#!/bin/bash

echo "Searching clients. Please be patient..."

python connect.py \
    --key ../../configs/morpheus/keys/client.key \
    --cert ../../configs/morpheus/keys/client.crt \
    --ca ../../configs/morpheus/keys/ca.crt \
    --broker_port 8883 \
    --seconds 20 \
    ping morpheus.pilvenreuna.fi


read -p "Client to connect: " CLIENT

python connect.py \
    --key ../../configs/morpheus/keys/client.key \
    --cert ../../configs/morpheus/keys/client.crt \
    --ca ../../configs/morpheus/keys/ca.crt \
    --broker_port 8883 \
    connect $CLIENT morpheus.pilvenreuna.fi
