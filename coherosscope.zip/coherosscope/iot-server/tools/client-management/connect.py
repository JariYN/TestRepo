#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Made in Earth by humans
# Copyright 2017 Coheros Oy

import argparse
import json
import os
import platform
import Queue
import socket
import tempfile
import time
from subprocess import call, check_output
import paho.mqtt.client as paho


LINUX_BASH_MAGIC = r'ss -ln4t | awk "{print \$4}" | grep -o -e ":.*" | sed "s/://"'
MAC_BASH_MAGIC = (
    r'lsof -i -n -P | grep LISTEN | awk "{print \$9}" | grep -o -e ":\d*\$" | sed "s/://"'
)


def find_free_remote_port(proxy):
    reserved_ports = check_output(['ssh', proxy, LINUX_BASH_MAGIC]).split('\n')
    for port in range(19990, 20050):
        if str(port) not in reserved_ports:
            return port
    raise RuntimeError("All ports are reserved! Try again later.")


def find_free_local_port():
    if platform.system() == 'Linux':
        reserved_ports = check_output(['bash', '-c', LINUX_BASH_MAGIC]).split('\n')
    elif platform.system() == 'Darwin':
        reserved_ports = check_output(['bash', '-c', MAC_BASH_MAGIC]).split('\n')
    else:
        raise RuntimeError("Only Linux and Mac are supported. Sorry.")
    for port in range(20050, 20060):
        if str(port) not in reserved_ports:
            return port
    raise RuntimeError("All ports are reserved! Try again later.")


def gen_ssh_keys(ca_key):
    """ Generate public and private ssh keys and sign certificate for limited access. """
    keyfile = tempfile.NamedTemporaryFile()
    keyfile.close()
    call(['ssh-keygen', '-q', '-f', keyfile.name, '-P', ''])
    call([
        'ssh-keygen', '-q',
        '-s', ca_key,
        '-I', "calling_home",
        "-n", "pi",
        "-V", "+5m",
        keyfile.name + '.pub'
    ])

    with open(keyfile.name) as priv_keyfile:
        priv_key = priv_keyfile.read()

    with open(keyfile.name + '.pub') as pub_keyfile:
        pub_key = pub_keyfile.read()

    with open(keyfile.name + '-cert.pub') as cert_keyfile:
        pub_cert = cert_keyfile.read()

    os.remove(keyfile.name)
    os.remove(keyfile.name + '.pub')
    os.remove(keyfile.name + '-cert.pub')

    return (priv_key, pub_key, pub_cert)


def mqtt_query(args, on_connect, on_subscribe, on_message, userdata):
    mqtt = paho.Client(userdata=userdata)
    mqtt.on_connect = on_connect
    mqtt.on_subscribe = on_subscribe
    mqtt.on_message = on_message

    if args.ca and args.key and args.cert:
        mqtt.tls_set(ca_certs=args.ca, certfile=args.cert, keyfile=args.key)
        mqtt.tls_insecure_set(True)

    try:
        mqtt.connect(args.broker_host, args.broker_port)
        mqtt.loop_start()
        time.sleep(args.seconds)
    except socket.gaierror as err:
        raise RuntimeError("Connection to {host}:{port} failed: {msg}".format(
            host=args.broker_host, port=args.broker_port, msg=err[1]))
    except socket.error as err:
        raise RuntimeError("Connection to {host}:{port} failed: {msg}".format(
            host=args.broker_host, port=args.broker_port, msg=err[1]))
    except KeyboardInterrupt:
        raise RuntimeError("Cancelled by user")
    finally:
        mqtt.loop_stop()
        mqtt.disconnect()


def do_ping(args):
    """List available remote clients"""
    def on_connect(client, userdata, flags, rc):
        client.subscribe('management/from/+/ping')

    def on_subscribe(client, userdata, mid, granted_qos):
        client.publish('management/to_all/ping')

    def on_message(client, userdata, message):
        userdata.append(message.topic.split('/')[2])

    clients = []
    mqtt_query(args, on_connect, on_subscribe, on_message, clients)
    if clients:
        print "Found client(s):"
        for client in clients:
            print "  {client}".format(client=client)
    else:
        print "No clients found"


def do_status(args):
    """Show service status of remore client"""
    def on_connect(client, userdata, flags, rc):
        client.subscribe('management/from/{client}/status'.format(client=args.client))

    def on_subscribe(client, userdata, mid, granted_qos):
        client.publish('management/to/{client}/status'.format(client=args.client))

    def on_message(client, userdata, message):
        userdata.append(message.payload)

    status_list = []
    mqtt_query(args, on_connect, on_subscribe, on_message, status_list)
    if status_list:
        print "Status of installed IoT services in {client}:\n".format(client=args.client)
        for raw_status in status_list:
            status = json.loads(raw_status)
            for service in sorted(status['services']):
                print "{service}:".format(service=service)
                print "-" * len(service)
                print "\ninstalled versions:"
                for version in sorted(status['services'][service]['versions']):
                    is_current = status['services'][service]['versions'][version]['current']
                    print "    {version}{active}".format(
                        version=version, active=" (in use)" if is_current else ""
                    )
                print "\nsystemctl status:"
                print status['services'][service]['status']


def do_connect(args):
    """Make a ssh connection to a remote server"""
    print "Generate keys"
    key, pub, cert = gen_ssh_keys(args.ca_key)

    print "Search free ports"
    remote_port = find_free_remote_port(args.proxy)
    local_port = find_free_local_port()

    params = json.dumps({ 'proxy': args.proxy, 
                         'key': key, 'pub': pub, 'cert': cert, 
                         'port':remote_port})

    mqtt = paho.Client()
    if args.ca and args.key and args.cert:
        mqtt.tls_set(ca_certs=args.ca, certfile=args.cert, keyfile=args.key)
        mqtt.tls_insecure_set(True)
    mqtt.connect(args.broker_host, args.broker_port)
    mqtt.publish('management/to/{host}/call_home'.format(host=args.client), params)

    time.sleep(args.seconds)

    call(["ssh", "-f", "-q",
          "-L", "{local}:localhost:{remote}".format(local=local_port, remote=remote_port),
          "-oStrictHostKeyChecking=no",
          "-oCheckHostIP=no",
          "-oConnectTimeout=1",
          "-oBatchMode=yes",
          args.proxy, "sleep 10"])

    print("To transfer files, command 'scp -oStrictHostKeyChecking=no pi@localhost "
          "-P {port}'").format(port=str(local_port))

    call(['ssh', '-oStrictHostKeyChecking=no', 'pi@localhost', '-p', str(local_port)])


def do_listen(args):
    """Listen MQTT messages"""
    def on_connect(client, userdata, flags, rc):
        client.subscribe('management/from/+/ping')

    def on_subscribe(client, userdata, mid, granted_qos):
        client.publish('management/to_all/ping')

    def on_message(client, userdata, message):
        userdata.append(message.topic.split('/')[2])

    clients = []
    mqtt_query(args, on_connect, on_subscribe, on_message, clients)
    if clients:
        print "Found client(s):"
        for client in clients:
            print "  {client}".format(client=client)
    else:
        print "No clients found"


##   ##  ####  #### ##  ##
### ### ##  ##  ##  ### ##
## # ## ######  ##  ## ###
##   ## ##  ## #### ##  ##

def main():

    parser = argparse.ArgumentParser(
        description="Remote client management CLI")
    subparsers = parser.add_subparsers(help="command help")

    # ping
    parser_ping = subparsers.add_parser('ping', help="list available clients")
    parser_ping.set_defaults(func=do_ping)

    # status
    parser_status = subparsers.add_parser('status', help="get status of a client")
    parser_status.add_argument('client', help="game of the remote client")
    parser_status.set_defaults(func=do_status)

    # connect
    parser_connect = subparsers.add_parser('connect', help="connect to a remote client")
    parser_connect.add_argument('client', type=str, help="name of the remote client")
    parser_connect.add_argument('--proxy', type=str, default="pi@194.136.129.102",
                                help="username and host for proxy server, e.g. user@host")
    parser_connect.add_argument('--ca_key', type=str, default="ssh_ca", help="path of CA key")
    parser_connect.set_defaults(func=do_connect)

    # for all
    parser.add_argument('broker_host', type=str, help="MQTT broker host name")
    parser.add_argument('--broker_port', type=int, default=1883,
                        help="MQTT broker port (default 1883)")
    parser.add_argument('--key', type=str, help="Path to TLS key", default="")
    parser.add_argument('--cert', type=str, help="Path to TLS certificate", default="")
    parser.add_argument('--ca', type=str, help="Path to CA certificate", default="")
    parser.add_argument('--seconds', type=int, default=2, help="seconds to wait client respond")

    args = parser.parse_args()
    args.func(args)


if __name__ == '__main__':
    try:
        main()
    except RuntimeError as err:
        print str(err)
