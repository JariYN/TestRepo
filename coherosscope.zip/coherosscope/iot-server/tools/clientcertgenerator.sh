#!/bin/bash

CLIENT="$1"

if [ -z "$CLIENT" ]
then
  echo "usage $0 <client>"
  exit 1
fi

COUNTRY="FI"
STATE="Pirkanmaa"
LOCALITY="Tampere"
ORGANIZATION="Coheros Oy"
ORGANIZATIONUNIT="IoT"
COMMONNAME="$CLIENT"
EMAIL="info@coheros.com"
DAYS="3650"

openssl genrsa -out "$CLIENT".key 2048 &&
openssl req -out "$CLIENT".csr -key "$CLIENT".key -new -subj "/C=$COUNTRY/ST=$STATE/L=$LOCALITY/O=$ORGANIZATION/OU=$ORGANIZATIONUNIT/CN=$COMMONNAME/emailAddress=$EMAIL" &&
openssl x509 -req -in "$CLIENT".csr -CA ca.crt -CAkey ca.key -CAcreateserial -out "$CLIENT".crt -days "$DAYS" &&
openssl x509 -in "$CLIENT".crt -text -noout
