#!/bin/bash

# Set test environment variables
export GRAFANA_ADMIN_PASSWORD=admin
export FULLY_QUALIFIED_DOMAIN_NAME=localhost
export LETSENCRYPT_CERT_PATH=../configs

# Start up mtign stack...
docker-compose up -d
sleep 10

# Run tests
curl -k -H "Content-Type: application/json" -XPOST "https://localhost/lorawan_demo" -d '{
    "DevEUI_uplink": {
        "Time": "2017-12-21T07:32:23.999+01:00",
        "DevEUI": "4786C58B00450045",
        "FPort": "8",
        "FCntUp": "38712",
        "ADRbit": "1",
        "MType": "2",
        "FCntDn": "3141",
        "payload_hex": "0019eb0103b5020b4103091204000f6940051b91660dec67089f6804096902326a0b52",
        "mic_hex": "82624612",
        "Lrcid": "00000201",
        "LrrRSSI": "-88.000000",
        "LrrSNR": "-19.000000",
        "SpFact": "11",
        "SubBand": "G3",
        "Channel": "LC8",
        "DevLrrCnt": "8",
        "Lrrid": "FF017EE8",
        "Late": "0",
        "LrrLAT": "60.165096",
        "LrrLON": "24.946859",
        "Lrrs": {
            "Lrr": [
                {
                    "Lrrid": "FF017EE8",
                    "Chain": "0",
                    "LrrRSSI": "-88.000000",
                    "LrrSNR": "-19.000000",
                    "LrrESP": "-107.054337"
                },
                {
                    "Lrrid": "FF0109D8",
                    "Chain": "0",
                    "LrrRSSI": "-108.000000",
                    "LrrSNR": "-10.000000",
                    "LrrESP": "-118.413925"
                },
                {
                    "Lrrid": "FF017D48",
                    "Chain": "0",
                    "LrrRSSI": "-116.000000",
                    "LrrSNR": "-2.750000",
                    "LrrESP": "-120.599426"
                }
            ]
        },
        "CustomerID": "100006244",
        "CustomerData": {
            "alr": {
                "pro": "LORA/Generic",
                "ver": "1"
            }
        },
        "ModelCfg": "0",
        "DevAddr": "028CF2FE"
    }
}'

curl -k -H "Content-Type: application/json" -XPOST "https://localhost/lorawan_demo" -d '{
    "DevEUI_uplink": {
        "Time": "2017-11-27T07:12:41.864+01:00",
        "DevEUI": "4786C58B004A002A",
        "FPort": "8",
        "FCntUp": "5459",
        "MType": "4",
        "FCntDn": "7874",
        "payload_hex": "000893004a00",
        "mic_hex": "ceb67321",
        "Lrcid": "00000201",
        "LrrRSSI": "-108.000000",
        "LrrSNR": "-20.000000",
        "SpFact": "12",
        "SubBand": "G1",
        "Channel": "LC2",
        "DevLrrCnt": "1",
        "Lrrid": "FF017E98",
        "Late": "0",
        "LrrLAT": "61.542294",
        "LrrLON": "23.597982",
        "Lrrs": {
            "Lrr": [
                {
                    "Lrrid": "FF017E98",
                    "Chain": "0",
                    "LrrRSSI": "-108.000000",
                    "LrrSNR": "-20.000000",
                    "LrrESP": "-128.043213"
                }
            ]
        },
        "CustomerID": "100006244",
        "CustomerData": {
            "alr": {
                "pro": "LORA/Generic",
                "ver": "1"
            }
        },
        "ModelCfg": "0",
        "AppSKey": "9cde0c4441959d86359c54d0e0bb3164",
        "DevAddr": "0395B6F3"
    }
}'

curl -k -H "Content-Type: application/json" -XPOST "https://localhost/otso_demo" -d '{
    "otso_v1": {
        "id": "imei",
        "lon": 0.000,
        "lat": 0.000,
        "loc_acc": 0,
        "battery": 0,
        "value": 0
    }
}'

# Show results
docker-compose logs | grep -e "ode,model=" -e "aiqu,model=" -e "otso,model="

# Clean up
docker-compose down