"use strict";

/*

ODE-sensor
==========

byte index:
0: AppLedStateOn;
1: int16 MSB temperature 0.01C, [-39.7 .. +124.13] -50.00C = fail
2: int16 LSB temperature
3: uint16 MSB humidity 0.01RH%, [0 .. 100] 200.00RH% = fail
4: uint16 LSB humidity
5: uint8 batteryLevel 0%-100% [0 .. 255]

*/

function hex2uint16(index, hex) {return (parseInt(hex.substr(index*2, 2), 16) << 8) | parseInt(hex.substr(index*2+2, 2), 16)}
function hex2sint16(index, hex) {return (hex2uint16(index, hex) + 0x8000 & 0xFFFF) - 0x8000}
function hex2uint8(index, hex) {return parseInt(hex.substr(index*2, 2), 16)}

class OdeData {

    constructor(data) {
        this._isValid = false;
        if ('DevEUI_uplink' in data) {
            var hex = data.DevEUI_uplink.payload_hex;

            this.tempMin = -39.70;
            this.tempMax = 124.13;
            this.tempErr = -50.00;

            this.humMin = 0.00;
            this.humMax = 100.00;
            this.humErr = 200.00;

            this.battMin = 0.00;
            this.battMax = 100.00;
            this.battErr = 0.00;

            this._temperature = this.tempErr;
            this._humidity = this.humErr;
            this._batteryLevel = this.battErr;
            this._model = "SHT75"

            this._isValid = true;
            if (hex.length != 12) {
                this._isValid = false;
                return;
            }

            this._temperature = hex2sint16(1, hex)/100;
            this._humidity = hex2uint16(3, hex)/100;
            this._batteryLevel = Math.round((hex2uint8(5, hex)/2.55) * 100) / 100;

            if (((this._temperature < this.tempMin || this._temperature > this.tempMax) && this._temperature != this.tempErr) ||
                ((this._humidity < this.humMin || this._humidity > this.humMax) && this._humidity != this.humErr) ||
                ((this._batteryLevel < this.battMin || this._batteryLevel > this.battMax) && this._batteryLevel != this.battErr)) {

                this._isValid = false;

            }
        }
    }

    get isValid() {
        return this._isValid;
    }

    get fieldsForInfluxdb() {
        return "temperature=" + this._temperature.toString() +
            ",humidity=" + this._humidity.toString() +
            ",battery_level=" + this._batteryLevel.toString();
    }

    get tagsForInfluxdb() {
        return "model=" + this._model +
            ",temperatureErr=" + (this._temperature == this.tempErr).toString() +
            ",humidityErr=" + (this._humidity == this.humErr).toString() +
            ",batteryLevelErr=" + (this._batteryLevel == this.battErr).toString();
    }

}

module.exports.OdeData = OdeData;
