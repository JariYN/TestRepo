"use strict";

const geohash = require('ngeohash');

/*

OTSO-sensor
===========

Otso is a MaxBotix Inc's ultrasonic sensor MB7589 with GSM and GPS.

Otso messages has following json structure:

{
    "otso_v1": {
        "id": "imei",       // string
        "lon": "0.000",     // float, degrees
        "lat": "0.000",     // float, degrees
        "loc_acc": "0",     // int, mm
        "battery": "0",     // int, 0-100
        "value": "0"        // int, measured distance, mm
    }
}

*/

class OtsoData {

    constructor(data) {
        this._isValid = false;
        this._id = "";
        this._loc = "";
        this._loc_acc = 0;
        this._battery = 0;
        this._value = 0;
        this._model = "MB7589";

        if ('otso_v1' in data) {
            this._isValid = true;
            this._id = data.otso_v1.id;
            this._loc = geohash.encode(parseFloat(data.otso_v1.lat), parseFloat(data.otso_v1.lon));
            this._loc_acc = parseInt(data.otso_v1.loc_acc);
            this._battery = parseInt(data.otso_v1.battery);
            this._value = parseInt(data.otso_v1.value);
        }
    }

    get isValid() {
        return this._isValid;
    }

    get fieldsForInfluxdb() {
        return "battery_level=" + this._battery + ",location_accuracy=" + this._loc_acc + ",value=" + this._value;
    }

    get tagsForInfluxdb() {
        return "model=" + this._model + ",device_location=" + this._loc + ",device_id=" + this._id;
    }

}


module.exports.OtsoData = OtsoData;