module.exports = {

    doForward: true,

    destinations: [

        {
            destinationURI:
            {
                host: "aiqu-demo.metosin.fi",
                port: 443,
                path: "/api/receive"
            },

            packetFilters: [

                // AiQu-22
                {
                    key: "DevEUI",
                    value: "2823730D5529351C"
                },
                // ODE-01
                {
                    key: "DevEUI",
                    value: "282373B159BD77B3"
                },
                // ODE-02
                {
                    key: "DevEUI",
                    value: "282373AE90BD7BF4"
                }

            ]
        },


        // Vuores POC configuration

        {
            destinationURI:
            {
                host: "palvelin1.tunninen.fi",
                port: 455,
                path: "/api/v1/coherosdata/",
                authorization: "Basic Y29oZXJvczpDb2hlMTM1Nw=="
            },

            jsonTemplate: `{
                "timestamp": "{{now}}",
                "device_id": "{{filter.name}}",
                "data": [
                    { "name": "temperature", "value": {{aiqu.UG250.temperature}} , "unit": "celsius" },
                    { "name": "humidity", "value": {{aiqu.UG250.humidity}}, "unit": "percentage" },
                    { "name": "co2", "value": {{aiqu.LP8.co2}}, "unit": "ppm" },
                    { "name": "tvoc", "value": {{aiqu.UG250.tvoc}}, "unit": "ppb" },
                    { "name": "atmospheric_pressure", "value": {{aiqu.UG250.pressure}}, "unit": "Pa" },
                    { "name": "sound_level", "value": {{aiqu.UG250.sound_level}}, "unit": "dBm" }
                ]
            }`,

            packetFilters: [

                {
                    key: "DevEUI",
                    value: "70B3D5D2E84731E7",
                    name: "AiQu-23"
                },
                {
                    key: "DevEUI",
                    value: "70B3D5D2E847349B",
                    name: "AiQu-24"
                }

            ]
        }

        // Add more destinations here

    ]
};