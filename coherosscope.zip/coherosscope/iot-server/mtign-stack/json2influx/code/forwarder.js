"use strict";

const https = require('https');
const mustache = require('mustache');
const doForward = require('./config/forwarder.config').doForward;
const destinations = require('./config/forwarder.config').destinations;
const AiquData = require('./aiqu').AiquJsonData;

class LoraPacketForwarder {
    constructor(data) {
        this._data = data;
    }

    send() {
        var data = this._data;
        destinations.forEach(function(dest) {
            dest.packetFilters.some(function(filter) {
                var breakPacketFilterLoop = false;
                if (doForward &&
                    'DevEUI_uplink' in data &&
                    filter.key in data.DevEUI_uplink &&
                    filter.value === data.DevEUI_uplink[filter.key]) {

                    console.log("*** forwarding packet ***");
                    console.log("*** FW URI: " + dest.destinationURI.host + ":" + dest.destinationURI.port.toString() + dest.destinationURI.path);
                    console.log("*** FW filter: " + filter.key + ": " + filter.value);

                    var jsonData = JSON.stringify(data);
                    if ('jsonTemplate' in dest) {
                        let templateData = {
                            aiqu: new AiquData(data).asJson(),
                            now: new Date().toISOString(),
                            filter: filter }
                        jsonData = mustache.render(dest.jsonTemplate, templateData);
                        jsonData = JSON.stringify(JSON.parse(jsonData));
                        // console.log("*** mustache:", jsonData);
                    }
                    var options = {
                        hostname: dest.destinationURI.host,
                        port: dest.destinationURI.port,
                        path: dest.destinationURI.path,
                        method: 'POST',
                        rejectUnauthorized: false,
                        headers: {
                            'Content-Type': 'application/json',
                            'Content-Length': Buffer.byteLength(jsonData, 'utf8')}
                    };

                    if (dest.destinationURI.authorization) {
                        options.headers.Authorization = dest.destinationURI.authorization;
                    }

                    var reqPost = https.request(options, function(res) {
                        console.log("statusCode: ", res.statusCode);

                        res.on('data', function(d) {
                            console.info('POST result:\n');
                            process.stdout.write(d);
                            console.info('\n\nPOST completed');
                        });
                    });

                    reqPost.write(jsonData);
                    reqPost.end();
                    reqPost.on('error', function(e) {
                        console.error(e);
                    });
                    breakPacketFilterLoop = true;
                }
                return breakPacketFilterLoop;
            });
        });
    }

}

module.exports.LoraPacketForwarder = LoraPacketForwarder;