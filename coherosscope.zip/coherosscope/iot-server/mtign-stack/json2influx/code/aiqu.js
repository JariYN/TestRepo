"use strict";

const aiquMeaTypes = {
    "00": {desc: "co2",         model: "UG250",   format: "uint", size: 4, units: 1},
    "01": {desc: "tvoc",        model: "UG250",   format: "uint", size: 4, units: 1},
    "02": {desc: "humidity",    model: "UG250",   format: "uint", size: 4, units: 0.01},
    "03": {desc: "temperature", model: "UG250",   format: "int",  size: 4, units: 0.01},
    "04": {desc: "pressure",    model: "UG250",   format: "uint", size: 8, units: 0.1},
    "05": {desc: "sound_level", model: "UG250",   format: "int",  size: 4, units: 0.01},
    "64": {desc: "humidity",    model: "HIH9130", format: "uint", size: 4, units: 0.01},
    "65": {desc: "temperature", model: "HIH9130", format: "int",  size: 4, units: 0.01},
    "66": {desc: "humidity",    model: "GMW93",   format: "int",  size: 4, units: 0.01},
    "67": {desc: "temperature", model: "GMW93",   format: "int",  size: 4, units: 0.01},
    "68": {desc: "co2",         model: "GMW93",   format: "uint", size: 4, units: 1},
    "69": {desc: "co2",         model: "LP8",     format: "uint", size: 4, units: 1},
    "6a": {desc: "temperature", model: "LP8",     format: "int",  size: 4, units: 0.01}
};


class AiquData {
    constructor(model, meas, data) {
        this._measurements = this.parseMeasurements(data, meas);
        this._model = model;
    }

    parseMeasurements(data, meas) {
        var meaList = [];
        meas.forEach(function(mea) {
            for (var i=0; i<data.length;) {
                var meaId = data.slice(i, i+2).toLowerCase();
                if (!aiquMeaTypes.hasOwnProperty(meaId)) {
                    // Unknown meaType in data, it cannot be parsed anymore
                    console.log("Unknown meaType: " + meaId);
                    console.log("   mea: " + mea);
                    console.log("     i: " + i.toString());
                    console.log("  data: " + data);
                    break;
                }
                var meaType = aiquMeaTypes[meaId];
                if (meaId == mea.toLowerCase()) {
                    var hexValue = data.slice(i+2, i+2+meaType.size);
                    var value = 0;
                    if (meaType.format == "uint") {
                        value = parseInt(hexValue, 16);
                    } else if (meaType.format == "int" && meaType.size == 4){
                        value = ((parseInt(hexValue, 16)+0x8000)&0xFFFF)-0x8000;
                    } else {
                        console.log("Unsupported format: " + mea + " - " + meaType.format + " for size " + meaType.size.toString());
                        break;
                    }
                    //console.log("Matched mea: " + mea + " - " + meaType.desc + "=" + (value * meaType.units).toFixed(2));
                    meaList.push(meaType.desc + "=" + (value * meaType.units).toFixed(2));
                    break;
                }
                i += 2 + meaType.size;
            }
        });
        return meaList.join();
    }

    get isValid() {
        return this._measurements != "";
    }

    get fieldsForInfluxdb() {
        return this._measurements;
    }

    get tagsForInfluxdb() {
        return "model=" + this._model;
    }
}


class AiquUG250Data extends AiquData {
    constructor(data) {
        super("UG250", ["00", "01", "02", "03", "04", "05"],
            'DevEUI_uplink' in data ? data.DevEUI_uplink.payload_hex: "");
    }
}


class AiquGMW93Data extends AiquData {
    constructor(data) {
        super("GMW93", ["66", "67", "68"],
            'DevEUI_uplink' in data ? data.DevEUI_uplink.payload_hex: "");
    }
}


class AiquLP8Data extends AiquData {
    constructor(data) {
        super("LP8", ["69", "6a"],
            'DevEUI_uplink' in data ? data.DevEUI_uplink.payload_hex: "");
    }
}

class AiquJsonData {

    constructor(data) {
        this._measurements = this.parseMeasurements(
            'DevEUI_uplink' in data ? data.DevEUI_uplink.payload_hex: "");

    }

    parseMeasurements(data) {
        var meaValues = {};

        for (var i=0; i<data.length;) {
            var meaId = data.slice(i, i+2).toLowerCase();
            if (!aiquMeaTypes.hasOwnProperty(meaId)) {
                // Unknown meaType in data, it cannot be parsed anymore
                console.log("Unknown meaType: " + meaId);
                console.log("   mea: " + mea);
                console.log("     i: " + i.toString());
                console.log("  data: " + data);
                break;
            }
            var meaType = aiquMeaTypes[meaId];

            var hexValue = data.slice(i+2, i+2+meaType.size);
            var value = 0;
            if (meaType.format == "uint") {
                value = parseInt(hexValue, 16);
            } else if (meaType.format == "int" && meaType.size == 4){
                value = ((parseInt(hexValue, 16)+0x8000)&0xFFFF)-0x8000;
            } else {
                console.log("Unsupported format: " + mea + " - " + meaType.format + " for size " + meaType.size.toString());
                break;
            }
            if (!meaValues.hasOwnProperty(meaType.model)) {
                meaValues[meaType.model] = {};
            }
            // console.log("***", meaType);
            meaValues[meaType.model][meaType.desc] =  Number((value * meaType.units).toFixed(2));
            i += 2 + meaType.size;
        }
        return meaValues;
    }

    asJson() {
        return this._measurements;
    }
}

module.exports.AiquGMW93Data = AiquGMW93Data;
module.exports.AiquLP8Data = AiquLP8Data;
module.exports.AiquUG250Data = AiquUG250Data;
module.exports.AiquJsonData = AiquJsonData;