"use strict";

const port = 3000;

const express = require('express');
const bodyParser = require('body-parser');

const ode = require('./ode');
const aiqu = require('./aiqu');
const dbapi = require('./dbapi');
const forwarder = require('./forwarder')
const otso = require('./otso');

const app = express();
app.use(bodyParser.json());
app.listen(port, () => {
    console.log('RESTful API server started on: ' + port);
});

app.post('/', (req, res) => {
    console.log("*** input ***");
    console.log(JSON.stringify(req.body, null, 4));
    res.send('');

    console.log("*** output ***")

    // Store and forward Ode data
    var handler = new ode.OdeData(req.body);
    if (handler.isValid) {
        new dbapi.LoraPacketSender(req.body).sendDataToInfluxdb("ode", "ode", handler);
        new forwarder.LoraPacketForwarder(req.body).send();
        return;
    }

    // Store Otso data
    handler = new otso.OtsoData(req.body);
    if (handler.isValid) {
        var data = handler.tagsForInfluxdb + " " + handler.fieldsForInfluxdb;
        new dbapi.InfluxdbPacketSender().sendDataToInfluxdb('ode', 'otso', data);
        return;
    }

    // Store Aiqu data
    var aiquHandlers = [new aiqu.AiquGMW93Data(req.body), new aiqu.AiquUG250Data(req.body), new aiqu.AiquLP8Data(req.body)];
    aiquHandlers.forEach(function(handler) {
        if (handler.isValid) {
            new dbapi.LoraPacketSender(req.body).sendDataToInfluxdb("ode", "aiqu", handler);
        }
    });

    // Forward Aiqu data
    new forwarder.LoraPacketForwarder(req.body).send();

});
