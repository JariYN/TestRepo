
"use strict";

const geohash = require('ngeohash');
const http = require('http');


class SignalQuality {
    constructor(data) {
        this._rssi = Math.round(parseFloat(data.DevEUI_uplink.LrrRSSI) * 100) / 100;
        this._snr = Math.round(parseFloat(data.DevEUI_uplink.LrrSNR) * 100) / 100;
    }

    get rssi() {
        return this._rssi;
    }

    get snr() {
        return this._snr;
    }

    get fieldsForInfluxdb() {
        return "rssi=" + this._rssi +
            ",snr=" + this._snr;
    }
}


class RelayLocation {
    constructor(data) {
        this._lon = parseFloat(data.DevEUI_uplink.LrrLON);
        this._lat = parseFloat(data.DevEUI_uplink.LrrLAT);
    }

    get tagsForInfluxdb() {
        return "relay_location=" + geohash.encode(this._lat, this._lon);
    }

}


class DeviceID {
    constructor(data) {
        this._deviceID = data.DevEUI_uplink.DevEUI;
    }

    get tagsForInfluxdb() {
        return "device_id=" + this._deviceID;
    }
}


class InfluxdbPacketSender {
    sendDataToInfluxdb(db, mea, data) {
        var influxData = mea + "," + data;

        console.log(influxData);

        var options = {
            hostname: 'database',
            port: 8086,
            path: '/write?db=' + db,
            method: 'POST',
            headers: {'Content-Type': 'text/plain'}
        };

        var req = http.request(options, function(res) {
            console.log('Status: ' + res.statusCode);
            console.log('Headers: ' + JSON.stringify(res.headers));
            res.setEncoding('utf8');
            res.on('data', function(body) {
                console.log('Body: ' + body);
            });
        });

        req.on('error', function(e) {
            console.log('Error: ' + e.message);
        });
        req.write(influxData);
        req.end();
    }
}


class LoraPacketSender extends InfluxdbPacketSender {
    constructor(data) {
        super();
        this._signal = new SignalQuality(data);
        this._loc = new RelayLocation(data);
        this._id = new DeviceID(data);
        this._date = new Date(Date.parse(data.DevEUI_uplink.Time));
    }

    sendDataToInfluxdb(db, mea, data) {
        var influxData = [data.tagsForInfluxdb, this._loc.tagsForInfluxdb, this._id.tagsForInfluxdb].join() +
            " " + [data.fieldsForInfluxdb, this._signal.fieldsForInfluxdb].join() +
            " " + (this._date.getTime() * 1000000).toString();

        super.sendDataToInfluxdb(db, mea, influxData);
    }
}


module.exports.InfluxdbPacketSender = InfluxdbPacketSender;
module.exports.LoraPacketSender = LoraPacketSender;
