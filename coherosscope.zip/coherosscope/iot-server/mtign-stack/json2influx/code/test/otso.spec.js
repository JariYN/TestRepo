const expect = require('chai').expect;
const nock = require('nock');
const otso = require('../otso');
const dbapi = require('../dbapi');

const otsoInput = {
    "otso_v1": {
        "id": "imei",       // string
        "lon": "0.000",     // float, degrees
        "lat": "0.000",     // float, degrees
        "loc_acc": "1",     // int, mm
        "battery": "2",     // int, 0-100
        "value": "3"        // int, measured distance, mm
    }
};

describe('Otso data', function() {
    it('should be send to database', function() {

        var expectedOutput = 'test,model=MB7589,device_location=7zzzzzzzz,device_id=imei '+
            'battery_level=2,location_accuracy=1,value=3';

        nock.cleanAll();
        var dbAPI = nock("http://database:8086")
            .post('/write?db=test', function(body) {
                expect(body).to.eql(expectedOutput);
                return true;
            })
            .reply(200, "");

        var otsoData = new otso.OtsoData(otsoInput);
        expect(otsoData.isValid).to.eql(true);
        var dataToInfluxdb = otsoData.tagsForInfluxdb + " " + otsoData.fieldsForInfluxdb;

        var sender = new dbapi.InfluxdbPacketSender();
        sender.sendDataToInfluxdb('test', 'test', dataToInfluxdb);
        expect(dbAPI.isDone()).to.eql(true);
    });
});
