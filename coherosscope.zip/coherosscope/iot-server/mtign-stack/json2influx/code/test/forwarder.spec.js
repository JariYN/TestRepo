const expect = require('chai').expect;
const nock = require('nock');
const forwarder = require('../forwarder');

const receivedData = {
    "DevEUI_uplink": {
        "Time": "2017-11-27T07:12:41.864+01:00",
        "DevEUI": "2823730D5529351C",
        "FPort": "8",
        "FCntUp": "5459",
        "MType": "4",
        "FCntDn": "7874",
        "payload_hex": "0019eb0103b5020b4103091204000f6940051b91660dec67089f6804096902326a0b52",
        "mic_hex": "ceb67321",
        "Lrcid": "00000201",
        "LrrRSSI": "-108.000000",
        "LrrSNR": "-20.000000",
        "SpFact": "12",
        "SubBand": "G1",
        "Channel": "LC2",
        "DevLrrCnt": "1",
        "Lrrid": "FF017E98",
        "Late": "0",
        "LrrLAT": "61.542294",
        "LrrLON": "23.597982",
        "Lrrs": {
            "Lrr": [
                {
                    "Lrrid": "FF017E98",
                    "Chain": "0",
                    "LrrRSSI": "-108.000000",
                    "LrrSNR": "-20.000000",
                    "LrrESP": "-128.043213"
                }
            ]
        },
        "CustomerID": "100006244",
        "CustomerData": {
            "alr": {
                "pro": "LORA/Generic",
                "ver": "1"
            }
        },
        "ModelCfg": "0",
        "AppSKey": "9cde0c4441959d86359c54d0e0bb3164",
        "DevAddr": "0395B6F3"
    }
};

describe('Forwarder', function() {
    it('should forward packet', function() {

        nock.cleanAll();
        var targetAPI = nock("https://aiqu-demo.metosin.fi")
            .post('/api/receive', function(body) {
                expect(body).to.eql(receivedData);
                return true;
            })
            .reply(200, "");

        new forwarder.LoraPacketForwarder(receivedData).send();
        expect(targetAPI.isDone()).to.eql(true);

    });

    it('should forward packet in custom format', function() {
        nock.cleanAll();
        var targetAPI = nock("https://palvelin1.tunninen.fi:455")
            .post('/api/v1/coherosdata/', function(body) {
                const dataOut =  {
                    "device_id": "AiQu-23",
                    "timestamp": body.timestamp,
                    "data": [
                        { "name": "temperature", "value": 23.22 , "unit": "celsius" },
                        { "name": "humidity", "value": 28.81, "unit": "percentage" },
                        { "name": "co2", "value": 562, "unit": "ppm" },
                        { "name": "tvoc", "value": 949, "unit": "ppb" },
                        { "name": "atmospheric_pressure", "value": 100998.4, "unit": "Pa" },
                        { "name": "sound_level", "value": 70.57, "unit": "dBm" }
                    ]
                };

                expect(body).to.eql(dataOut);
                return true;
            })
            .basicAuth({user: 'coheros', pass: 'Cohe1357'})
            .reply(200, "");

            var dataIn = JSON.parse(JSON.stringify(receivedData));
            dataIn.DevEUI_uplink.DevEUI = '70B3D5D2E84731E7';
            new forwarder.LoraPacketForwarder(dataIn).send();
            expect(targetAPI.isDone()).to.eql(true);
        });
});

const odeData = {
    "DevEUI_uplink": {
        "Time": "2018-05-16T10:54:26.000+02:00",
        "DevEUI": "282373B159BD77B3",
        "FPort": "8",
        "FCntUp": "66",
        "MType": "2",
        "FCntDn": "35",
        "payload_hex": "000de90c43e2",
        "mic_hex": "5553f971",
        "Lrcid": "00000201",
        "LrrRSSI": "-115.000000",
        "LrrSNR": "-10.000000",
        "SpFact": "9",
        "SubBand": "G1",
        "Channel": "LC2",
        "DevLrrCnt": "1",
        "Lrrid": "FF0193BB",
        "Late": "0",
        "LrrLAT": "61.450024",
        "LrrLON": "23.858814",
        "Lrrs": {
            "Lrr": [
                {
                    "Lrrid": "FF0193BB",
                    "Chain": "0",
                    "LrrRSSI": "-115.000000",
                    "LrrSNR": "-10.000000",
                    "LrrESP": "-125.413925"
                }
            ]
        },
        "CustomerID": "100006244",
        "CustomerData": {
            "alr": {
                "pro": "LORA/Generic",
                "ver": "1"
            }
        },
        "ModelCfg": "0",
        "DevAddr": "E0033105"
    }
}

describe('Forwarder', function() {
    it('should forward ODE packet', function() {

        nock.cleanAll();
        var targetAPI = nock("https://aiqu-demo.metosin.fi")
            .post('/api/receive', function(body) {
                expect(body).to.eql(odeData);
                return true;
            })
            .reply(200, "");

        new forwarder.LoraPacketForwarder(odeData).send();
        expect(targetAPI.isDone()).to.eql(true);

    });
});
