const expect = require('chai').expect;
const nock = require('nock');
const ode = require('../ode');
const dbapi = require('../dbapi');

const odeInput = {
    "DevEUI_uplink": {
        "Time": "2017-11-27T07:12:41.864+01:00",
        "DevEUI": "4786C58B004A002A",
        "FPort": "8",
        "FCntUp": "5459",
        "MType": "4",
        "FCntDn": "7874",
        "payload_hex": "000893004a00",
        "mic_hex": "ceb67321",
        "Lrcid": "00000201",
        "LrrRSSI": "-108.000000",
        "LrrSNR": "-20.000000",
        "SpFact": "12",
        "SubBand": "G1",
        "Channel": "LC2",
        "DevLrrCnt": "1",
        "Lrrid": "FF017E98",
        "Late": "0",
        "LrrLAT": "61.542294",
        "LrrLON": "23.597982",
        "Lrrs": {
            "Lrr": [
                {
                    "Lrrid": "FF017E98",
                    "Chain": "0",
                    "LrrRSSI": "-108.000000",
                    "LrrSNR": "-20.000000",
                    "LrrESP": "-128.043213"
                }
            ]
        },
        "CustomerID": "100006244",
        "CustomerData": {
            "alr": {
                "pro": "LORA/Generic",
                "ver": "1"
            }
        },
        "ModelCfg": "0",
        "AppSKey": "9cde0c4441959d86359c54d0e0bb3164",
        "DevAddr": "0395B6F3"
    }
};

describe('Ode data', function() {
    it('should be send to database', function() {

        var expectedOutput = 'ode,model=SHT75,temperatureErr=false,humidityErr=false,'+
            'batteryLevelErr=true,relay_location=udby0grtb,device_id=4786C58B004A002A '+
            'temperature=21.95,humidity=0.74,battery_level=0,rssi=-108,snr=-20 1511763161864000000';

        nock.cleanAll();
        var dbAPI = nock("http://database:8086")
            .post('/write?db=ode', function(body) {
                expect(body).to.eql(expectedOutput);
                return true;
            })
            .reply(200, "");

        var odeData = new ode.OdeData(odeInput);
        expect(odeData.isValid).to.eql(true);
        var sender = new dbapi.LoraPacketSender(odeInput);

        sender.sendDataToInfluxdb('ode', 'ode', odeData);
        expect(dbAPI.isDone()).to.eql(true);
    });
});
