const expect = require('chai').expect;
const nock = require('nock');
const aiqu = require('../aiqu');
const dbapi = require('../dbapi');

const aiquInput = {
    "DevEUI_uplink": {
        "Time": "2017-12-21T07:32:23.999+01:00",
        "DevEUI": "4786C58B00450045",
        "FPort": "8",
        "FCntUp": "38712",
        "ADRbit": "1",
        "MType": "2",
        "FCntDn": "3141",
        "payload_hex": "0019eb0103b5020b4103091204000f6940051b91660dec67089f6804096902326a0b52",
        "mic_hex": "82624612",
        "Lrcid": "00000201",
        "LrrRSSI": "-88.000000",
        "LrrSNR": "-19.000000",
        "SpFact": "11",
        "SubBand": "G3",
        "Channel": "LC8",
        "DevLrrCnt": "8",
        "Lrrid": "FF017EE8",
        "Late": "0",
        "LrrLAT": "60.165096",
        "LrrLON": "24.946859",
        "Lrrs": {
            "Lrr": [
                {
                    "Lrrid": "FF017EE8",
                    "Chain": "0",
                    "LrrRSSI": "-88.000000",
                    "LrrSNR": "-19.000000",
                    "LrrESP": "-107.054337"
                },
                {
                    "Lrrid": "FF0109D8",
                    "Chain": "0",
                    "LrrRSSI": "-108.000000",
                    "LrrSNR": "-10.000000",
                    "LrrESP": "-118.413925"
                },
                {
                    "Lrrid": "FF017D48",
                    "Chain": "0",
                    "LrrRSSI": "-116.000000",
                    "LrrSNR": "-2.750000",
                    "LrrESP": "-120.599426"
                }
            ]
        },
        "CustomerID": "100006244",
        "CustomerData": {
            "alr": {
                "pro": "LORA/Generic",
                "ver": "1"
            }
        },
        "ModelCfg": "0",
        "DevAddr": "028CF2FE"
    }
};


describe('Aiqu data', function() {
    it("should send LP8 sensor data to database", function() {

        var expectedOutput = 'aiqu,model=LP8,relay_location=ud9wr8txp,device_id=4786C58B00450045 '+
            'co2=562.00,temperature=28.98,rssi=-88,snr=-19 1513837943999000000';

        nock.cleanAll();
        var dbAPI = nock("http://database:8086")
            .post('/write?db=ode', function(body) {
                expect(body).to.eql(expectedOutput);
                return true;
            })
            .reply(200, "");

        var aiquData = new aiqu.AiquLP8Data(aiquInput);
        var sender = new dbapi.LoraPacketSender(aiquInput);

        expect(aiquData.isValid).to.eql(true, 'AiquData.isValid is false');
        sender.sendDataToInfluxdb('ode', 'aiqu', aiquData);
        expect(dbAPI.isDone()).to.eql(true);

    });

    it("should send GMW93 sensor data to database", function() {

        var expectedOutput = 'aiqu,model=GMW93,relay_location=ud9wr8txp,device_id=4786C58B00450045 '+
            'humidity=35.64,temperature=22.07,co2=1033.00,rssi=-88,snr=-19 1513837943999000000';

        nock.cleanAll();
        var dbAPI = nock("http://database:8086")
            .post('/write?db=ode', function(body) {
                expect(body).to.eql(expectedOutput);
                return true;
            })
            .reply(200, "");

        var aiquData = new aiqu.AiquGMW93Data(aiquInput);
        var sender = new dbapi.LoraPacketSender(aiquInput);

        expect(aiquData.isValid).to.eql(true, 'AiquData.isValid is false');
        sender.sendDataToInfluxdb('ode', 'aiqu', aiquData);
        expect(dbAPI.isDone()).to.eql(true);

    });

    it("should send UG250 sensor data to database", function() {

        var expectedOutput = 'aiqu,model=UG250,relay_location=ud9wr8txp,device_id=4786C58B00450045 '+
            'co2=6635.00,tvoc=949.00,humidity=28.81,temperature=23.22,pressure=100998.40,'+
            'sound_level=70.57,rssi=-88,snr=-19 1513837943999000000';

        nock.cleanAll();
        var dbAPI = nock("http://database:8086")
            .post('/write?db=ode', function(body) {
                expect(body).to.eql(expectedOutput);
                return true;
            })
            .reply(200, "");

        var aiquData = new aiqu.AiquUG250Data(aiquInput);
        var sender = new dbapi.LoraPacketSender(aiquInput);

        expect(aiquData.isValid).to.eql(true, 'AiquData.isValid is false');
        sender.sendDataToInfluxdb('ode', 'aiqu', aiquData);
        expect(dbAPI.isDone()).to.eql(true);

    });

});
