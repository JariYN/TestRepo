
const mongo = require('mongodb');
const express = require('express')
const fs = require('fs');

const MongoClient = mongo.MongoClient;
const url = "mongodb://mongodb:27017/prod-test";
const apiKey = "23fhsDF455HsgsDFRTbfht5nukllksddvs346grvsSse436geSDVhdsddv";

let dbo;
MongoClient.connect(url, { useNewUrlParser: true }, function(err, db) {
    if (err) {
        console.log('DB conn failed: ', err);
        process.exit(1)
    }
    dbo = db.db('prod-test');
}); 

const app = express()
app.use(express.json());

const port = 3000

function isAuthorized(req) {
    _apiKey = req.get('api-key')
    return _apiKey == apiKey
}

function parseRequest(req, res) {
    result = {}
    console.log(req.body);
    result.client = req.body.client;
    result.status = req.body.status;
    result.log = req.body.log;
    result.mcuId = req.body.mcuId;
    result.serialNumber = req.body.serialNumber;
    result.arrivalTime = new Date()
    return result;
}

app.post('/test-results', (_request, response) => {
    if (!isAuthorized(_request)) {
        response.sendStatus(403);
        return
    }
    if (dbo) {
        data = parseRequest(_request, response)
        if (data) {
            dbo.collection('results').insertOne(data, function(err) {
                if (err) {
                    console.log('Failed to save result: ', err);
                    console.log(data)
                    response.sendStatus(500);
                    return;
                }
                response.sendStatus(204);
            });
        } else {
            response.sendStatus(400);
        }
    } else {
        console.log('DB not ready');
        response.sendStatus(503)
    }
});

function getFilter(request) {
    filter = {};
    client = request.query.client;
    if(client) {
        // Yes, bobby tables here
        filter = { client: { $eq: client } };
    }
    return filter;
}

app.get('/test-results', (_request, response) => {
    if (!isAuthorized(_request)) {
        response.sendStatus(403);
        return
    }
    if(dbo) {
        filter = getFilter(_request);
        dbo.collection('results').find(filter).toArray(function(err, data) {
            if (err) {
                console.log('DB find error: ', err);
                response.sendStatus(500);
                return
            }
            response.status(200).send(data)
        });
    } else {
        console.log('DB not ready');
        response.sendStatus(503)
        return
    }
});


const key  = fs.readFileSync('key.pem', 'utf8');
const cert = fs.readFileSync('cert.pem', 'utf8');

const options = {
    key: key,
    cert: cert
};

var https = require('https');
https.createServer(options, app).listen(port, (err) => {
    if (err) {
        console.log('Listen failed:', err)
        process.exit(1)
    }
    console.log(`Server is listening on ${port}`)
});
