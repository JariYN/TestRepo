# netq prod test API

## Build & publish

    cd srv
    npm install
    docker build --tag coheros/netq:netq-prod-test-api-<ver-number> .
    docker push coheros/netq:netq-prod-test-api-0.0.1

## Install (to AWS ubuntu)
Copy `docker-compose.yml` to `/home/ubuntu/netq-prod-test-api/.` and `netq-prod-api-service` to `/etc/systemd/system/.`

    sudo su
    systemctl daemon-reload
    systemctl enable netq-prod-api.service
    systemctl start netq-prod-api.service

Check that it started succesfully

    systemctl status netq-prod-api.service
    journalctl | grep docker-compose

## Usage
### Post new device tests

    curl --cacert cert.pem -X POST \
    -H "api-key:23fhsDF455HsgsDFRTbfht5nukllksddvs346grvsSse436geSDVhdsddv" \
    -H "Content-Type:application/json" \
    https://hansunapi.coherosscope.com/test-results \
    -d '{"client":"someapp","status":4,"mcuId":"5555","serialNumber":"asf43543","log":"Just testing"}'

### Query tests

    curl --cacert cert.pem \
    -H "api-key:23fhsDF455HsgsDFRTbfht5nukllksddvs346grvsSse436geSDVhdsddv" \
    https://hansunapi.coherosscope.com/test-results?client=someapp \
    | python -m json.tool

## Other
Generate new SSL keys to server some other domain

    openssl req -newkey rsa:2048 -nodes -keyout key.pem -x509 -days 1825 -out cert.pem
