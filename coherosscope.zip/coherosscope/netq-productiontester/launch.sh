#!/bin/bash
python3 src/main.py

