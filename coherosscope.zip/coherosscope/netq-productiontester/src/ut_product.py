import unittest
import os
import json
import shutil
from product import ProductLogger, Product

def generate_logs(path, count):
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(path)

    serial = 1000

    info = {}
    info[Product.KeyClient] = 'dummy'
    info[Product.KeySerial] = '0000'
    info[Product.KeyMcuid] = '1000'
    info[Product.KeyLog] = 'LED: OK\r\nLORA: OK\r\n'
    info[Product.KeyStatus] = 0

    while count:
        info[Product.KeySerial] = str(serial)
        filename = info[Product.KeySerial]
        with open(path + filename + '.log', "a+") as outfile:
            json.dump(info, outfile)
        count -= 1
        serial += 1

def remove_logs(path):
    if os.path.exists(path):
        shutil.rmtree(path)


class TestProductLogger(unittest.TestCase):

    def test__get_unsent_devices__no_devices(self):
        rest_uri = ''
        log_path = './' + ProductLogger.UNSENT_DIR
        logger = ProductLogger(rest_uri, './')

        expected_count = 0
        devices = logger.get_unsent_devices()
        self.assertEqual(expected_count, len(devices), 'device count')

        expected_count = 0
        generate_logs(log_path, expected_count)
        devices = logger.get_unsent_devices()
        self.assertEqual(expected_count, len(devices), 'device count')

        remove_logs(log_path)

    def test__get_unsent_devices__some_devices(self):
        rest_uri = ''
        log_path = './' + ProductLogger.UNSENT_DIR
        logger = ProductLogger(rest_uri, './')

        expected_count = 2
        generate_logs(log_path, expected_count)
        devices = logger.get_unsent_devices()
        self.assertEqual(expected_count, len(devices), 'device count')
        self.assertIn('1001', devices, 's/n of 1st device')
        self.assertIn('1000', devices, 's/n of 2st device')

        remove_logs(log_path)

    def test__get_unsend_logfiles__no_logs(self):
        rest_uri = ''
        log_path = './' + ProductLogger.UNSENT_DIR
        logger = ProductLogger(rest_uri, './')

        # no log folder
        expected_count = 0
        devices = logger.get_unsent_logfiles()
        self.assertEqual(expected_count, len(devices), 'logfile count (no log folder)')

        # no logs
        expected_count = 0
        generate_logs(log_path, expected_count)
        devices = logger.get_unsent_logfiles()
        self.assertEqual(expected_count, len(devices), 'logfile count (no logs)')

        remove_logs(log_path)

    def test__get_unsend_logfiles__some_logs(self):
        rest_uri = ''
        log_path = './' + ProductLogger.UNSENT_DIR
        logger = ProductLogger(rest_uri, './')

        # some logs
        expected_count = 2
        generate_logs(log_path, expected_count)

        files = logger.get_unsent_logfiles()
        self.assertEqual(expected_count, len(files), 'logfile count')
        self.assertIn(log_path+'1001.log', files, 'name of 1st logfile')
        self.assertIn(log_path+'1000.log', files, 'name of 2st logfile')

        remove_logs(log_path)


if __name__ == '__main__':
    unittest.main()
