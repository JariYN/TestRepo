import os, inspect, subprocess
from pyudev.pyqt5 import MonitorObserver
from pyudev import Context, Monitor
import ownui

class UsbObserver:
    def __init__(self):
        self.global_state = 0;
        self.mode = ""
        self.observer = None
        self.connected = False

    def startObs(self):
        context = Context()
        monitor = Monitor.from_netlink(context)
        monitor.filter_by(subsystem='usb')
        self.observer = MonitorObserver(monitor)
        self.observer.deviceEvent.connect(self.addUsbDevice)
        monitor.start()

    def addUsbDevice(self, device):
        if device.action == 'add':
            print('add')
            if device.device_number != 0:
                #new entry => wait next event
                self.global_state = 1
                return
            else:
                self.global_state += 1
                if self.global_state == 2:
                     if device.driver == "cdc_acm":
                         self.connected = True
                         self.mode = "ACM"
                     else:
                         self.connected = True
                         self.mode = "DFU"
                return
        if device.action == 'remove':
            self.connected = False
            self.mode = ''
            print('remove')

    def isConnected(self):
        return self.connected


def getConnectedDevice__():
    log('+'+inspect.stack()[0][3]+'()')
    #response = os.popen('ls -m /dev/ttyA*').read()
    ownui.log('execute "ls -m /dev/ttyA*"')
    process = subprocess.run('ls -m /dev/ttyA*', shell=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
    if process.returncode != 0:
        if process.returncode == 2:
            print('No ACM device => check DFU device existence')
        else:
            print(process.stderr.decode())
    response = process.stdout.decode()
    acmDevs = response.split(',')

    device = acmDevs[0].strip()
    if device == "":
        #response = os.popen('dfu-util -l').read()
        ownui.log('execute "dfu-util -l"')
        process = subprocess.run('dfu-util -l', shell=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        response = process.stdout.decode()
        for line in response.splitlines():
            if "Found DFU:" in line:
                device = 'DFU'
                break

    log('-'+inspect.stack()[0][3]+'() "{}"'.format(device))
    return device

def getConnectedDevice():
    ownui.log('+'+inspect.stack()[0][3]+'()')
    device = ''
    ownui.log('execute "dfu-util -l"')
    process = subprocess.run('dfu-util -l', shell=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
    response = process.stdout.decode()
    for line in response.splitlines():
        if "Found DFU:" in line:
            device = 'DFU'
            break

    if not device:
        ownui.log('execute "ls -m /dev/ttyA*"')
        process = subprocess.run('ls -m /dev/ttyA*', shell=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        if process.returncode != 0:
            if process.returncode == 2:
                print('No ACM device')
            else:
                print(process.stderr.decode())
        response = process.stdout.decode()
        acmDevs = response.split(',')

        device = acmDevs[0].strip()

    ownui.log('-'+inspect.stack()[0][3]+'() "{}"'.format(device))
    return device
