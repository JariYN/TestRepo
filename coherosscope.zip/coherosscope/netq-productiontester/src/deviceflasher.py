from PyQt5.QtWidgets import QMessageBox
import subprocess
import os
import shlex, serial, time
from PyQt5.QtCore import QThread,pyqtSignal
from usbobserver import getConnectedDevice
from pathlib import Path
import ownui

class FlashDeviceThr(QThread):
    flashReady = pyqtSignal(int, int, 'QString')
    flashFailed = pyqtSignal(int)
    flashProgress = pyqtSignal('QString', 'QString')

    def __init__(self, fwfiles):
        QThread.__init__(self)
        self.running = False

        #dfuUtilCmd = './dfu-util'
        #self.flashCmd = '{} -d 0483:df11 -a0 --dfuse-address=0x08000000:leave -D {}'.format(dfuUtilCmd, fwfile)
        self.fwfiles = fwfiles

    def __del__(self):
        self.wait()

    def run(self):
        self.running = True
        dfuUtilCmd = './dfu-util'
        dfuUtilFile = Path('./dfu-util')
        if not dfuUtilFile.exists():
            dfuUtilCmd = Path(os.path.basename(dfuUtilCmd))
        count = 0
        rawLine = ""
        addrs = ['0x08000000', '0x08010000']
        while self.running:
            count = 0
            for file in self.fwfiles:
                if count == 0:
                    option = 'mass-erase:force'
                if count == (len(self.fwfiles)-1):
                    option = 'leave'

                addr = addrs[count]

                flashCmd = '{} -d 0483:df11 -a0 --dfuse-address={}:{} -D {}'.format(dfuUtilCmd, addr, option, file)
                print(flashCmd)
                count = count + 1

                process = subprocess.Popen(shlex.split(flashCmd), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                #process = subprocess.Popen(self.flashCmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

                while True:
                    output = process.stdout.read(1)
                    rawLine += output.decode()
                    if output == b'' and process.poll() is not None:
                        break
                    if rawLine.count('%'):
                        mode = "Flashing"
                        if rawLine.count('Erase'):
                            mode = 'Erasing'
                        start = rawLine.find(']')+1
                        end = rawLine.find('%', start)+1
                        pros = rawLine[start:end]
                        self.flashProgress.emit(pros, mode)
                        rawLine = ''
            returncode = process.poll()
            if returncode != 0:
                count += 1
                #print(process.stderr.read().decode())
                self.flashReady.emit(returncode, count, process.stderr.read().decode())
            else:
                self.flashReady.emit(returncode, count, 'SUCCESS')
                break;

    """
    def run(self):
        self.running = True
        count = 0
        flashCmd = "dfu-util -d 0483:df11 -a0 --dfuse-address=0x08000000:leave -D" + self.fwFile

        #cmd="ls mo"
        while self.running:
            response = subprocess.run(shlex.split(flashCmd))
            if response.returncode != 0:
                count += 1
                self.flashReady.emit(response.returncode, count)
            else:
                self.waitAcmMode()
                self.flashReady.emit(response.returncode, count)
                break;
    """

    def stopFlashing(self):
        self.running = False

def waitAcmMode():
    count = 0
    while count < 3:
        #response = subprocess.run('ls -m /dev/ttyA3*', shell=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        #response = subprocess.run('ls /dev/ttyA*', shell=True, stderr)
        #response = os.popen('ls /dev/ttyA*').read()
        response = subprocess.run('ls /dev/ttyA*', shell=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        if response.returncode != 0:
            time.sleep(1)
            count += 1
        else:
            return True
    return False


def setToFlashMode(dev):
    ownui.log('+setToFlashMode()')
    found = False
    #count = 0
    time.sleep(0.5)
    dev = getConnectedDevice()
    if dev == 'DFU':
        return True

    count = 0
    while dev.find('ACM') > 0:
        count = count + 1
        if count == 3:
            break
        try:
            serialport = serial.Serial(dev, timeout=1) # TODO handle exception
            ownui.log('send "FLASHMODE" > {}'.format(dev))
            serialport.write(b'FLASHMODE')
            time.sleep(1)
            dev = getConnectedDevice()
            if  dev == "DFU":
                found = True
            else:
                time.sleep(1)
            serialport.close()
        except:
            pass

    ownui.log('-setToFlashMode() {}'.format(found))
    return found

"""
    def run(self):
        import time
        status = 1
        self.running = True
        count = 0
        while self.running:
            time.sleep(0.5)
            if count < 10:
                count += 1
                self.flashReady.emit(status, count)
            else:
                status = 1
                self.flashReady.emit(status, count)
                break;
"""

