import os
import sys
from PyQt5 import QtWidgets
from ownui import Window


if __name__ == "__main__":

    if not getattr(sys, 'frozen', False):
        # application is not bundled with pyinstaller
        # ensure working directory is one dir before location of this file
        os.chdir(os.path.dirname(os.path.realpath(__file__))+'/..')
    app = QtWidgets.QApplication(sys.argv)
    ui = Window()
    ui.initApp()

    ui.show()
    ret = app.exec_()

    sys.exit(ret)
