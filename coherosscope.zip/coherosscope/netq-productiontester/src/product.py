import os, sys
import json, requests
import serial
import time
import shutil
from PyQt5.QtCore import QThread,pyqtSignal, QObject
from _version import __version__

lowReferenceVoltage = 3000 #mV
highReferenceVoltage = 4500 #mV



class Product(QObject):
    testStatus = pyqtSignal('QString', 'QString', 'QString')

    KeyClient = 'client'
    KeySerial = 'serialNumber'
    KeyMcuid  = 'mcuId'
    KeyLog    = 'log'
    KeyStatus = 'status'

    def __init__(self, serial):
        super(Product, self).__init__()
        self.info = {}
        self.info[Product.KeyClient] = __version__
        self.info[Product.KeySerial] = serial
        self.info[Product.KeyMcuid] = ''
        self.info[Product.KeyLog] = ''
        self.info[Product.KeyStatus] = 1

        self.deviceNode = ""
        self.readerThr = ReadDeviceThr()

    def __del__(self):
        self.readerThr.wait(2000) #wait 2s

    def setDeviceNode(self, deviceNode):
        self.deviceNode = deviceNode

    def startTestObserver(self):
        print('startTestObserver')
        if self.deviceNode == '':
            return False
        self.readerThr.setDeviceNode(self.deviceNode)
        self.readerThr.dataReady.connect(self.deviceResponse)
        self.readerThr.start()
        return True

    def stopObserver(self):
        print('stopObserver')
        self.readerThr.stop()

    def setPassed(self):
        self.info[Product.KeyStatus] = 0

    def setFailed(self, status = 1):
        self.info[Product.KeyStatus] = status

    def isPassed(self):
        return self.info[Product.KeyStatus] == 0

    def deviceResponse(self, line):
        mut = ''
        status = 'OK'
        detail = ''
        if line != '':# and (line.count('OK') or line.count('FAIL')):
            if line.count('LORA'):
                mut = 'LORA'
            elif line.count('LED'):
                mut = 'LED'
            elif line.count('BUTTON'):
                mut = 'BUTTON'
            elif line.count("GSM"):
                mut = 'GSM'
            elif line.count("IMU"):
                mut = 'IMU'
            elif line.count("GPS"):
                mut = 'GPS'
            elif line.count("BATNC"):
                mut = 'BATNC'
            elif line.count("USBDET"):
                mut = 'USBDET'
            elif line.count("BATCHG"):
                mut = 'BATCHG'
                detail = line.split(',', 1)[1].strip()
                voltage = int(detail.strip('mV'))
                if voltage < lowReferenceVoltage or voltage > highReferenceVoltage:
                    line = line.replace('OK', 'FAIL')

            elif line.count("CHGDET"):
                mut = 'CHGDET'
            elif line.count("MCUID"):
                mut = 'MCUID'
                detail = line.split(':')[1].strip()
                self.addMcuid(detail)
            if line.count('FAIL'):
                status = 'FAIL'
                detail = line.split(',', 1)[1].strip()

            self.addTestStep(line)
            if mut != '':
                self.testStatus.emit(mut, status, detail)
            else:
                print(line)

    def addMcuid(self, mcuid):
        self.info[Product.KeyMcuid] = mcuid

    def addTestStep(self, logLine):
        if logLine.count('FAIL'):
            self.setFailed()
        self.info['log'] += logLine+'\r\n'

    def getSerial(self):
        return self.info[Product.KeySerial]

    def getData(self):
        return self.info


class ProductLogger():
    FAIL_DIR = 'fail/'  # local directory for log files with 'fail' status
    UNSENT_DIR = 'unsent/'  # local backup directory for unsent log files
    RESENT_COUNT = 2

    def __init__(self, rest_api_uri, logPath):
        self.log_rest_api_uri = rest_api_uri
        self.log_local_path = logPath
        self.thr = None

    def post_json(self, json_string):
        status = {}
        key = os.environ['API_KEY_AUTH']
        headers = {
            'api-key': key
        }
        resp = requests.post(self.log_rest_api_uri, json=json.dumps(json_string), headers=headers, verify=False)
        status['http_status'] = resp.status_code
        if 200 <= resp.status_code <= 230:
            status['success'] = 1
        else:
            status['success'] = 0

        print('HTTP status: {}'.format(status['http_status']))  # TODO: remove unnecessary prints
        return status

    def log(self, product):
        # write to cloud
        logging_status = True
        subfolder = ''

        if not product.isPassed():
            subfolder = self.FAIL_DIR

        if self.log_rest_api_uri != "":
            tries_left = self.RESENT_COUNT + 1
            result_in_cloud = False
            status = {}
            while tries_left:
                tries_left -= 1
                try:
                    status = self.post_json(product.getData())
                except:
                    print('no internet connection?')
                else:
                    if status['success']:
                        result_in_cloud = True
                        break
                time.sleep(.500)

            if not result_in_cloud:
                if product.isPassed():
                    # write to unsent folder to wait further resents
                    subfolder = self.UNSENT_DIR
                    logging_status = False
                else:
                    product.addTestStep('connection failure, resp.status_code={}'.format(status['http_status']))

        print(json.dumps(product.info))  # TODO: remove unnecessary prints

        # write to file
        filename = product.getSerial()
        directory = self.log_local_path + subfolder
        if not os.path.exists(directory):
            os.makedirs(directory)
        print(directory+filename+'.log')  # TODO: remove unnecessary prints
        logfile = open(directory+filename+'.log', "w")
        logfile.write(json.dumps(product.info)+'\r\n')
        logfile.close()

        return logging_status

    def get_unsent_devices(self):
        unsent_list = []
        for file in self.get_unsent_logfiles():
            unsent_list.append(os.path.basename(os.path.splitext(file)[0]))
        return unsent_list

    def get_unsent_logfiles(self):
        unsent_list = []
        directory = self.log_local_path + self.UNSENT_DIR

        if os.path.exists(directory):
            for f in os.listdir(directory):
                if os.path.isfile(os.path.join(directory, f)):
                    unsent_list.append(directory+f)
        return unsent_list

    def post_unsent_logs(self, callback):
        self.thr = LogFileSenderThr(self.get_unsent_logfiles(), self.post_json)
        self.thr.logSent.connect(callback)
        self.thr.start()

    def get_log_full_path(self):
        return os.getcwd() + '/' + self.log_local_path + self.UNSENT_DIR

class LogFileSenderThr(QThread):
    logSent = pyqtSignal('QString')

    def __init__(self, logfiles, func):
        QThread.__init__(self)
        self.logfiles = logfiles
        self.post_json = func

    def __del__(self):
        self.wait()

    def run(self):
        for file in self.logfiles:
            self.post_json_file(file)
        self.logSent.emit('')

    def post_json_file(self, log_filename):
        with open(log_filename) as json_file:
            try:
                json_data = json.load(json_file)
            except json.JSONDecodeError as e:
                print("File: {}, JSONDecodeError: {}".format(log_filename, e.msg))
            except:
                print("Unexpected error:", sys.exc_info()[0])
                raise
            else:
                status = self.post_json(json_data)
                if status['success']:
                    self.logSent.emit(os.path.splitext(os.path.basename(log_filename))[0])
                    os.remove(log_filename)
                    if not os.listdir(os.path.dirname(log_filename)):
                        shutil.rmtree(os.path.dirname(log_filename))


def writeStickerInfo(path, stickerData, sticker, printer):
    script = '%BTW% /AF="{}" /D=%Trigger File Name% /PRN="{}" /R=3 /P /DD\r\n%END%\r\n{}'.format(sticker, printer, stickerData)
    extension = ".hn1"
    bartenderfile = open(path + stickerData + extension, "w")
    bartenderfile.write(script)
    bartenderfile.close()


class ReadDeviceThr(QThread):
    dataReady = pyqtSignal('QString')

    def __init__(self):
        QThread.__init__(self)
        self.read = False
        self.dev = ''

    def __del__(self):
        self.wait()
    """
    def run(self):
        import time
        self.read = True
        outputStrs = ['IMU;OK', 'MCU;OK', 'DONE']
        for outputStr in outputStrs:
            if self.read == False:
                break;
            self.dataReady.emit(outputStr)
            time.sleep(0.5)
    """
    def setDeviceNode(self, deviceNode):
        self.dev = deviceNode

    def run(self):
        self.read = True
        outputCharacters = ""
        serialport = serial.Serial(self.dev, timeout=1)
        while self.read:
            try:
                ch = serialport.read(1)
                if len(ch) > 0:
                    outputCharacters += ch.decode()
                    if outputCharacters.count('\n'):
                        outputCharacters = outputCharacters.strip('\n')
                        outputCharacters = outputCharacters.strip('\r')
                        self.dataReady.emit(outputCharacters)
                        outputCharacters = ''
            except serial.SerialException:
                if self.read: #print only if thread is not going to stop
                    print('exception during read') #TODO handle this exception
                time.sleep(0.2)

    def stop(self):
        self.read = False
