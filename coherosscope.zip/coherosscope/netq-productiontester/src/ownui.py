import configparser, sys, pyudev
import time
from pathlib import Path
from PyQt5 import uic
from PyQt5.QtWidgets import QMessageBox, QMainWindow, QWidget
from enum import Enum
from PyQt5.QtCore import QRegExp, QTimer, Qt, QEventLoop, pyqtSignal
from PyQt5.QtGui import QRegExpValidator, QValidator

from product import Product
from usbobserver import UsbObserver, getConnectedDevice
from product import writeStickerInfo, ProductLogger
from deviceflasher import FlashDeviceThr, setToFlashMode, waitAcmMode
from _version import __version__

defStickerPath = "./"

txtWeirdHappens = '...but there is something weird going on.\n' \
                  'Seems that device in not able to continue  automatically\n' \
                  'You should disconnect and reconnect USB-C cable.\n' \
                  'If problem persists, click <Abort>' \
                  '\n' \
                  'Using external USB hub might help'

txtSerialInstructions = '1. Connect USB-C cable to device under test\n' \
                        '   (battery shall not be inserted)\n\n' \
                        '2. Scan serial number to text field (is number is valid flashing starts automatically)\n' \
                        '   (if serial number is typed manually you need to press <ENTER> or click <START TEST> button)'

txtFlashInstructions = '1. Wait for flashing to be completed\n\n' \
                       '2. If flashing fails repeatedly, click <ABORT> button'

txtTestInstructions = '1. Insert battery after "insert battery" text appears inside CHGDET rectangle\n\n' \
                      '2. Press once device power button after "press button" text appears inside BUTTON box\n\n' \
                      '3. Wait for (max 1min) the tests to be completed (color of all rectangles are red or green)\n' \
                      '   (click <ABORT> button to stop testing phase)'

txtStatusInstructions = '1. Disconnect USB-C cable\n\n' \
                        '2. Press power button (1s-2s) until leds turns from white to green/yellow\n\n' \
                        '3. Target is to turn leds off\n\n' \
                        '   a. Press power button (1s-13s) until leds turns off or makes short (0.3s) flash \n\n' \
                        '   b. If leds just flashes repeat step a\n\n' \
                        '4. Click <NEXT DEVICE> button\n\n' \
                        'BONUS TASK: If list of unreported devices are shown please try to resend those by clicking ' \
                        '<RESEND> button'



class AppState(Enum):
    ENTER_SERIAL = 1
    FLASHING_TEST_FW = 2
    FLASHING_REAL_FW = 3
    TEST_FW_RUNNING = 4
    ABORT_FLASH = 5
    SHOW_FINAL_STATUS = 6


class Window(QMainWindow):
    can_quit = pyqtSignal()

    def __init__(self):
        QWidget.__init__(self)
        uic.loadUi("qtproject/mainwindow.ui", self)

    def initApp(self):
        self.state = AppState.ENTER_SERIAL
        self.previousState = None
        self.but = None
        self.stickerPath = ""
        self.passedButCount = 0
        #self.obs = UsbObserver()
        #self.obs.startObs()
        self.btnStopTesting.setText('ABORT')
        self.groupUnreported.setVisible(False)

        self.testLabels = {}
        self.testLabels['LORA'] = [self.lblTestLora, self.lblTestLoraDetail, self.frmTestLora, None]
        self.testLabels['IMU'] = [self.lblTestImu, self.lblTestImuDetail, self.frmTestImu, None]
        self.testLabels['GPS'] = [self.lblTestGps, self.lblTestGpsDetail, self.frmTestGps, None]
        self.testLabels['GSM'] = [self.lblTestGsm, self.lblTestGsmDetail, self.frmTestGsm, None]
        self.testLabels['MCUID'] = [self.lblTestMcuid, self.lblTestMcuidDetail, self.frmTestMcuid, None]
        self.testLabels['BATNC'] = [self.lblTestBatnc, self.lblTestBatncDetail, self.frmTestBatnc, None]
        self.testLabels['USBDET'] = [self.lblTestUsbdet, self.lblTestUsbdetDetail, self.frmTestUsbdet, None]
        self.testLabels['BATCHG'] = [self.lblTestBatchg, self.lblTestBatchgDetail, self.frmTestBatchg, None]
        self.testLabels['CHGDET'] = [self.lblTestChgdet, self.lblTestChgdetDetail, self.frmTestChgdet, None]
        self.testLabels['LED'] = [self.lblTestLed, self.lblTestLedDetail, self.frmTestLed, None]
        self.testLabels['BUTTON'] = [self.lblTestButton, self.lblTestButtonDetail, self.frmTestButton, None]

        self.initTestStatus()

        self.lblTestInstructions.setText(txtTestInstructions)
        self.lblSerialInstructions.setText(txtSerialInstructions)
        self.lblStatusInstructions.setText(txtStatusInstructions)
        self.label_3.setText(txtFlashInstructions)

        self.timerButton = QTimer()
        self.timerChgdet = QTimer()

        self.actionAbout = self.menuBar.addAction("About")

        #connect signals
        self.btnStopTesting.clicked.connect(self.stopTesting)
        self.btnEndFlash.clicked.connect(self.abortFlash)
        self.entrySerial.returnPressed.connect(self.serialReady)
        self.btnContSerial.clicked.connect(self.serialReady)
        self.timerButton.timeout.connect(self.blinkButton)
        self.timerChgdet.timeout.connect(self.blinkChgdet)
        self.entrySerial.editingFinished.connect(self.serialEditFinished)
        self.actionAbout.triggered.connect(self.showAbout)
        self.btnResend.clicked.connect(self.resend)

        #serial validation
        ex = QRegExp('[0-9]{14}')
        self.validator = QRegExpValidator(ex)

        #self.entrySerial.setValidator(validator)

        #read ini file
        configFile = Path('config.ini')
        config = configparser.ConfigParser()
        if configFile.is_file() == False:
            config['DEFAULT'] = {'bartendermount': defStickerPath}
            with open(configFile.name, 'w') as configfile:
                config.write(configfile)
        else:
            config.read(configFile.name)
        self.stickerPath = config['DEFAULT']['bartendermount']

        stickerFile = Path(self.stickerPath)
        if not stickerFile.exists():
            self.stickerPath = defStickerPath

        try:
            logUrl = config['DEFAULT']['url']
        except KeyError:
            logUrl = ''
        logPath = config['DEFAULT']['logpath']
        try:
            self.testfw = config['DEFAULT']['testfw'].split()
            if len(self.testfw) == 0:
                self.testfw = ['']
        except KeyError:
            self.testfw = ['']
        try:
            self.realfw = config['DEFAULT']['realfw'].split()
            if len(self.realfw) == 0:
                self.realfw = ['']
        except KeyError:
            self.realfw = ['']
        self.bartenderLabel = config['XORTEC']['label']
        self.bartenderPrinter = config['XORTEC']['printer']

        testFwFile = Path(self.testfw[0])
        realFwFile = Path(self.realfw[0]) #TODO check all files in list
        if not testFwFile.exists():
            msgBox = QMessageBox()
            msgBox.setIcon(QMessageBox.Information)
            msgBox.setWindowTitle('Testing fw not found')
            msgBox.setText('File: {} does not exist.'.format(self.testfw[0]))
            msgBox.setInformativeText('Check "testfw" entry from config.ini')
            msgBox.setStandardButtons(QMessageBox.Abort)
            msgBox.setDefaultButton(QMessageBox.Abort)
            msgBox.exec()
            sys.exit(1)
        if not realFwFile.exists():
            msgBox = QMessageBox()
            msgBox.setIcon(QMessageBox.Information)
            msgBox.setWindowTitle('Real fw not found')
            msgBox.setText('File: {} does not exist.'.format(self.realfw[0]))
            msgBox.setInformativeText('Check "realfw" entry from config.ini\r\nLeave empty if real fw is not needed.')
            msgBox.setStandardButtons(QMessageBox.Abort)
            msgBox.setDefaultButton(QMessageBox.Abort)
            msgBox.exec()
            sys.exit(1)

        self.butLogger = ProductLogger(logUrl, logPath)

    def splitResponse(self, line):
        return line.split(';')

    def isValidLine(self, line):
        splittedLine = self.splitResponse(line)
        return len(splittedLine) >= 2

    def isTestingReady(self, line):
        if line.count('GSM') > 0:
            return True
        else:
            return False

    def readyToNextBoard(self):
        if self.but.isPassed():
            self.lblStatus.setStyleSheet('QLabel { color : green; }')
            self.lblStatus.setText('PASSED')
        else:
            self.lblStatus.setStyleSheet('QLabel { color : red; }')
            self.lblStatus.setText('FAILED')


        self.showUnsentDevices()

        self.stackedWidget.setCurrentWidget(self.pageStatus)
        self.statusBar.clearMessage()
        self.state = AppState.SHOW_FINAL_STATUS
        self.but = None
        self.btnNextDevice.clicked.connect(self.nextDevice)
        self.btnStopTesting.setText('ABORT')

    def nextDevice(self):
        self.state = AppState.ENTER_SERIAL
        self.entrySerial.clear()
        self.entrySerial.setFocus()
        self.txtFlash.clear()
        self.initTestStatus()
        self.stackedWidget.setCurrentWidget(self.pageSn)
        if self.listWidget.count() == 0:
            self.groupUnreported.setVisible(False)

    def blinkButton(self):
        if self.lblTestButtonDetail.isEnabled():
            self.lblTestButtonDetail.setEnabled(False)
        else:
            self.lblTestButtonDetail.setEnabled(True)

    def blinkChgdet(self):
        if self.lblTestChgdetDetail.isEnabled():
            self.lblTestChgdetDetail.setEnabled(False)
        else:
            self.lblTestChgdetDetail.setEnabled(True)

    def butTestStatus(self, mut, status, detail):
        # ≅
        lbl = self.testLabels[mut]

        if mut == 'BATNC':
            self.timerButton.start(500)
            self.timerChgdet.start(500)
            self.lblTestChgdetDetail.setText('insert battery')
            self.lblTestButtonDetail.setText('press button')
        if mut == 'BUTTON':
            self.lblTestButtonDetail.clear()
            self.timerButton.stop()
            self.lblTestButtonDetail.setEnabled(True)
        if mut == 'CHGDET':
            self.lblTestChgdetDetail.clear()
            self.timerChgdet.stop()
            self.lblTestChgdetDetail.setEnabled(True)

        if status == 'OK':
            lbl[2].setStyleSheet("background-color: green")
            lbl[3] = True
        else:
            lbl[2].setStyleSheet("background-color: red")
            lbl[3] = False

        if detail != '':
            lbl[1].setText(detail)

        self.updateStatus()

    def updateStatus(self):
        okCount = 0
        expectMore = False
        for key, label in self.testLabels.items():
            if label[3] == True:
                okCount += 1
            elif label[3] == None:
                expectMore = True
        if okCount == len(self.testLabels):
            self.but.setPassed()
            self.btnStopTesting.setStyleSheet("background-color: green");
            self.btnStopTesting.setText('CONTINUE')
            self.stopTesting()
        else:
            self.but.setFailed()
            self.btnStopTesting.setStyleSheet("background-color: red");
            if not expectMore:
                self.btnStopTesting.setText('CONTINUE')

    def stopTesting(self):
        self.but.stopObserver()
        if self.realfw[0] == '' or not self.but.isPassed():
            self.write_device_log()
            self.readyToNextBoard()
        else:
            # start flashing real fw
            self.state = AppState.FLASHING_REAL_FW
            time.sleep(.3)
            if self.prepareDeviceForFlashing():
                self.startFlashing()

    def abortFlash(self):
        self.devFlasher.stopFlashing()
        self.previousState = self.state
        self.state = AppState.ABORT_FLASH

    def startFlashing(self):
        log('+startFlashing()')
        self.statusBar.showMessage("Flashing...")
        """
        mode = 'app in wrong state: {}'.format(self.state)
        if self.state == AppState.FLASHING_REAL_FW:
            mode = 'Flashing real firmware...'
        elif self.state == AppState.FLASHING_TEST_FW:
            mode = 'Flashing test firmware...'
        self.txtFlash.setText(mode)
        """
        self.stackedWidget.setCurrentWidget(self.pageFlash)

        # start flashing thread
        if self.state == AppState.FLASHING_REAL_FW:
            self.devFlasher = FlashDeviceThr(self.realfw)
        else:
            self.devFlasher = FlashDeviceThr(self.testfw)
        self.devFlasher.flashReady.connect(self.flashResponse)
        self.devFlasher.flashProgress.connect(self.flashProgress)
        self.devFlasher.start()
        log('-startFlashing()')

    def flashProgress(self, progress, mode):
        self.statusBar.showMessage('{}...{}'.format(mode, progress))
        self.txtFlash.setText('{}...{}'.format(mode, progress))

    def flashResponse(self, status, retries, stderr):
        self.txtFlash.append(stderr)
        if status != 0:
            #flash failed
            self.txtFlash.append('Failed!  Retry #{}'.format(retries))
            #self.statusBar.showMessage("Flashing...failed!  Retry #"+str(retries))

            if self.state == AppState.ABORT_FLASH:
                #no success in flashing => abort testing
                if self.previousState == AppState.FLASHING_REAL_FW:
                    firmware = 'test fw'
                elif self.previousState == AppState.FLASHING_TEST_FW:
                    firmware = 'real fw'
                self.but.addTestStep('{} flashing: FAIL retries: {}'.format(firmware, retries))
                self.write_device_log()
                self.readyToNextBoard()
        else:
            self.statusBar.showMessage("Flash OK!")
            if self.state == AppState.ABORT_FLASH:
                self.state = self.previousState

            if self.state == AppState.FLASHING_TEST_FW:
                #check ACM
                count = 1
                while count:
                    time.sleep(.5)
                    if not waitAcmMode():
                        count -= 1
                    else:
                        break

                if not count:
                    self.txtFlash.append(txtWeirdHappens)
                    self.txtFlash.repaint()

                    context = pyudev.Context()
                    monitor = pyudev.Monitor.from_netlink(context)
                    monitor.filter_by(subsystem='usb')
                    found = False
                    count = 0
                    while not found:
                        devices = monitor.poll
                        for device in iter(devices, None):
                            if device.action == 'add':
                                print('add')
                                count += 1
                                if count == 3:
                                    found = True
                                    break
                            if device.action == 'remove':
                                count = 0
                                print('remove')


                self.state = AppState.TEST_FW_RUNNING
                self.btnStopTesting.setStyleSheet("background-color: red");
                self.stackedWidget.setCurrentWidget(self.pageTest)
                self.statusBar.clearMessage()

                #device starts executing tests
                # start serial reading thread
                self.but.setDeviceNode(getConnectedDevice())
                self.but.startTestObserver()
                self.but.testStatus.connect(self.butTestStatus)
            elif self.state == AppState.FLASHING_REAL_FW:
                self.write_device_log()
                self.readyToNextBoard()
            else:
                print('Wrong state: {}'.format(self.state))

    """
    def flashRetry(self, retries):
        self.statusBar.showMessage("Flashing...failed!  Retry #"+str(retries))
    """
    def serialEditFinished(self):
        serialNumber = self.entrySerial.displayText()
        val = self.validator.validate(serialNumber,0)
        if val[0] != QValidator.Acceptable:
            self.entrySerial.clear()
            self.entrySerial.setFocus()

    def serialReady(self):
        serialNumber = self.entrySerial.displayText()
        val = self.validator.validate(serialNumber,0)
        if val[0] == QValidator.Acceptable:
            if self.but == None: #serialNumber != self.but.getSerial():
                log('New device {}'.format(serialNumber))
                self.but = Product(self.entrySerial.displayText())
                writeStickerInfo(self.stickerPath, serialNumber, self.bartenderLabel, self.bartenderPrinter)
            else:
                log('Retry previous device {}'.format(serialNumber))


            dev = self.waitDeviceConnect()
            if dev != "":
                isFlashMode = True
                #dev is DFU or /dev/ttyACMx
                if dev != "DFU":

                    isFlashMode = self.prepareDeviceForFlashing()

                if isFlashMode:
                    #start flashing
                    self.state = AppState.FLASHING_TEST_FW
                    time.sleep(0.5)
                    self.startFlashing()
        else:
            self.entrySerial.clear()
            self.entrySerial.setFocus()

    def waitDeviceConnect(self):
        dev = ''
        while dev == '':
            dev = getConnectedDevice()
            if dev == '':
                # no device
                msgBox = QMessageBox()
                msgBox.setWindowTitle('Connection failure')
                msgBox.setText(
                    'Disconnect and reconnect USB-C cable and click <Retry>')
                msgBox.setInformativeText('If problem persist, click <Abort>')
                msgBox.setStandardButtons(QMessageBox.Abort | QMessageBox.Retry)
                msgBox.setIcon(QMessageBox.Critical)
                returnValue = msgBox.exec()

                if returnValue == QMessageBox.Abort:
                    self.but.addTestStep('USB power: FAIL')
                    self.write_device_log()
                    self.readyToNextBoard()
                    break
        return dev

    def prepareDeviceForFlashing(self):
        dev = ''
        while True:
            isFlashMode = setToFlashMode(dev)

            if isFlashMode:
                break
            else:
                # unable to put device to flash mode
                msgBox = QMessageBox()
                msgBox.setWindowTitle('Fail')
                msgBox.setText('Unable to set device to flash mode.')
                msgBox.setInformativeText('1. Remove battery if inserted\n' \
                                          '2. Disconnect and reconnect USB-C cable\n' \
                                          '3. Click <Retry>\n4. Reinsert battery if it was inserted in step 1\n' \
                                          '\n' \
                                          'If problem persist, click <Abort> to start with new device.')
                msgBox.setStandardButtons(QMessageBox.Abort | QMessageBox.Retry)
                returnValue = msgBox.exec()
                if returnValue == QMessageBox.Abort:
                    self.but.addTestStep('flashmode: FAIL')
                    self.write_device_log()
                    self.readyToNextBoard()
                    break
        return isFlashMode

    def initTestStatus(self):
        for key, label in self.testLabels.items():
            label[0].setStyleSheet('QLabel { color : black; }')
            if key == 'BATCHG':
                label[1].setText('----mV')
            else:
                label[1].clear()
            label[2].setStyleSheet('background-color: white')
            label[3] = None

        self.btnStopTesting.setStyleSheet('background-color: gray');
        self.lblStatus.setText('N/A')
        self.lblStatus.setStyleSheet('QLabel { color : gray; }')

    def showUnsentDevices(self):
        # check existence of unsent reports (devices)
        unsent_devices = self.butLogger.get_unsent_devices()
        if len(unsent_devices):
            self.groupUnreported.setVisible(True)
            self.btnResend.setEnabled(True)
            for device in unsent_devices:
                if len(self.listWidget.findItems(device, Qt.MatchFlag.MatchExactly)) == 0:
                    self.listWidget.addItem(device)
        else:
            self.groupUnreported.setVisible(False)

    def showAbout(self):
        str = "GUI for NETQ production testing ({})\r\n" \
              "Copyright © 2018 Coheros Oy\r\n" \
              "\r\n" \
              "Used open source APIs:\r\n" \
              " QT (Copyright © The Qt Company)\r\n" \
              " PyQt5 (Copyright © 2018 Riverbank Computing Limited <info@riverbankcomputing.com>)\r\n" \
              " pySerial (Copyright © 2001-2016 Chris Liechti <cliechti@gmx.net>)\r\n" \
              " pyudev (Copyright © 2011 Sebastian Wiesner <lunaryorn@gmail.com>)\r\n" \
              " requests (Copyright © 2018 Kenneth Reitz)".format(__version__)

        msgBox = QMessageBox()
        msgBox.setWindowTitle('About')
        msgBox.setStyleSheet("QLabel{min-width: 700px;}");
        msgBox.setText(str)
        msgBox.setDefaultButton(QMessageBox.Ok)
        msgBox.exec()

    def resend(self):
        self.btnResend.setEnabled(False)
        self.butLogger.post_unsent_logs(self.logged_device)

    def logged_device(self, device):
        if device == '':
            self.can_quit.emit()
            if self.listWidget.count() == 0:
                self.btnResend.setEnabled(False)
            else:
                self.btnResend.setEnabled(True)
        else:
            items = self.listWidget.findItems(device, Qt.MatchFlag.MatchExactly)
            for item in items:
                self.listWidget.takeItem(self.listWidget.row(item))

    def write_device_log(self):
        if not self.butLogger.log(self.but):
            msgBox = QMessageBox()
            msgBox.setWindowTitle('Connection failure')
            msgBox.setText('Device {} data\r\nnot written to cloud'.format(self.but.getSerial()))
            msgBox.setDetailedText('Is internet connection broken?\r\n\r\nYou could retry by clicking <RESEND> button '
                                   'on next screen.')
            msgBox.setDefaultButton(QMessageBox.Ok)
            msgBox.exec()

    def closeEvent(self, event):
        loop = QEventLoop()
        self.can_quit.connect(loop.quit)
        self.butLogger.post_unsent_logs(self.logged_device)
        # prevent to window close before files are sent
        loop.exec_()  # Execution stops here until finished called

        # notify user if there are unsent logs still
        if len(self.butLogger.get_unsent_devices()) > 0:
            msgBox = QMessageBox()
            msgBox.setWindowTitle('Connection failure')
            msgBox.setText('There are some reports still in folder\r\n{}'.format(self.butLogger.get_log_full_path()))
            msgBox.setDetailedText("Is internet connection broken?\r\n\r\nYou can try to send those later by opening "
                                   "and closing this application.\r\nIf that doesn't help please email "
                                   "files to Coheros.")
            msgBox.setDefaultButton(QMessageBox.Ok)
            msgBox.exec()


def log(line):
    pass
    #print(line)


def calculateAverage(vol):
    count = 0
    avg = 0
    for s in vol:
        if s != None:
            avg += s
            count += 1
        else:
            break
    avg = int(avg / count)
    return avg
