import serial
from PyQt5.QtCore import QThread,pyqtSignal




'''
            serialPort = serial.Serial('/dev/ttyACM0', timeout=1)
            while 1:
                ch = serialPort.read()
                self.txtFlash.setText(ch.decode())
            serialPort.close()
'''