"use strict";

const port = 3000;
const dbHost = process.env.npm_package_config_dbhost;

const maxInteger = 2147483647;

console.log("***");
console.log("*** dbHost:", dbHost);
console.log("***");

const express = require('express');
const bodyParser = require('body-parser');
const http = require('http');
const elasticsearch = require('elasticsearch');
const deviceData = require('./device-data');

const app = express();

const getDbIndexFromRequest = (req) => {
  return `data_${req.subdomains[0]}`;
};


app.listen(port, () => {
    console.log('RESTful API server started on: ' + port);
});

const textParser = bodyParser.text({ type: '*/*' });
const rawParser = bodyParser.raw({ type: 'application/octet-stream' });


import { Client, SearchResponse, UpdateDocumentParams } from "elasticsearch";


const es: Client = new elasticsearch.Client({
    host: dbHost + ':9200'
});
/**
 * Log Elasticsearch errors
 * @param {*} err
 * @param {*} rsp
 */
function logElasticError(err, rsp?) {
    if (typeof err != 'undefined') {
        console.trace(err);
        console.log("Response: " + rsp);
    }
}

/**
 * Store raw, all received, data to Elasticsearch
 * @param {*} data
 */
function storeRawData(data, pathName: string) {

    var options = {
        hostname: dbHost,
        port: 9200,
        path: `/raw/${pathName}/doc`,
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    };

    var req = http.request(options, function (res) {
        //console.log('Status: ' + res.statusCode);
        //console.log('Headers: ' + JSON.stringify(res.headers));
        res.setEncoding('utf8');
        res.on('data', function (body) {
            //console.log('Body: ' + body);
        });
    });

    req.on('error', function (e) {
        console.log('Error: ' + e.message);
    });
    req.write(data);
    req.end();

}

function decorateMsg(data: deviceDataUL | deviceDataDL, jsonData, dbIndex: string) {
    if (jsonData.gps.motion) {
        data.device_ground_speed = jsonData.gps.motion.gSpeed;
        data.device_ground_speed_accuracy = Math.min(jsonData.gps.motion.sAcc, maxInteger);
    }

    if (jsonData.isManual) {
        data.special_mea_type = 'manual';
        data.special_mea_id = jsonData.manualMeaId;
    }

    if (jsonData.spreadingFactor != 0) {
        data.device_sf = jsonData.spreadingFactor;
    }
    push2query(data, dbIndex)
}
/**
 * Handle POST /device/pb/
 * Data is binary, formatted as
 *      <len1><protobuf data1><len2><protobuf data2>...
 */
app.post('/device/pb/', rawParser, (req, res) => {
    console.log('post /device/pb/');
    if (!req.body) return res.sendStatus(400);

    const dbIndex = getDbIndexFromRequest(req);
    // TODO: check if device belongs to owner of dbIndex

    //console.log("*** input device pb ***");
    res.send('');

    const buf = new deviceData.Buffer(req.body);

    for (let msg of buf.messages()) {
        const jsonData = msg.toObject();

        //console.log("JSON to db:", JSON.stringify(jsonData, null, 4));

        const rawData = JSON.stringify(jsonData, null, 4);
        storeRawData(rawData, dbIndex);
        if (msg.isValid()) {
            if (!jsonData.isDownlink) {
                const data: deviceDataUL = {
                    direction: 'ul',
                    cloud_time: new Date(),
                    dev_eui: jsonData.devEui,
                    mea_id: jsonData.meaId,
                    device_time: jsonData.deviceTime,
                    device_time_accuracy: Math.min(jsonData.gps.time.tAcc, maxInteger),
                    device_location: {
                        lon: jsonData.gps.lon,
                        lat: jsonData.gps.lat
                    },
                    device_location_accuracy: Math.min(jsonData.gps.hAcc, maxInteger),
                    dl: false
                }
                decorateMsg(<deviceDataUL>data, jsonData, dbIndex)
            } else {
                const data: deviceDataDL = {
                    direction: 'dl',
                    cloud_time: new Date(),
                    dev_eui: jsonData.devEui,
                    mea_id: jsonData.meaId,
                    device_time: jsonData.deviceTime,
                    device_time_accuracy: Math.min(jsonData.gps.time.tAcc, maxInteger),
                    device_location: {
                        lon: jsonData.gps.lon,
                        lat: jsonData.gps.lat
                    },
                    device_location_accuracy: Math.min(jsonData.gps.hAcc, maxInteger),
                    device_rssi: jsonData.dlRssi,
                    device_snr: jsonData.dlSnr
                }
                decorateMsg(<deviceDataDL>data, jsonData, dbIndex)
            }
        }
    }
});
function saveNetworkData(selected: elasticDeviceDataUL, networkData: networkDataUL) {
    return {
        network_time: networkData.network_time,
        network_rssi: networkData.network_rssi,
        network_snr: networkData.network_snr,
        network_lrrid: networkData.network_lrrid,
        network_location: networkData.network_location,
        network_lrrs: networkData.network_lrrs,
        network_sf: networkData.network_sf,
        network_lrr_count: networkData.network_lrr_count,
    };
}

function saveDeviceData(selected: elasticNetworkDataUL, deviceData: deviceDataUL) {
    return {
        device_time: deviceData.device_time,
        device_time_accuracy: deviceData.device_time_accuracy,
        device_location: deviceData.device_location,
        device_location_accuracy: deviceData.device_location_accuracy,
        device_ground_speed: deviceData.device_ground_speed,
        device_ground_speed_accuracy: deviceData.device_ground_speed_accuracy,
        special_mea_type: deviceData.special_mea_type,
        special_mea_id: deviceData.special_mea_id,
        device_sf: deviceData.device_sf
    };
}

let dataquery: (deviceDataUL | deviceDataDL | networkDataUL)[] = [];
let dataqueryPeak: number = 0
let dataPeakTime = new Date();
function push2query(item: deviceDataUL | deviceDataDL | networkDataUL, dbIndex: string): void {
    /* Push item to query and trigger query handling if query was empty */
    console.log('\x1b[36m%s\x1b[0m', 'Pushing item to query (Mea id: ' + item.mea_id + ', Direction: ' + item.direction + '). Query length is before push is ' + (dataquery.length) + ', Query peak was ' + dataqueryPeak + ' at ' + dataPeakTime.toLocaleString())
    if (dataquery.length + 1 > dataqueryPeak) {
        dataqueryPeak = dataquery.length + 1
        dataPeakTime = new Date();
    }
    if (dataquery.push(item) === 1) {
        saveData(dbIndex);
    } else if (dataquery.length > 10000) {
        console.log('There is a stuck in query, printing stucked item:');
        console.log(dataquery[0]);
    }
}
function isDeviceDataUL(toBeDetermined: any): toBeDetermined is deviceDataUL {
    if ((toBeDetermined as deviceDataUL).device_time && !(toBeDetermined as any).network_time && (toBeDetermined as deviceDataUL).direction === 'ul') {
        return true
    }
    return false
}
function isnetworkDataUL(toBeDetermined: any): toBeDetermined is networkDataUL {
    if ((toBeDetermined as networkDataUL).network_time && (toBeDetermined as networkDataUL).direction === 'ul') {
        return true
    }
    return false
}
function isDeviceDataDL(toBeDetermined: any): toBeDetermined is deviceDataDL {
    if ((toBeDetermined as deviceDataDL).device_time && !(toBeDetermined as any).network_time && (toBeDetermined as deviceDataDL).direction == 'dl') {
        return true
    }
    return false
}
let needRefresh: boolean = false;
async function updateIndex(dbIndex : string) {
    if (needRefresh) {
        await es.indices.refresh({ index: dbIndex });
        console.log(':::::::::::::::::::::::::DATAINDEX REFRESHED! :::::::::::::::::::::')
        needRefresh = false;
    }
}
async function eliminateDuplicate(data: (deviceDataUL | deviceDataDL | networkDataUL), dbIndex: string): Promise<boolean> {
    let range = {}
    let timefield = 'device_time';
    if (isnetworkDataUL(data)) {
        timefield = 'network_time';
    }
    range[timefield] = { gte: data[timefield] + "||-5m", lt: data[timefield] + "||+5m" };
    await updateIndex(dbIndex);
    let searchObj = {
        index: dbIndex,
        type: 'doc',
        body: {
            size: 100,
            query: {
                bool: {
                    must: [
                        { term: { direction: data.direction } },
                        { exists: { field: timefield } },
                        { term: { mea_id: data.mea_id } },
                        { term: { dev_eui: data.dev_eui } },
                        {
                            range
                        }
                    ]
                }
            }
        }
    }
    return es.search(searchObj).then(rsp => rsp.hits.hits.length > 0)
}
async function handleData(currentdata: (deviceDataUL | deviceDataDL | networkDataUL), dbIndex: string): Promise<boolean> {
    if (await eliminateDuplicate(currentdata, dbIndex)) {
        console.log('Eliminated duplicate');
        return true;
    }
    let data: DBdata = { toDB: currentdata }
    let range = {}
    let timefield = 'device_time';
    let matchingtimefield = 'network_time';
    if (isnetworkDataUL(currentdata)) {
        timefield = 'network_time';
        matchingtimefield = 'device_time';
    }
    range[matchingtimefield] = { gte: currentdata[timefield] + "||-5m", lt: currentdata[timefield] + "||+5m" }

    let searchObj = {
        index: dbIndex,
        type: 'doc',
        body: {
            size: 100,
            query: {
                bool: {
                    must: [
                        { term: { mea_id: currentdata.mea_id } },
                        { term: { dev_eui: currentdata.dev_eui } },
                        {
                            range
                        }
                    ],
                    must_not: [
                        { exists: { field: timefield } },
                        { term: { direction: "dl" } }
                    ]
                }
            },
            sort: [
                { device_time: { order: "asc" } }
            ]
        }
    }
    if (isnetworkDataUL(currentdata) || isDeviceDataUL(currentdata)) {
        await updateIndex(dbIndex);
        data = await es.search(searchObj).then((rsp: SearchResponse<(deviceDataUL | networkDataUL)>): (Promise<DBdata> | DBdata) => {
            let targetTime = new Date(currentdata[timefield]).getTime();
            let selected: (elasticDeviceDataUL | elasticNetworkDataUL);
            // Search the best matching timestamp for network data from the results
            rsp.hits.hits.forEach((deviceDataElement) => {
                if (selected) {
                    if (Math.abs(targetTime - new Date(deviceDataElement._source[matchingtimefield]).getTime()) < Math.abs(targetTime - new Date(selected._source[matchingtimefield]).getTime())) {
                        selected = <(elasticDeviceDataUL | elasticNetworkDataUL)>deviceDataElement;
                    }
                } else {
                    selected = <(elasticDeviceDataUL | elasticNetworkDataUL)>deviceDataElement;
                }
            });
            if (selected) {
                let updateBody;
                if (isnetworkDataUL(currentdata)) {
                    updateBody = saveNetworkData(<elasticDeviceDataUL>selected, <networkDataUL>currentdata);
                    (<networkDataUL>currentdata).dl = selected._source.dl
                } else
                    updateBody = saveDeviceData(<elasticNetworkDataUL>selected, <deviceDataUL>currentdata);
                console.log('\x1b[35m%s\x1b[0m', 'Combining data (Elastic id: ' + selected._id + ',Mea_id: ' + currentdata.mea_id + ')');
                needRefresh = true;
                return es.update({
                    index: dbIndex,
                    type: 'doc',
                    id: selected._id,
                    body: { doc: updateBody }
                }).then((): DBdata => {
                    return { combined: <combinedDataUL>Object.assign(<(networkDataUL | deviceDataUL)>selected._source, <(deviceDataUL | networkDataUL)>currentdata), id: selected._id };
                });
            }
            return { toDB: currentdata };
        })
    }
    if (data && data.toDB) {
        console.log('\x1b[35m%s\x1b[0m', 'Saving data (Mea_id: ' + data.toDB.mea_id + ')');
        console.log(data.toDB);
        needRefresh = true;
        data.id = await es.index({
            index: dbIndex,
            type: 'doc',
            body: data.toDB
        }).then(rsp => rsp._id)
    } else if (data.combined) {
        console.log('Combined data');
        console.log(data.combined);
    }
    return markDL(data, dbIndex);
}
function saveData(dbIndex: string, previous?: (deviceDataUL | deviceDataDL | networkDataUL)): Promise<void> {
    if (dataquery.length === 0) {
        return;
    }
    let timeout: NodeJS.Timeout;
    Promise.race([
        handleData(dataquery[0], dbIndex),
        new Promise(res => {
            timeout = setTimeout(() => {
                console.log('The queue was stucked for 30 second, jumping to next record. Stucked item was: ', dataquery[0]);
                res();
            }, 30000);
        })
    ]).catch(e => logElasticError).finally(() => {
        clearTimeout(timeout);
        saveData(dbIndex, dataquery.shift());
    });
};

async function markDL(fdata: DBdata, dbIndex: string): Promise<boolean> {
    let cdata: (combinedDataUL | deviceDataUL | networkDataUL | deviceDataDL) = fdata.combined || fdata.toDB;
    if (isDeviceDataUL(cdata) || isnetworkDataUL(cdata)) {
        if (cdata.dl) {
            return new Promise(resolve => resolve(false));
        }
    }
    let range = {}
    let timefield = 'network_time';
    let matchingtimefield = 'device_time';
    if (isDeviceDataDL(cdata) || isDeviceDataUL(cdata)) {
        timefield = 'device_time';
        matchingtimefield = 'network_time';
    } else if (!cdata.network_time) {
        timefield = 'device_time';
        matchingtimefield = 'network_time';
    }

    range[matchingtimefield] = { gte: cdata[timefield] + "||-5m", lt: cdata[timefield] + "||+5m" }
    await updateIndex(dbIndex);
    return es.search({
        index: dbIndex,
        type: 'doc',
        body: {
            size: 100,
            query: {
                bool: {
                    must: [
                        { term: { mea_id: cdata.mea_id } },
                        { term: { dev_eui: cdata.dev_eui } },
                        {
                            range
                        }
                    ],
                    must_not: [
                        { term: { direction: cdata.direction } },
                    ]
                }
            },
            sort: [
                { device_time: { order: "asc" } }
            ]
        }
    }).then((rsp): (Promise<boolean> | boolean) => {
        if (rsp.hits.hits.length === 0)
            return false
        let targetTime = new Date(cdata[timefield]).getTime();
        let selected = rsp.hits.hits.reduce((selected, DataElement) => {
            if (selected) {
                if (Math.abs(targetTime - new Date(DataElement[matchingtimefield]).getTime()) < Math.abs(targetTime - new Date(selected[matchingtimefield]).getTime())) {
                    return DataElement;
                }
            }
            return DataElement;
        });
        console.log('\x1b[35m%s\x1b[0m', 'Mark found downlink for UL: ' + (cdata.direction === 'ul' ? fdata.id : selected._id));
        needRefresh = true;
        return es.update({
            index: dbIndex,
            type: 'doc',
            id: cdata.direction === 'ul' ? fdata.id : selected._id,
            body: {
                doc: {
                    dl: true
                }
            }
        });
    });
}
/**
 * Handle POST /network/
 */
app.post('/network/', textParser, (req, res) => {
    console.log('post network');
    if (!req.body) return res.sendStatus(400);

    var bodyData = req.body;

    const dbIndex = getDbIndexFromRequest(req);
    // TODO: check if device belongs to owner of dbIndex

    //console.log("*** input network ***");
    //console.log(bodyData);
    res.send('');

    var jsonData = JSON.parse(bodyData);
    storeRawData(bodyData, dbIndex);

    let lrrs: lrrs[] = [];
    jsonData.DevEUI_uplink.Lrrs.Lrr.forEach(element => {
        lrrs.push({
            lrrid: element.Lrrid,
            rssi: element.LrrRSSI,
            snr: element.LrrSNR,
            esp: element.LrrESP
        });
    });
    push2query(<networkDataUL>{
        direction: "ul",
        cloud_time: new Date(),
        dev_eui: jsonData.DevEUI_uplink.DevEUI,
        mea_id: jsonData.DevEUI_uplink.payload_hex,
        network_time: jsonData.DevEUI_uplink.Time,
        network_rssi: jsonData.DevEUI_uplink.LrrRSSI,
        network_snr: jsonData.DevEUI_uplink.LrrSNR,
        network_lrrid: jsonData.DevEUI_uplink.Lrrid,
        network_location: {
            lon: jsonData.DevEUI_uplink.LrrLON || 0,
            lat: jsonData.DevEUI_uplink.LrrLAT || 0,
        },
        network_sf: jsonData.DevEUI_uplink.SpFact,
        network_lrrs: lrrs,
        network_lrr_count: jsonData.DevEUI_uplink.DevLrrCnt,
        dl: false
    }, dbIndex);
});
/**
 * Handle GET /
 */
app.get('/', (req, res) => {
    res.send('Hello, world!')
});
