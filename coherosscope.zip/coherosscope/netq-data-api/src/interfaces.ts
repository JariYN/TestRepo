interface location {
    lon: number;
    lat: number
}
interface lrrs {
    lrrid: string;
    rssi: number;
    snr: number;
    esp: number;

}
interface dataUL {
    dev_eui: string;
    mea_id: string;
    direction: string;
    cloud_time: Date;
}
interface deviceDataUL {
    dev_eui: string;
    mea_id: string;
    direction: string;
    cloud_time: Date;
    device_time: number;
    device_time_accuracy: number;
    device_location: location;
    device_location_accuracy: number;
    device_ground_speed?: number;
    device_ground_speed_accuracy?: number;
    special_mea_type?: string;
    special_mea_id?: number;
    device_sf?: number
    dl: boolean;
    downlink_id?: string;
}
interface networkDataUL extends dataUL {
    network_time: number;
    network_rssi: number;
    network_snr: number;
    network_lrrid: string;
    network_location: location;
    network_sf: number;
    network_lrrs: lrrs[];
    network_lrr_count: number;
    dl: boolean
    downlink_id?: string;
}
interface combinedDataUL extends deviceDataUL, networkDataUL {

}
interface DBdata {
    combined?: combinedDataUL;
    toDB?: (deviceDataUL | networkDataUL | deviceDataDL);
    id?: string;
}
interface elasticDeviceDataUL {
    _source: deviceDataUL,
    _id: string
}

interface elasticNetworkDataUL {
    _source: networkDataUL
    _id: string
}
interface deviceDataDL {
    dev_eui: string;
    mea_id: string;
    direction: string;
    cloud_time: Date;
    device_time: number;
    device_time_accuracy: number;
    device_location: location;
    device_location_accuracy: number;
    device_ground_speed?: number;
    device_ground_speed_accuracy?: number;
    special_mea_type?: string;
    special_mea_id?: number;
    device_sf?: number
    device_rssi: number;
    device_snr: number;
}