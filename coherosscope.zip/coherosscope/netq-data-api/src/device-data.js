"use strict";

//const navigationData = require('./navigation_data_pb');
const deviceDLMessage = require('./device_message_pb');
const jspb = require('google-protobuf');
const long = require('long');

// From protobuf definition
const mcuIdFieldNumber = 1;
const devEUIFieldNumber = 2;
const manualMeaIdFieldNumber = 8;

/**
 * Convert number to hex string with leading zeros
 * @param {*} size
 */
Number.prototype.toHex = function(size) {
    let s = this.toString(16);
    while (s.length < (size || 2)) {s = "0" + s;}
    return s;
}


class DeviceDataMessage {
    constructor(rawMsg) {
        this._msg = proto.DeviceMessage.deserializeBinary(new Uint8Array(rawMsg));
        this._raw = rawMsg;
        this._obj = this._msg.toObject();
    }

    enumAsString(enumName, value) {
        for (var name in enumName) {
            if (enumName[name] == value) {
                return name;
            }
        }
    }

    has(param) {
        return typeof param != 'undefined';
    }

    fixed64AsHexString(reqFieldNumber) {
        /**
         * Quite a hack to get UInt64 and convert it as a hex string.
         * By default BinaryReader returns UInt64 as (53bit) number, so, it
         * must be found and read as string that is converted to Long, which
         * is converted to string.
         */
        const reader = new jspb.BinaryReader(new Uint8Array(this._raw));
        while (reader.nextField()) {
            if (reader.isEndGroup()) {
              break;
            }
            const field = reader.getFieldNumber();
            if (field == reqFieldNumber) {
                const value = long.fromString(reader.readFixed64String(), true);
                return value.toString(16);
            }
            reader.skipField();
        }
        return 'NOT_SET';
    }

    timestampAsMillisFromEpoch(timestamp) {
        return timestamp.seconds * 1e3 + Math.round(timestamp.nanos / (1e6))
    }

    gpsTimeAsMillisFromEpoch(gpsTime) {
        return Date.UTC(
            gpsTime.year,
            gpsTime.month - 1, // JS months: 0-11
            gpsTime.day,
            gpsTime.hour,
            gpsTime.min,
            gpsTime.sec,
            Math.round(gpsTime.nano * 1e-6)); // negative millis are valid too
    }

    isValid() {
        if ((this._obj.direction != proto.DeviceMessage.Direction.DIR_DOWNLINK) &&
            (this._obj.direction != proto.DeviceMessage.Direction.DIR_UPLINK) &&
            (this._obj.direction != proto.DeviceMessage.Direction.DIR_MANUAL_DOWNLINK) &&
            (this._obj.direction != proto.DeviceMessage.Direction.DIR_MANUAL_UPLINK)) {
                console.warn('DeviceMessage has bad direction:', msgObj.direction);
                return false;
        }

        if (!this._obj.gps) {
            console.warn('DeviceMessage has no gps data');
            return false;
        }

        if (!this._obj.gps.time) {
            console.warn('DeviceMessage has no timestamp');
            return false;
        }

        if (((this._obj.direction == proto.DeviceMessage.Direction.DIR_MANUAL_DOWNLINK) ||
             (this._obj.direction == proto.DeviceMessage.Direction.DIR_MANUAL_UPLINK)) &&
             this._obj.manualMeaId == 0) {
            console.warn('DeviceMessage is manual but manual mea id is not set.');
            return false;
        }

        return true;
    }

    toObject() {
        const msgObj = this._msg.toObject();
        const validBitmask = proto.NavigationData.ValidBitmask;
        const flagsBitmask = proto.NavigationData.FlagsBitmask;
        const flags2Bitmask = proto.NavigationData.Flags2Bitmask;

        msgObj.mcuId = String(this.fixed64AsHexString(mcuIdFieldNumber));
        msgObj.devEui = String(this.fixed64AsHexString(devEUIFieldNumber));
        msgObj.meaId = msgObj.meaId.toHex(4);
        msgObj.isDownlink = ((msgObj.direction == proto.DeviceMessage.Direction.DIR_DOWNLINK) ||
                            (msgObj.direction == proto.DeviceMessage.Direction.DIR_MANUAL_DOWNLINK));
        msgObj.isManual = ((msgObj.direction == proto.DeviceMessage.Direction.DIR_MANUAL_DOWNLINK) ||
                          (msgObj.direction == proto.DeviceMessage.Direction.DIR_MANUAL_UPLINK));

        if (msgObj.gps) {
            if (msgObj.gps.time) {
                msgObj.deviceTime = this.gpsTimeAsMillisFromEpoch(msgObj.gps.time);
                // Booleans from gps.valid
                msgObj.gps.time.validDate = (msgObj.gps.time.valid & validBitmask.VB_VALID_DATE) ? true : false;
                msgObj.gps.time.validTime = (msgObj.gps.time.valid & validBitmask.VB_VALID_TIME) ? true : false;
                msgObj.gps.time.fullyResolved = (msgObj.gps.time.valid & validBitmask.VB_FULLY_RESOLVED) ? true : false;
                msgObj.gps.time.validMag = (msgObj.gps.time.valid & validBitmask.VB_VALID_MAG) ? true : false;
            }

            msgObj.gps.fixType = String(this.enumAsString(proto.NavigationData.GNSSFixType, msgObj.gps.fixType));

            // Values from gps.flags
            msgObj.gps.gnssFixOk = (msgObj.gps.flags & flagsBitmask.FB_GNSS_FIX_OK) ? true : false;
            msgObj.gps.diffSoln = (msgObj.gps.flags & flagsBitmask.FB_DIFF_SOLN) ? true : false;
            msgObj.gps.psmState = this.enumAsString(
                proto.NavigationData.PowerSaveMode, (msgObj.gps.flags & flagsBitmask.FB_PSM_STATE));
            msgObj.gps.headVehValid = (msgObj.gps.flags & flagsBitmask.FB_HEAD_VEH_VALID) ? true : false;
            msgObj.gps.carrSoln = this.enumAsString(
                proto.NavigationData.CarrierPhaseRangeSolutionStatus, (msgObj.gps.flags & flagsBitmask.FB_CARR_SOLN));

            // Booleans from gps.flags2
            msgObj.gps.confirmedAvail = (msgObj.gps.flags2 & flags2Bitmask.F2B_CONFIRMED_AVAI) ? true : false;
            msgObj.gps.confirmedDate = (msgObj.gps.flags2 & flags2Bitmask.F2B_CONFIRMED_DATE) ? true : false;
            msgObj.gps.confirmedTime = (msgObj.gps.flags2 & flags2Bitmask.F2B_CONFIRMED_TIME) ? true : false;

            // Do scaling
            msgObj.gps.lon = Number((msgObj.gps.lon * 1e-7).toFixed(7));
            msgObj.gps.lat = Number((msgObj.gps.lat * 1e-7).toFixed(7));
            msgObj.gps.pDop = Number((msgObj.gps.pDop * 1e-2).toFixed(2));

            if (msgObj.gps.motion) {
                msgObj.gps.motion.headMot = Number((msgObj.gps.motion.headMot * 1e-5).toFixed(5));
                msgObj.gps.motion.headAcc = Number((msgObj.gps.motion.headAcc * 1e-5).toFixed(5));
            }

            if (msgObj.gps.compass) {
                msgObj.gps.compass.headVeh = Number((msgObj.gps.compass.headVeh * 1e-5).toFixed(5));
                msgObj.gps.compass.magDeg = Number((msgObj.gps.compass.magDeg * 1e-2).toFixed(2));
                msgObj.gps.compass.magAcc = Number((msgObj.gps.compass.magAcc * 1e-2).toFixed(2));
            }
        }
        return msgObj;
    }

}

class DeviceDataBuffer {
    constructor(dataBuffer) {
        this._dataBuffer = dataBuffer;
        this._index = 0;
    }

    * messages() {
        while (this._index < this._dataBuffer.length) {
            var sliceStart = this._index + 1;
            var sliceEnd = this._index + this._dataBuffer.readUInt8(this._index) + 1;

            this._index = sliceEnd;

            if (sliceEnd <= this._dataBuffer.length) {
                yield new DeviceDataMessage(this._dataBuffer.slice(sliceStart, sliceEnd));
            }
        }
    }
}

module.exports.Buffer = DeviceDataBuffer;
