#!/bin/bash

# Missing DL from device, network UL - Device UL

echo "Add network data #1"
curl -k -H 'Host: test.coherosscope.com' -H 'Content-Type: application/json' -XPOST "http://localhost:3000/network/" -d'
{
    "DevEUI_uplink": {
        "Time": "'$(date +"%Y-%m-%dT%H:%M:%S%z")'",
        "DevEUI": "deadbeefcafebabe",
        "FPort": "8",
        "FCntUp": "801",
        "MType": "4",
        "FCntDn": "801",
        "payload_hex": "0001",
        "mic_hex": "a3080280",
        "Lrcid": "00000201",
        "LrrRSSI": "-48.000000",
        "LrrSNR": "11.000000",
        "SpFact": "12",
        "SubBand": "G0",
        "Channel": "LC5",
        "DevLrrCnt": "5",
        "Lrrid": "004A223D",
        "Late": "0",
        "LrrLAT": "1.000001",
        "LrrLON": "2.000001",
        "Lrrs": {
            "Lrr": [
                {
                    "Lrrid": "004A223D",
                    "Chain": "0",
                    "LrrRSSI": "-48.000000",
                    "LrrSNR": "11.000000",
                    "LrrESP": "-48.331955"
                },
                {
                    "Lrrid": "FF0193BB",
                    "Chain": "0",
                    "LrrRSSI": "-91.000000",
                    "LrrSNR": "3.000000",
                    "LrrESP": "-92.764351"
                },
                {
                    "Lrrid": "FF018004",
                    "Chain": "0",
                    "LrrRSSI": "-92.000000",
                    "LrrSNR": "-13.000000",
                    "LrrESP": "-105.212387"
                }
            ]
        },
        "CustomerID": "100006244",
        "CustomerData": {
            "alr": {
                "pro": "LORA/Generic",
                "ver": "1"
            }
        },
        "ModelCfg": "0",
        "DevAddr": "025991E0"
    }
}
'
python $(dirname $0)/send_pb_data_api_msgs.py

