#!/bin/bash
echo "Testing data #1"

DATA=$(curl -sS -H 'Host: test.coherosscope.com' -H "Content-Type: application/json" -XPOST "http://localhost:9200/data/doc/_search?pretty" -d'
{
  "query": {
    "bool": {
        "must":[ 
            {"term":{ "mea_id":"0001"} }
        ]
    }
  },
  "sort": [{ "cloud_time": { "order": "asc" }}]
}
')

PASSED=0
FAILED=0

# *** Test Lib ***
# Try to use natural language

field() {
    FIELD=$1
    OPERAND=$2
    EXPECTED=$3
    VALUE=$(echo $DATA | jq -r "$FIELD")

    if [[ $? -ne 0 ]]; then
        ((FAILED++))
        return 1
    fi

    case $OPERAND in
        is)
            if [[ $VALUE != $EXPECTED ]]; then
                echo "FAIL: $FIELD: $VALUE != $EXPECTED"
                ((FAILED++))
                return 1
            fi
            ;;
        *)
            echo "Unknown operand: $OPERAND"
            return 1
    esac
    ((PASSED++))
}


show_summary() {
    echo ""
    echo "------------------------------"
    echo "TOTAL: $((PASSED+FAILED)), PASSED: $PASSED, FAILED: $FAILED"
    echo ""

    if [[ $FAILED -eq 0 ]]; then
        echo "*** PASSED ***"
        echo ""
        return 0
    else
        echo "*** FAILED ***"
        echo ""
        return 1
    fi
}

# *** Test Cases ***

field '.hits.total' is 1

field '.hits.hits[0]._source.direction' is "ul"
field '.hits.hits[0]._source.dev_eui' is "deadbeefcafebabe"
field '.hits.hits[0]._source.mea_id' is "0001"
field '.hits.hits[0]._source.device_time_accuracy' is 2147483647
field '.hits.hits[0]._source.device_location.lon' is "24.0000001"
field '.hits.hits[0]._source.device_location.lat' is "60.0000001"
field '.hits.hits[0]._source.device_location_accuracy' is 2147483647
field '.hits.hits[0]._source.device_ground_speed' is 13
field '.hits.hits[0]._source.device_ground_speed_accuracy' is 2147483647
field '.hits.hits[0]._source.network_rssi' is "-48.000000"
field '.hits.hits[0]._source.network_snr' is "11.000000"
field '.hits.hits[0]._source.network_lrrid' is "004A223D"
field '.hits.hits[0]._source.network_location.lon' is "2.000001"
field '.hits.hits[0]._source.network_location.lat' is "1.000001"
field '.hits.hits[0]._source.network_sf' is 12
field '.hits.hits[0]._source.network_lrr_count' is 5
field '.hits.hits[0]._source.dl' is "false"

# *** Show test summary and pass result to Travis ***
show_summary