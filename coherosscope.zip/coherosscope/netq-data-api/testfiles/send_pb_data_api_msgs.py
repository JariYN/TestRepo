#!/usr/bin/python

import datetime
import requests
import time
import device_message_pb2

NOW = datetime.datetime.utcnow()

msg0 = device_message_pb2.DeviceMessage()

print "Add protobuffer UL device data #0"

msg0.mcu_id = 0x204a375e41465018
msg0.dev_eui = 0xdeadbeefcafebabe
msg0.mea_id = 1
msg0.direction = 1  # UPLINK
msg0.dl_rssi = -100
msg0.dl_snr = 20
msg0.spreading_factor = 12
msg0.gps.time.year = NOW.year
msg0.gps.time.month = NOW.month
msg0.gps.time.day = NOW.day
msg0.gps.time.hour = NOW.hour
msg0.gps.time.min = NOW.minute
msg0.gps.time.sec = NOW.second
msg0.gps.time.nano = NOW.microsecond * 1000
msg0.gps.time.valid = 3
msg0.gps.time.t_acc = 2147483650
msg0.gps.fix_type = 3
msg0.gps.flags = 4
msg0.gps.flags2 = 64
msg0.gps.num_sv = 5
msg0.gps.lon = 240000001
msg0.gps.lat =  600000001
msg0.gps.height = 8000
msg0.gps.h_msl = 9000
msg0.gps.h_acc = 2147483648
msg0.gps.v_acc = 1100
msg0.gps.p_dop = 12
msg0.gps.motion.vel_n = 130
msg0.gps.motion.vel_e = 140
msg0.gps.motion.vel_d = 150
msg0.gps.motion.g_speed = 13
msg0.gps.motion.head_mot = 17000000
msg0.gps.motion.s_acc = 2147483650
msg0.gps.motion.head_acc = 19000000

data0 = msg0.SerializeToString()
msglen0 = chr(len(data0))


res = requests.post(
    url='http://localhost:3000/device/pb/',
    data=msglen0+data0,
    headers={'Host': 'test.coherosscope.com', 'Content-Type': 'application/octet-stream'})

# Just to ensure that packets are in correct order
# during verification
time.sleep(0.1)


#######################
NOW = datetime.datetime.utcnow()

msg = device_message_pb2.DeviceMessage()

print "Add protobuffer UL device data #2"

msg.mcu_id = 0x204a375e41465018
msg.dev_eui = 0xdeadbeefcafebabe
msg.mea_id = 2
msg.direction = 1  # UPLINK
msg.dl_rssi = -100
msg.dl_snr = 20
msg.spreading_factor = 12
msg.gps.time.year = NOW.year
msg.gps.time.month = NOW.month
msg.gps.time.day = NOW.day
msg.gps.time.hour = NOW.hour
msg.gps.time.min = NOW.minute
msg.gps.time.sec = NOW.second
msg.gps.time.nano = NOW.microsecond * 1000
msg.gps.time.valid = 3
msg.gps.time.t_acc = 2147483650
msg.gps.fix_type = 3
msg.gps.flags = 4
msg.gps.flags2 = 64
msg.gps.num_sv = 5
msg.gps.lon = 600000002
msg.gps.lat = 240000002
msg.gps.height = 8000
msg.gps.h_msl = 9000
msg.gps.h_acc = 2147483648
msg.gps.v_acc = 1100
msg.gps.p_dop = 12
msg.gps.motion.vel_n = 130
msg.gps.motion.vel_e = 140
msg.gps.motion.vel_d = 150
msg.gps.motion.g_speed = 1600
msg.gps.motion.head_mot = 17000000
msg.gps.motion.s_acc = 2147483650
msg.gps.motion.head_acc = 19000000

data1 = msg.SerializeToString()
msglen1 = chr(len(data1))

print "Add protobuffer DL device data #2"

msg.direction = 2  # DOWNLINK
msg.gps.lon = -600000002
msg.gps.lat = -240000002
data2 = msg.SerializeToString()
msglen2 = chr(len(data2))

res = requests.post(
    url='http://localhost:3000/device/pb/',
    data=msglen1+data1+msglen2+data2,
    headers={'Host': 'test.coherosscope.com', 'Content-Type': 'application/octet-stream'})

# Just to ensure that packets are in correct order
# during verification
time.sleep(0.1)

#print "Add protobuffer UL device data #3"

msg.direction = 3  # MANUAL_UPLINK
msg.mea_id = 3
msg.manual_mea_id = 3
msg.gps.lon = 600000003
msg.gps.lat = 240000003
data3 = msg.SerializeToString()
msglen3 = chr(len(data3))

res = requests.post(
   url='http://localhost:3000/device/pb/',
   data=msglen3+data3,
   headers={'Host': 'test.coherosscope.com', 'Content-Type': 'application/octet-stream'})
