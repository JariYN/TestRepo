#!/usr/bin/python

import datetime
import requests
import time
import os,sys,inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir) 
import device_message_pb2


#######################
NOW = datetime.datetime.utcnow()

msg = device_message_pb2.DeviceMessage()

print "Add protobuffer UL device data #3"

msg.mcu_id = 0x204a375e41465018
msg.dev_eui = 0xdeadbeefcafebabe
msg.mea_id = 3
msg.manual_mea_id =3
msg.direction = 3 #MANUAL UPLINK
msg.dl_rssi = -100
msg.dl_snr = 20
msg.spreading_factor = 12
msg.gps.time.year = NOW.year
msg.gps.time.month = NOW.month
msg.gps.time.day = NOW.day
msg.gps.time.hour = NOW.hour
msg.gps.time.min = NOW.minute
msg.gps.time.sec = NOW.second
msg.gps.time.nano = NOW.microsecond * 1000
msg.gps.time.valid = 3
msg.gps.time.t_acc = 2147483650
msg.gps.fix_type = 3
msg.gps.flags = 4
msg.gps.flags2 = 64
msg.gps.num_sv = 5
msg.gps.lon = 600000003
msg.gps.lat = 240000003
msg.gps.height = 8000
msg.gps.h_msl = 9000
msg.gps.h_acc = 2147483648
msg.gps.v_acc = 1100
msg.gps.p_dop = 12
msg.gps.motion.vel_n = 130
msg.gps.motion.vel_e = 140
msg.gps.motion.vel_d = 150
msg.gps.motion.g_speed = 1600
msg.gps.motion.head_mot = 17000000
msg.gps.motion.s_acc = 2147483650
msg.gps.motion.head_acc = 19000000

print "Add protobuffer DL device data #2"

#print "Add protobuffer UL device data #3"

data3 = msg.SerializeToString()
msglen3 = chr(len(data3))



msg.direction = 2  # DOWNLINK
data2 = msg.SerializeToString()
msglen2 = chr(len(data2))


res = requests.post(
   url='http://localhost:3000/device/pb/',
   data=msglen2+data2+msglen3+data3,
   headers={'Host': 'test.coherosscope.com', 'Content-Type': 'application/octet-stream'})
