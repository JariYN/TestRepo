
echo "\n*** Delete DB ***\n"
curl -H 'Content-Type: application/json' -XDELETE 'http://localhost:9200/data'

echo "\n\n*** Create DB ***\n"
curl -H 'Content-Type: application/json' -XPUT 'http://localhost:9200/data' -d'
{
  "settings": {
    "index": {
      "number_of_shards": 3,
      "number_of_replicas": 1
    }
  },
  "mappings": {
    "doc": {
      "properties": {

        "mea_id":   {"type": "keyword"},
        "dev_eui":  {"type": "keyword"},

        "device_data": {
          "type": "nested",
          "properties": {
            "time": {
              "type": "date",
              "format": "strict_date_optional_time||epoch_millis"
            },
            "location": {"type": "geo_point"},
            "location_accuracy": {"type": "integer"},
            "ground_speed": {"type": "integer"},
            "ground_speed_accuracy": {"type": "integer"}
          }
        },

        "network_data": {
          "type": "nested",
          "properties": {
            "time": {
              "type": "date",
              "format": "strict_date_optional_time||epoch_millis"
            },
            "rssi":     {"type": "float"},
            "snr":      {"type": "float"},
            "esp":      {"type": "float"},
            "lrrid":    {"type": "keyword"},
            "location": {"type": "geo_point"},
            "lrrs": {
              "type": "nested",
              "properties": {
                "lrrid": {"type": "keyword"},
                "rssi":  {"type": "float"},
                "snr":   {"type": "float"},
                "esp":   {"type": "float"}
              }
            }
          }
        }
      }
    }
  }
}
'

echo "\n\n*** Add network data ***\n"
curl -H 'Content-Type: application/json' -XPOST 'http://localhost:3000/network/' -d'
{
    "DevEUI_uplink": {
        "Time": "'$(date +"%Y-%m-%dT%H:%M:%S")'",
        "DevEUI": "4786C58B0036003A",
        "FPort": "8",
        "FCntUp": "801",
        "MType": "4",
        "FCntDn": "801",
        "payload_hex": "0002f7010036020812030a1504000f320305122a6902406a0b45",
        "mic_hex": "a3080280",
        "Lrcid": "00000201",
        "LrrRSSI": "-48.000000",
        "LrrSNR": "11.000000",
        "SpFact": "12",
        "SubBand": "G0",
        "Channel": "LC5",
        "DevLrrCnt": "5",
        "Lrrid": "004A223D",
        "Late": "0",
        "LrrLAT": "0.000000",
        "LrrLON": "0.000000",
        "Lrrs": {
            "Lrr": [
                {
                    "Lrrid": "004A223D",
                    "Chain": "0",
                    "LrrRSSI": "-48.000000",
                    "LrrSNR": "11.000000",
                    "LrrESP": "-48.331955"
                },
                {
                    "Lrrid": "FF0193BB",
                    "Chain": "0",
                    "LrrRSSI": "-91.000000",
                    "LrrSNR": "3.000000",
                    "LrrESP": "-92.764351"
                },
                {
                    "Lrrid": "FF018004",
                    "Chain": "0",
                    "LrrRSSI": "-92.000000",
                    "LrrSNR": "-13.000000",
                    "LrrESP": "-105.212387"
                }
            ]
        },
        "CustomerID": "100006244",
        "CustomerData": {
            "alr": {
                "pro": "LORA/Generic",
                "ver": "1"
            }
        },
        "ModelCfg": "0",
        "DevAddr": "025991E0"
    }
}'

#sleep 0.1

echo "\n\n*** Add device data ***\n"
curl -H 'Content-Type: application/json' -XPOST 'http://localhost:3000/device/' -d'
{
    "DevEUI": "4786C58B0036003A",
    "payload_hex": "0002f7010036020812030a1504000f320305122a6902406a0b45",
    "time": "'$(date +"%Y-%m-%dT%H:%M:%S")'",
    "gpsData": {
        "iTOW": 0,
        "valid": 0,
        "tAcc": 0,
        "fixType": 0,
        "flags": 0,
        "numSV": 0,
        "lon": 60.0000000,
        "lat": 24.0000000,
        "height": 0,
        "hMSL": 0,
        "hAcc": 0,
        "vAcc": 21474836460,
        "velN": 0,
        "velE": 0,
        "velD": 0,
        "gSpeed": 0,
        "heading": 0.00000,
        "sAcc": 0,
        "headingAcc": 0.00000,
        "pDOP": 0.00
    }
}
'


#sleep 0.1

echo "\n\n*** Search data ***\n"
curl -H 'Content-Type: application/json' -XPOST 'http://localhost:9200/data/doc/_search?pretty=true' -d'
{ "query": { "term": { "mea_id": "0002f7010036020812030a1504000f320305122a6902406a0b45" }}}'


echo "\n\n*** Aggregate ***\n"
curl -H 'Content-Type: application/json' -XPOST 'http://localhost:9200/data/doc/_search?pretty=true' -d'
{
  "size": 0,
  "aggs": {
    "pairs": {
      "terms": { "field": "mea_id" },
      "aggs": {
        "top_pair_hits": {
          "top_hits": {
            "_source": { "includes": ["network_data", "device_data"] },
            "size": 1
          }
        }
      }
    }
  }
}'

echo "\n\n*** All data ***\n"
curl -H 'Content-Type: application/json' -XPOST 'http://localhost:9200/data/doc/_search?pretty=true' -d'
{ "query": { "match_all": {}}}'


sleep 10
echo "\n\n*** All data after 10s ***\n"
curl -H 'Content-Type: application/json' -XPOST 'http://localhost:9200/data/doc/_search?pretty=true' -d'
{ "query": { "match_all": {}}}'


