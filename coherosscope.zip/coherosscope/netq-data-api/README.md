# Running on local

To test on local PC, run command ```npm run local```.

# Message structure


## Device -> Cloud Protobuf API

See ProtoBuffer definition from [NetQ API](https://github.com/coheros/netq-api/tree/master/data_api).


## Device -> Cloud API

See [ u-blox 8 / u-blox M8 Receiver Description](https://www.u-blox.com/sites/default/files/products/documents/u-blox8-M8_ReceiverDescrProtSpec_%28UBX-13003221%29.pdf), chapter '31.18.14 UBX-NAV-PVT (0x01 0x07)'

Example json:
```json
{
    "DevEUI": "0123456789AB",
    "payload_hex": "deadbeef",
    "time": "2018-02-18T13:20:50.666",
    "gpsData": {
        "iTOW": 0,
        "valid": 0,
        "tAcc": 0,
        "fixType": 0,
        "flags": 0,
        "flags2": 0,
        "numSV": 0,
        "lon": 0.0000000,
        "lat": 0.0000000,
        "height": 0,
        "hMSL": 0,
        "hAcc": 0,
        "vAcc": 0,
        "velN": 0,
        "velE": 0,
        "velD": 0,
        "gSpeed": 0,
        "headMot": 0.00000,
        "sAcc": 0,
        "headAcc": 0.00000,
        "pDOP": 0.00,
        "headVeh": 0.00000,
        "magDeg": 0.00,
        "magAcc": 0.00
    }
}
```

Mandatory values are:
- `time`
- `DevEUI`
- `payload_hex`
- `gpsData.lon`
- `gpsData.lat`
- `gpsData.hAcc`
- `gpsData.gSpeed`
- `gpsData.sAcc`
- `gpsData.tAcc`
