#!/bin/bash

K8S_CONTEXT="$(kubectl config current-context)"

# --- preconditions ---
if [[ "$K8S_CONTEXT" != "netq-test.k8s.local" ]]; then echo "Please set Kubernetes context to netq-test.k8s.local"; else
# --- preconditions are fulfilled ---


echo "Using context ${K8S_CONTEXT}"
NETQ_WEB_HOST="$(kubectl get service -o wide netq-web | tail -1 | awk '{print $4}')"
#NETQ_WEB_HOST=digilora.coheros.com
echo "Public host: ${NETQ_WEB_HOST}"

echo "Add network data"
curl -k -H 'Content-Type: application/json' -XPOST "https://${NETQ_WEB_HOST}/api/data/v1/network/" -d'
{
    "DevEUI_uplink": {
        "Time": "'$(date +"%Y-%m-%dT%H:%M:%S%z")'",
        "DevEUI": "TEST",
        "FPort": "8",
        "FCntUp": "801",
        "MType": "4",
        "FCntDn": "801",
        "payload_hex": "0001",
        "mic_hex": "a3080280",
        "Lrcid": "00000201",
        "LrrRSSI": "-48.000000",
        "LrrSNR": "11.000000",
        "SpFact": "12",
        "SubBand": "G0",
        "Channel": "LC5",
        "DevLrrCnt": "5",
        "Lrrid": "004A223D",
        "Late": "0",
        "LrrLAT": "0.000000",
        "LrrLON": "0.000000",
        "Lrrs": {
            "Lrr": [
                {
                    "Lrrid": "004A223D",
                    "Chain": "0",
                    "LrrRSSI": "-48.000000",
                    "LrrSNR": "11.000000",
                    "LrrESP": "-48.331955"
                },
                {
                    "Lrrid": "FF0193BB",
                    "Chain": "0",
                    "LrrRSSI": "-91.000000",
                    "LrrSNR": "3.000000",
                    "LrrESP": "-92.764351"
                },
                {
                    "Lrrid": "FF018004",
                    "Chain": "0",
                    "LrrRSSI": "-92.000000",
                    "LrrSNR": "-13.000000",
                    "LrrESP": "-105.212387"
                }
            ]
        },
        "CustomerID": "100006244",
        "CustomerData": {
            "alr": {
                "pro": "LORA/Generic",
                "ver": "1"
            }
        },
        "ModelCfg": "0",
        "DevAddr": "025991E0"
    }
}
'

#echo "Add device data"
#curl -k -H 'Content-Type: application/json' -XPOST "https://${NETQ_WEB_HOST}/api/data/v1/device/" -d'
#{
#    "DevEUI": "TEST",
#    "payload_hex": "0001",
#    "time": "'$(date +"%Y-%m-%dT%H:%M:%S%z")'",
#    "gpsData": {
#        "iTOW": 0,
#        "valid": 0,
#        "tAcc": 0,
#        "fixType": 0,
#        "flags": 0,
#        "numSV": 0,
#        "lat": 60.0000000,
#        "lon": 24.0000000,
##        "height": 0,
 #       "hMSL": 0,
#        "hAcc": 0,
#        "vAcc": 0,
#        "velN": 0,
#        "velE": 0,
#        "velD": 0,
#        "gSpeed": 0,
#        "heading": 0.00000,
#        "sAcc": 0,
#        "headingAcc": 0.00000,
##        "pDOP": 0.00
 #   }
#}
#'

echo "Wait data unifier to do its magic and check the results"

DATABASE_POD="$(kubectl get pods | grep -e "^netq-database-.*1/1" | awk '{print $1}')"
kubectl port-forward ${DATABASE_POD} 9200:9200 &
DATABASE_PID=$!
sleep 10

curl -H "Content-Type: application/json" -XPOST "http://localhost:9200/data/doc/_search?pretty" -d'
{
  "query": {
    "match_all": {}
  }
}
'

kill ${DATABASE_PID}


# --- preconditions ends ---
fi
