from pymongo import MongoClient


def main():
    client = MongoClient('localhost:27017')
    db = client.admin['global']

    globalConfig = db.find_one()
    globalConfig = {} if globalConfig == None else globalConfig
    globalConfig['ftpServer'] = 'localhost'
    globalConfig['ftpPort'] = '1337'

    db.replace_one({}, globalConfig, upsert=True)
    client.close()


if __name__ == '__main__':
    main()
