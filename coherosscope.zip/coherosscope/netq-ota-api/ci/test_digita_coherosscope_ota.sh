#!/bin/bash
python send_file_dl_request.py mcu 1.1.1.0 0x207a355258465016 https://digita.coherosscope.com/api/ota/v1/

