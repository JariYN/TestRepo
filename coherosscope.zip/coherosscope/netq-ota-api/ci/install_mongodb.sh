#!/bin/bash
docker run --name netq-mongodb.default -d --rm -p 27017:27017 mongo:3.6.4-jessie

sleep 5

python add_fw_to_mongodb.py data1.png mcu 0.0.1.0
python add_fw_to_mongodb.py data2.png mcu 0.0.1.1
python add_fw_to_mongodb.py data2.png lora 0.0.2.0
python add_ftp_globals_to_mongodb.py
python add_swversion_to_mongodb.py 1.0.0 0.0.1.0 0.0.2.0 0.0.0.0 0.0.0.0
python add_device_to_mongodb.py
