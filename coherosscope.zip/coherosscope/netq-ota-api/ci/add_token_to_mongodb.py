import datetime
import sys

from pymongo import MongoClient


def help(name):
    print "Usage: {} <token> <type: mcu, lora, gps, gsm> <version: major.minor.patch.build>".format(name)


def parse_version(vString):
    v = 0
    if vString.count('.') != 3:
        raise ValueError('Illegal version:', vString)
    for i in vString.split('.'):
        v <<= 8
        v += int(i)
    return v

def main(token, fwType, version):
    client = MongoClient('localhost:27017')
    db = client.admin.ftptokens
    db.replace_one({'token': token}, {
        'timestamp': datetime.datetime.now(),
        'downloaded': False,
        'token': token,
        'filename': '{}_{}.bin'.format(fwType, version),
        'username': 'username',
        'password': 'password',
    }, upsert=True)


if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[2] in ['mcu', 'lora', 'gps', 'gsm']:
        main(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        help(sys.argv[0])
