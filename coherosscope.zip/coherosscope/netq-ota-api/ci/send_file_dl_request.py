#!/usr/bin/python

from ftplib import FTP
import requests
import sys
import file_download_request_message_pb2 as dl_req
import file_download_response_message_pb2 as dl_rsp
import json

def as_hex_string(data):
    ret = ""
    for i in data:
        ret += "{:02X}".format(ord(i))
    return ret

def parse_version(vString):
    v = 0
    if vString.count('.') != 3:
        raise ValueError('Illegal version:', vString)
    for i in vString.split('.'):
        v <<= 8
        v += int(i)
    return v

def send_request(req, url):

    res = requests.post(
        url=url,
        data=req.SerializeToString(),
        headers={'Content-Type': 'application/octet-stream'})

    ret = {'status_code': res.status_code, 'response': {}}

    if res.status_code == 200:
        rsp = dl_rsp.FileDownloadResponseMessage()
        rsp.ParseFromString(res.content)
        ret['response']['server'] = {}
        ret['response']['server']['protocol'] = rsp.server.protocol
        ret['response']['server']['server_ip'] = rsp.server.server_ip
        ret['response']['server']['server_name'] = rsp.server.server_name
        ret['response']['server']['server_port'] = rsp.server.server_port
        ret['response']['server']['username'] = rsp.server.username
        ret['response']['server']['password'] = rsp.server.password
        ret['response']['server']['secure_mode'] = rsp.server.secure_mode
        ret['response']['server']['ftp_mode'] = rsp.server.ftp_mode
        ret['response']['path'] = rsp.path
        ret['response']['filename'] = rsp.filename
        ret['response']['crc32'] = rsp.crc32
        ret['response']['md5'] = rsp.md5

        print "Hex:"
        for i in res.content:
            print "{:02X}".format(ord(i)),
        print ""


    return ret


##   ##  ####  #### ##  ##
### ### ##  ##  ##  ### ##
## # ## ######  ##  ## ###
##   ## ##  ## #### ##  ##

def main():

    if len(sys.argv) != 5:
        print "Usage:", sys.argv[0], "<file_type> <file_version> <mcu_id> <api url>"
        print "E.g.", sys.argv[0], "mcu 0.0.1 0x00000000000000FF http://localhost:3000/v1"
        print "or  ", sys.argv[0], "lora 2.0.0 255 https://digilora.coheros.com/api/ota/v1"
        return

    file_types = {
        'mcu': 0, # dl_req.FileDownloadRequestMessage.FileType.MCU_FIRMWARE,
        'lora': 1, # dl_req.FileDownloadRequestMessage.FileType.LORA_FIRMWARE,
        'gsm': 2, # dl_req.FileDownloadRequestMessage.FileType.GSM_FIRMWARE,
        'gps': 3, # dl_req.FileDownloadRequestMessage.FileType.GPS_FIRMWARE
    }

    file_type = file_types[sys.argv[1]]
    file_version = parse_version(sys.argv[2])
    mcu_id = sys.argv[3]
    if mcu_id.startswith('0x'):
        mcu_id = int(mcu_id, 16)
    else:
        mcu_id = int(mcu_id)
    url = sys.argv[4]

    req = dl_req.FileDownloadRequestMessage()
    req.file_type = file_type
    req.file_version = file_version
    req.mcu_id = mcu_id

    #sys.stdout.write(req.SerializeToString())

    rsp = send_request(req, url)
    print json.dumps(rsp, indent=2)
    if rsp['status_code'] != 200:
        print "ERROR: Server responded with status", rsp['status_code']
        return

    ftp = FTP()
    ftp.connect(
        rsp['response']['server']['server_name'],
        int(rsp['response']['server']['server_port']))
    ftp.login(
        rsp['response']['server']['username'],
        rsp['response']['server']['password'])
    ftp.cwd(rsp['response']['path'])
    ftp.set_pasv(
        False if rsp['response']['server']['ftp_mode'] == 0 else True)
#    ftp.dir()
    ftp.retrbinary(
        "RETR " + rsp['response']['filename'],
        open(rsp['response']['filename'], 'wb').write)

if __name__ == '__main__':
    main()
