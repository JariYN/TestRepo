#!/bin/bash
python send_file_dl_request.py mcu 1.1.1.0 0x2077358f58465016 https://ota.coherosscope.com/api/ota/v1/

