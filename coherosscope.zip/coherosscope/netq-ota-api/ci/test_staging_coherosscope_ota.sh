#!/bin/bash
python send_file_dl_request.py mcu 1.1.1.0 0x205d355d58465016 https://staging.coherosscope.com/api/ota/v1/

