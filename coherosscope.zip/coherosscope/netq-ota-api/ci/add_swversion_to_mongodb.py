import binascii
import datetime
import hashlib
import sys

import base64
import json
import subprocess
from pymongo import MongoClient
from pymongo.errors import OperationFailure
from bson.binary import Binary


def help(name):
    print "Usage: {} <sw name> <mcu fw version: major.minor.patch.build> <lora fw: x.y.z.w> <gsm fw: x.y.z.w> <gps fw: x.y.z.w>".format(name)


def parse_version(vString):
    v = 0
    if vString.count('.') != 3:
        raise ValueError('Illegal version:', vString)
    for i in vString.split('.'):
        v <<= 8
        v += int(i)
    return v

def mongo_client():
    db_host = 'localhost:27017'
    client = MongoClient(db_host)
    try:
        client.admin.devices.estimated_document_count()
        print "Using local Docker database"
    except OperationFailure:
        # Darn, authentication required
        print "Authenticating to Kubernetes cluster..."
        secrets = json.loads(subprocess.check_output(['kubectl', 'get', 'secrets', 'netq-config', '-o', 'json']))
        client = MongoClient(db_host,
            username=base64.b64decode(secrets['data']['mongo_username']),
            password=base64.b64decode(secrets['data']['mongo_password'])
        )
        client.admin.devices.estimated_document_count()
        print "OK"
    return client

def main(swName, mcuFwVersion, loraFwVersion, gsmFwVersion, gpsFwVersion):
    client = mongo_client()
    db = client.admin.swversions
    db.replace_one({'swName': swName}, {
        'swName': swName,
        'mcuFwVersion': parse_version(mcuFwVersion),
        'loraFwVersion': parse_version(loraFwVersion),
        'gsmFwVersion': parse_version(gsmFwVersion),
        'gpsFwVersion': parse_version(gpsFwVersion)
    }, upsert=True)


if __name__ == '__main__':
    if len(sys.argv) == 6:
        main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
    else:
        help(sys.argv[0])
