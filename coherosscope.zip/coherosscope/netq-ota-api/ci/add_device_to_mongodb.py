#!/usr/bin/python

from pymongo import MongoClient

client = MongoClient('localhost:27017')
db = client.admin.devices

data = {
    'name': 'Test-1',
    'devEui': '0000000000000001',
    'nwkSKey': '11111111111111111111111111111111',
    'appSKey': '22222222222222222222222222222222',
    'devAddr': '44444444',
    'mcuId': '0000000000000001',
    'enabled': True,
    'deviceGroupId': "0",
    'serialNumber': '66666666666666',
    'dataRateId': "3",
    'notes': "Just a test",
    'txPower': 1.5,
    'configVersion': 1,
    'configVersionInDevice': 0,
    'swVersion': '1.0.0',
}

db.replace_one({'mcuId': data['mcuId']}, data, upsert=True)

client.close()
