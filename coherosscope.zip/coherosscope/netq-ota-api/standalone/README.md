# Installation

1) Create a new server to AWS (e.g. Ubuntu 18.04.1 LTS).
1) Install docker:
    `sudo snap install docker`
1) Transfer configuration to server: `scp srv/ new-server:~/.`