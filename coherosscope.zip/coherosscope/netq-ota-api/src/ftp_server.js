'use strict'

const ftpd = require('simple-ftpd')
const { Readable } = require('stream');

const ftpHost = process.env.FTP_HOST || '127.0.0.1';
const ftpPort = process.env.FTP_PORT || 1337;

const mongoHost = process.env.npm_package_config_mongohost || 'localhost';
const mongoPort = process.env.npm_package_config_mongoport || '27017';
const mongoUsername = process.env.MONGO_USERNAME || '';
const mongoPassword = process.env.MONGO_PASSWORD || '';

console.log('Starting FTP server on:', ftpPort);

console.log('***');
console.log(`*** mongoDb: ${mongoHost}:${mongoPort}`);
console.log('***');

let mongoUri;
if (mongoUsername !== '' && mongoPassword !== '') {
  mongoUri = `mongodb://${mongoUsername}:${mongoPassword}@${mongoHost}:${mongoPort}/`;
} else {
  console.log('MongoDb: No credentials found, trying without...');
  mongoUri = `mongodb://${mongoHost}:${mongoPort}/`;
}

const mongoClient = require('mongodb').MongoClient;
const co = require('co');

/**
 * Get FTP token.
 * @param {string} token
 * @returns {string} FTP token if token is valid, otherwise throws an error
 */
let getFtpToken = co.wrap(function* (token) {
  const mongoDb = yield mongoClient.connect(mongoUri);
  const tokenCollection = mongoDb.collection('ftptokens');
  const ftpToken = yield tokenCollection.findOne({
    token: token,
    downloaded: false,
    timestamp: { $gt: new Date(Date.now() - 1000 * 60 * 10) } // 10 minutes in millis
  });
  mongoDb.close();
  if (ftpToken === null) {
    throw new Error("FTP token not valid");
  }
  return ftpToken;
});

/**
 * Get the firmware.
 * @param {string} fwType
 * @param {number} fwVersion
 */
let getFirmware = co.wrap(function* (fwType, fwVersion) {
  const mongoDb = yield mongoClient.connect(mongoUri);
  const fwCollection = mongoDb.collection('fw');
  const firmware = yield fwCollection.findOne({ version: fwVersion, type: fwType });
  mongoDb.close();
  if (firmware === null) {
    throw new Error("Firmware not found");
  }
  return firmware;
});

let markTokenAsUsed = co.wrap(function* (token) {
  const mongoDb = yield mongoClient.connect(mongoUri);
  const tokenCollection = mongoDb.collection('ftptokens');
  token.downloaded = true;
  token.downloadTime = new Date(Date.now());
  yield tokenCollection.replaceOne({token: token.token, downloaded: false}, token); // :D
  mongoDb.close();
});

/**
 * Parse filename to fw type and version
 * @param {string} filename
 */
function fwFilenameToTypeAndVersion(filename) {
  const parser = new RegExp('(\\S+)_(\\d)+\\.(\\d)+\\.(\\d)+\\.(\\d)+\\.bin');
  const values = filename.match(parser);
  if (values === null || values.length < 6) {
    throw new Error("Wrong filename format");
  }

  let version = parseInt(values[2]) << 24;
  version += parseInt(values[3]) << 16;
  version += parseInt(values[4]) << 8;
  version += parseInt(values[5]);

  return { type: values[1], version: version };
}

/**
 * Convert FW type and version as filename
 * @param {string} type
 * @param {number} version
 */
function fwTypeAndVersionToFilename(type, version) {
  return type + '_' +
    (version >> 24 & 0xFF).toString() + '.' +
    (version >> 16 & 0xFF).toString() + '.' +
    (version >> 8 & 0xFF).toString() + '.' +
    (version & 0xFF).toString() + '.bin';
}


/**
 *
 *      ##### ###### #####
 *      ##      ##   ##  ##
 *      ####    ##   #####
 *      ##      ##   ##
 *      ##      ##   ##
 *
 */
const ftpServer = ftpd({ host: ftpHost, port: ftpPort, maxConnections: 5, root: '' }, (session) => {

  session.on('pass', (username, password, cb) => {
    co(function*() {
      const mongoDb = yield mongoClient.connect(mongoUri);
      const tokenCollection = mongoDb.collection('ftptokens');
      const token = yield tokenCollection.findOne({
        username: username,
        password: password,
        downloaded: false,
        timestamp: { $gt: new Date(Date.now() - 1000 * 60 * 10) } // 10 minutes in millis
      });
      mongoDb.close();

      if (!token) {
        throw new Error('No valid token');
      }

      cb(null, 'Welcome');

    }).catch((err) => {
      console.log(err);
      cb(new Error("Forbidden"), null);
    });
  });

  session.on('stat', (pathName, cb) => {
    // console.log('*** got stat, pathName', pathName);
    co(function*() {
      const params = pathName.split('/');
      const token = yield getFtpToken(params[1]);
      const fstat = params.length < 3 ? parseInt('0040440', 8) : parseInt('0100440', 8);
      let fsize = 0;
      let mtime = 0;
      if (params.length >= 3) {
        const fwInfo = fwFilenameToTypeAndVersion(params[2]);
        const firmware = yield getFirmware(fwInfo.type, fwInfo.version);
        fsize = firmware.size;
        mtime = firmware.mtime;
      }

      cb(null, {
        mode: fstat,    // fs.stat modes
        size: fsize,    // size in bytes
        mtime: mtime,   // last modification time
      });

    }).catch((err) => {
      console.log(err);
      cb(new Error("Forbidden"), null);
    });
  });

  session.on('readdir', (pathName, cb) => {
    // console.log('*** got readdir, pathName', pathName);
    co(function*() {
      const params = pathName.split('/');
      const token =  yield getFtpToken(params[1]);
      const fwInfo = fwFilenameToTypeAndVersion(token.filename);
      const mongoDb = yield mongoClient.connect(mongoUri);
      const fwCollection = mongoDb.collection('fw');
      const items = yield fwCollection.find({type: fwInfo.type, version: fwInfo.version}).toArray();
      let files = [];
      items.forEach(element => {
        files.push(fwTypeAndVersionToFilename(element.type, element.version));
      });
      // console.log(files);
      cb(null, files);

    }).catch((err) => {
      cb(new Error("Forbidden"), null);
    });
  });

  session.on('read', (pathName, offset, cb) => {
    // console.log('*** got read, pathName', pathName, "offset", offset);
    co(function*() {
      const params = pathName.split('/');
      const token = yield getFtpToken(params[1]);
      const filename = params[2];

      if (filename !== token.filename) {
        throw new Error("File not authorized:", filename, "access to:", token.filename);
      }

      const fwInfo = fwFilenameToTypeAndVersion(filename);
      const firmware = yield getFirmware(fwInfo.type, fwInfo.version);

      let bytesToSend = firmware.size;
      const fwStream = new Readable({
        read(size) {
          if (bytesToSend > 0) {
            this.push(firmware.data.read(firmware.size - bytesToSend, Math.min(size, bytesToSend)));
            bytesToSend -= Math.min(size, bytesToSend);
          } else {
            // Sending data is finished
            this.push(null);
          }
        }
      });
      yield markTokenAsUsed(token);
      cb(null, fwStream);

    }).catch((err) => {
      console.log(err);
      cb(new Error("Forbidden"), null);
    });
  });

  session.on('write', (pathName, offset, cb) => {cb(new Error("Forbidden"))});
  session.on('mkdir', (pathName, cb) => {cb(new Error("Forbidden"))});
  session.on('unlink', (pathName, cb) => {cb(new Error("Forbidden"))});
  session.on('rename', (fromName, toName, cb) => {cb(new Error("Forbidden"))});
  session.on('remove', (pathName, cb) => {cb(new Error("Forbidden"))});

});
