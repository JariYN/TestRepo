"use strict";

const express = require('express');
const bodyParser = require('body-parser');
const http = require('http');
const getRawBody = require('raw-body');
const contentType = require('content-type');

const configReq = require('./file_download_request_message_pb');
const configRsp = require('./file_download_response_message_pb');
const long = require('long');

const jspb = require('google-protobuf');

/**
 * Mongo DB initialization/configuration
 */

const port = process.env.npm_package_config_configApiPort;
const mongoHost = process.env.npm_package_config_mongohost || '';
const mongoPort = process.env.npm_package_config_mongoport || '';
const mongoUsername = process.env.MONGO_USERNAME || '';
const mongoPassword = process.env.MONGO_PASSWORD || '';
const ftpHost = process.env.FTP_HOST || 'localhost';
const ftpPort = process.env.FTP_PORT || 1337;

console.log('***');
console.log(`*** mongoDb: ${mongoHost}:${mongoPort}`);
console.log('***');

let mongoUri;
if (mongoUsername !== '' && mongoPassword !== '') {
  mongoUri = `mongodb://${mongoUsername}:${mongoPassword}@${mongoHost}:${mongoPort}/`;
} else {
  console.log('MongoDb: No credentials found, trying without...');
  mongoUri = `mongodb://${mongoHost}:${mongoPort}/`;
}

const mongoClient = require('mongodb').MongoClient;
const co = require('co');

/**
 * Express initialization
 */

const app = express();
app.listen(port, () => {
    console.log('RESTful API server started on: ' + port);
});

const rawParser = bodyParser.raw({type: 'application/octet-stream'});

function fixed64AsHexString(data, reqFieldNumber) {
    /**
     * Quite a hack to get UInt64 and convert it as a hex string.
     * By default BinaryReader returns UInt64 as (53bit) number, so, it
     * must be found and read as string that is converted to Long, which
     * is converted to string.
     */
    const reader = new jspb.BinaryReader(new Uint8Array(data));
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
          break;
        }
        const field = reader.getFieldNumber();
        if (field == reqFieldNumber) {
            const value = long.fromString(reader.readFixed64String(), true);
            return ("0000000000000000" + value.toString(16)).slice(-16);
        }
        reader.skipField();
    }
    return undefinedMcuId;
}

const undefinedMcuId = 'NOT_SET';
const fileTypes = {
    0: 'mcu',   // proto.FileDownloadRequestMessage.FileType.MCU_FIRMWARE
    1: 'lora',  // proto.FileDownloadRequestMessage.FileType.LORA_FIRMWARE
    2: 'gsm',   // proto.FileDownloadRequestMessage.FileType.GSM_FIRMWARE
    3: 'gps'    // proto.FileDownloadRequestMessage.FileType.GPS_FIRMWARE
};


/**
 * Convert FW type and version as filename
 * @param {number} type
 * @param {number} version
 */
function fwTypeAndVersionToFilename(type, version) {
    return fileTypes[type] + '_' +
      (version >> 24 & 0xFF).toString() + '.' +
      (version >> 16 & 0xFF).toString() + '.' +
      (version >> 8 & 0xFF).toString() + '.' +
      (version & 0xFF).toString() + '.bin';
}

function Http404Error(message) {
    this.name = 'Http404Error';
    this.message = message;
    this.stack = (new Error()).stack;
}
Http404Error.prototype = new Error;

let getDevice = co.wrap(function* (mcuId) {
    const mongoDb = yield mongoClient.connect(mongoUri);
    const collection = mongoDb.collection('devices');
    const item = yield collection.findOne({ mcuId: mcuId });
    mongoDb.close();
    if (!item) {
      throw new Http404Error("MCU ID not found");
    }
    return item;
});

let getFirmware = co.wrap(function* (type, version) {
    const mongoDb = yield mongoClient.connect(mongoUri);
    const collection = mongoDb.collection('fw');
    const item = yield collection.findOne({ type: type, version: version });
    mongoDb.close();
    if (!item) {
      throw new Http404Error("FW not found");
    }
    return item;
});

function getRandomString() {
    return Math.random().toString(36).substring(2); // [a-z0-9]{7,13}
}

let getNewToken = co.wrap(function* (fileType, fileVersion) {
    const mongoDb = yield mongoClient.connect(mongoUri);
    const collection = mongoDb.collection('ftptokens');
    const token = {
        timestamp: new Date(Date.now()),
        token: getRandomString(),
        filename: fwTypeAndVersionToFilename(fileType, fileVersion),
        downloaded: false,
        username: getRandomString(),
        password: getRandomString(),
    };
    let retries = 0;
    while (yield collection.findOne({ token: token.token, downloaded: false, timestamp: { $gt: new Date(Date.now() - 60000) }})) {
        token.token = getRandomString() + '_' + retries.toString();
        if (++retries > 9999) {
            mongoDb.close();
            throw new Error('Generation of ftpToken failed');
        }
    }
    yield collection.insertOne(token);

    mongoDb.close();
    return token;
});

let getGlobalConfig = co.wrap(function* () {
    const mongoDb = yield mongoClient.connect(mongoUri);
    const collection = mongoDb.collection('global');
    const item = yield collection.findOne({});
    mongoDb.close();
    return item || {};
});


/**
 * Handle POST /
 */
app.post('/v1/', rawParser, (req, res) => {

    if (!req.body) return res.sendStatus(400); // Bad Request

    console.log("*** input /api/ota/v1/ ***");

    co(function*() {

        const msgIn = proto.FileDownloadRequestMessage.deserializeBinary(new Uint8Array(req.body));
        const obj = msgIn.toObject();
        obj.mcuId = fixed64AsHexString(req.body, 3);

        if (obj.mcuId === undefinedMcuId) {
            console.log('MCU ID not set');
            res.sendStatus(400); // Bad request
            return;
        }

        if (!obj.fileVersion) {
            console.log('file version not set');
            res.sendStatus(400); // Bad request
            return;
        }

        if (obj.fileType === undefined || !fileTypes[obj.fileType]) {
            console.log('file type is not set or it has unsupported value');
            res.sendStatus(400); // Bad request
            return;
        }

        yield getDevice(obj.mcuId);
        const fw = yield getFirmware(fileTypes[obj.fileType], obj.fileVersion);
        const token = yield getNewToken(obj.fileType, obj.fileVersion);

        const serverConfig = new proto.FileDownloadResponseMessage.ServerConfig();
        serverConfig.setProtocol(proto.FileDownloadResponseMessage.Protocol.PROTOCOL_FTP);
        serverConfig.setServerName(ftpHost);
        serverConfig.setServerPort(ftpPort);
        serverConfig.setUsername(token.username);
        serverConfig.setPassword(token.password);
        serverConfig.setSecureMode(proto.FileDownloadResponseMessage.SecureMode.FTP_SECURE_DISABLED);
        serverConfig.setFtpMode(proto.FileDownloadResponseMessage.FtpMode.FTP_MODE_PASSIVE);

        const msgOut = new proto.FileDownloadResponseMessage();
        msgOut.setServer(serverConfig);
        msgOut.setPath(token.token);
        msgOut.setFilename(token.filename);
        msgOut.setCrc32(fw.crc32);
        msgOut.setMd5(fw.md5);

        // console.log('response:', msgOut);

        res.set('Content-Type', 'application/octet-stream');
        res.status(200).send(new Buffer(msgOut.serializeBinary())); // OK

    }).catch(function(err) {
        if (err instanceof Http404Error) {
            console.log(err.message);
            res.sendStatus(404); // Not Found
        } else {
            console.log(err.stack);
            res.sendStatus(500); // Internal Server Error
        }
    });

});

/**
 * Handle GET /
 */
app.get('/', (req, res) => {
    res.send('OK')
});