# OTA API

API for Netq device to get latest firmware.

# API Definition

API has two Google Protocol Buffer formatted (binary) messages: request and response.

Actual firmware is been downloaded by FTP.

## Messages

Message definitions, see `netq-api/ota_api`.

## Returned HTTP statuses

- `200`: New configuration is send in response
- `400`: Illegal request, e.g. mcuId is missing
- `404`: No requested firmware is found
- `500`: Internal server error

---

# Developing with local database

```bash
# Override MongoDB address (needs to be configure only once)
npm config set ota_api:mongohost localhost
npm config set ota_api:configApiPort 3001    # port can be changed too

# start database and initialize it with some data
cd ci/
sh install_mongodb.sh
cd ..

# update libs and start device api
npm install
# Hack the ftpd...
npm start

# Ctrl-C to stop device api

# stop all and restore overrides
docker stop netq-mongodb.default
mnp config delete ota_api:mongohost
npm config delete ota_api:configApiPort

```

---

# Running Travis CI tests locally

```bash
# Requires:
# - node.js v8
# - jq
# - protobuf and pymongo python libs

# Install What Would Travis Do (a Ruby gem)
gem install wwtd

# Run .travis.yml with couple of extra fields
wwtd -u install -u after_script
```

# Installation to Kubernetes

## Install secrets

```bash
# Create secrets
kubectl create -f k8s/ota_api-configs.yml

# Edit secrets
# Note, you can encode values like: echo -n "new value" | base64
kubectl edit secret web-api-configs
```

## Install application

```bash
kubectl create -f k8s/ota_api-app.yml
```

## Test installation

```bash
# Port forward to Kubernetes
kubectl port-forward netq-ota-api-... 3000:3000

# Request parameters for MCU ID 1 (use MCU ID that has been configured)
python ci/send_request.py 1 http://localhost:3000/v1
```