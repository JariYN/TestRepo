# Config API

API for Netq device to get its configuration (e.g. LoRaWAN configuration).

# API Definition

API has two Google Protocol Buffer formatted (binary) messages: request and response.

## Messages

Message definitions, see `netq-api/config_api`.

## Returned HTTP statuses

- `200`: New configuration is send in response
- `204`: Device has the latest configuration already
- `400`: Illegal request, e.g. mcuId is missing
- `404`: No configuration for the device found
- `500`: Internal server error

---

# Developing with local database

```bash
# Override MongoDB address (needs to be configure only once)
npm config set config_api:mongohost localhost
npm config set config_api:configApiPort 3001    # port can be changed too

# start database
docker run --name netq-mongodb.default -d --rm -p 27017:27017 mongo:3.6.4-jessie

# update libs and start device api
npm install
npm start

# Ctrl-C to stop device api

# stop all and restore overrides
docker stop netq-mongodb.default
mnp config delete config_api:mongohost
npm config delete config_api:configApiPort

```

# Developing with database in Kubernetes

```bash
# Override MongoDB address (needs to be configure only once)
npm config set config_api:mongohost localhost
npm config set config_api:configApiPort 3001    # port can be changed too

export MONGO_USERNAME=_USERNAME_
export MONGO_PASSWORD=_PASSWORD_
sh start_with_kube_database.dh

# To restore overrides (if necessary)
mnp config delete config_api:mongohost
npm config delete config_api:configApiPort
```

---

# Running Travis CI tests locally

```bash
# Requires:
# - node.js v8
# - jq
# - protobuf and pymongo python libs

# Install What Would Travis Do (a Ruby gem)
gem install wwtd

# Run .travis.yml with couple of extra fields
wwtd -u install -u after_script
```

# Installation to Kubernetes

## Install secrets

```bash
# Create secrets
kubectl create -f k8s/config_api-configs.yml

# Edit secrets
# Note, you can encode values like: echo -n "new value" | base64
kubectl edit secret web-api-configs
```

## Install application

```bash
kubectl create -f k8s/config_api-app.yml
```

## Test installation

```bash
# Port forward to Kubernetes
kubectl port-forward netq-config-api-... 3000:3000

# Request parameters for MCU ID 1 (use MCU ID that has been configured)
python ci/send_request.py 1 http://localhost:3000/v1
```