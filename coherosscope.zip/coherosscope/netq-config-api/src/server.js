"use strict";

const express = require('express');
const bodyParser = require('body-parser');
const http = require('http');
const getRawBody = require('raw-body');
const contentType = require('content-type');

const configReq = require('./config_request_message_pb');
const configRsp = require('./config_response_message_pb');
const long = require('long');

const jspb = require('google-protobuf');

const mapDataRate = {
    '0': proto.ConfigResponseMessage.EU868DataRate.DR0,
    '1': proto.ConfigResponseMessage.EU868DataRate.DR1,
    '2': proto.ConfigResponseMessage.EU868DataRate.DR2,
    '3': proto.ConfigResponseMessage.EU868DataRate.DR3,
    '4': proto.ConfigResponseMessage.EU868DataRate.DR4,
    '5': proto.ConfigResponseMessage.EU868DataRate.DR5,
    '6': proto.ConfigResponseMessage.EU868DataRate.DR6,
    '7': proto.ConfigResponseMessage.EU868DataRate.DR7,
    '15': proto.ConfigResponseMessage.EU868DataRate.DR15
}

const defaults = {
    dataRate: '3'
}
const undefinedMcuId = 'NOT_SET';
const nonGroupedDeviceGroupId = '0';

/**
 * Mongo DB initialization/configuration
 */

const port = process.env.npm_package_config_configApiPort;
const mongoHost = process.env.npm_package_config_mongohost || '';
const mongoPort = process.env.npm_package_config_mongoport || '';
const mongoUsername = process.env.MONGO_USERNAME || '';
const mongoPassword = process.env.MONGO_PASSWORD || '';

console.log('***');
console.log(`*** mongoDb: ${mongoHost}:${mongoPort}`);
console.log('***');

let mongoUri;
if (mongoUsername !== '' && mongoPassword !== '') {
    mongoUri = `mongodb://${mongoUsername}:${mongoPassword}@${mongoHost}:${mongoPort}/`;
} else {
    console.log('MongoDb: No credentials found, trying without...');
    mongoUri = `mongodb://${mongoHost}:${mongoPort}/`;
}

const mongoClient = require('mongodb').MongoClient;
/**
 * Express initialization
 */

const app = express();
app.listen(port, () => {
    console.log('RESTful API server started on: ' + port);
});

const rawParser = bodyParser.raw({ type: 'application/octet-stream' });


function fixed64AsHexString(data, reqFieldNumber) {
    /**
     * Quite a hack to get UInt64 and convert it as a hex string.
     * By default BinaryReader returns UInt64 as (53bit) number, so, it
     * must be found and read as string that is converted to Long, which
     * is converted to string.
     */
    const reader = new jspb.BinaryReader(new Uint8Array(data));
    while (reader.nextField()) {
        if (reader.isEndGroup()) {
            break;
        }
        const field = reader.getFieldNumber();
        if (field == reqFieldNumber) {
            const value = long.fromString(reader.readFixed64String(), true);
            return ("0000000000000000" + value.toString(16)).slice(-16);
        }
        reader.skipField();
    }
    return undefinedMcuId;
}

function hexStringToUint8Array(hexString) {
    let hexList = [];
    for (let i = 0; i + 1 < hexString.length; i += 2) {
        let msb = hexString[i];
        let lsb = hexString[i + 1];
        hexList.push(parseInt(msb + lsb, 16));
    }
    return new Uint8Array(hexList);
}

function appendFixed64FromHexString(origBuffer, fieldNumber, hexString) {
    if (!hexString) {
        const buf = new Uint8Array(origBuffer.length);
        buf.set(origBuffer);
        return buf;
    }
    const value = long.fromString(hexString, 16);
    const writer = new jspb.BinaryWriter();
    writer.writeFixed64String(fieldNumber, value.toString());
    const buf = writer.getResultBuffer();

    const resultBuffer = new Uint8Array(origBuffer.length + buf.length);
    resultBuffer.set(origBuffer);
    resultBuffer.set(buf, origBuffer.length);
    return resultBuffer;
}


/**
 * Handle POST /
 */
app.post('/v1/', rawParser, (req, res) => {

    if (!req.body) return res.sendStatus(400); // Bad Request

    console.log("*** input /api/config/v1/ ***");

    try {

        const msgIn = proto.ConfigRequestMessage.deserializeBinary(new Uint8Array(req.body));
        const obj = msgIn.toObject();
        obj.mcuId = fixed64AsHexString(req.body, 2);

        if (obj.mcuId === undefinedMcuId) {
            console.log('MCU ID not set');
            res.sendStatus(400); // Bad request
            return;
        }

        console.log('request:', obj);

        new Promise(function connectToMongo(resolve) {
            mongoClient.connect(mongoUri, { reconnectTries: 10, reconnectInterval: 2000 }).then(resolve).catch(function(err) {
                console.log('Connection to Mongo failed (tried 10 times), uri was: ' + mongoUri + ' error is: ' + err);
                console.log('Keeping trying...');
                return connectToMongo(resolve);
            })
        }).then(mongoDb => {
            console.log('Connected to Mongo, url is'+mongoUri);
            const devices = mongoDb.db('admin').collection('devices');
            //let device = yield devices.findOne({mcuId: obj.mcuId});
            devices.findOne({ mcuId: obj.mcuId }, (err, device) => {
                if (err) throw err;
                console.log('*** from mongo:', device);

                if (!device) {
                    mongoDb.close();
                    console.log('MCU ID not found:', obj.mcuId);
                    res.sendStatus(404); // Not Found
                    return;
                }
                console.log('Going to findOneAndUpdate');
                devices.updateOne( { _id: device._id },{ $set: { configVersionInDevice: obj.configVersion } }).catch(err => {
                    console.log('findOneAndUpdate failed');
                    console.log(err);
                });
                console.log('getting collection swversions')
                const swVersions = mongoDb.db('admin').collection('swversions');
                const deviceSwVersion = device.swVersion || '1.0.0';
                console.log('Going to find swVersion')
                swVersions.findOne({ swName: deviceSwVersion }, (err,deviceFwVersions) => {
                    if (err) throw err;
                    deviceFwVersions = deviceFwVersions || {};

                    if (obj.configVersion === device.configVersion &&
                        obj.mcuSwVersion === deviceFwVersions.mcuFwVersion &&
                        obj.loraSwVersion === deviceFwVersions.loraFwVersion &&
                        obj.gsmSwVersion === deviceFwVersions.gsmFwVersion &&
                        obj.gpsSwVersion === deviceFwVersions.gpsFwVersion) {
                        mongoDb.close();
                        console.log('Device has the latest config already, version', device.configVersion);
                        res.sendStatus(204); // No Content
                        return;
                    }

                    const msgOut = new proto.ConfigResponseMessage();
                    msgOut.setConfigVersion(device.configVersion || 0);
                    device.devAddr && msgOut.setDevAddr(parseInt(device.devAddr, 16));
                    device.appSKey && msgOut.setAppskey(hexStringToUint8Array(device.appSKey));
                    device.nwkSKey && msgOut.setNwkskey(hexStringToUint8Array(device.nwkSKey));
                    device.dataRateId && msgOut.setDataRate(mapDataRate[device.dataRateId]);
                    device.txPower && msgOut.setTxPower(Number((device.txPower * 10).toFixed()));
                    msgOut.setMcuSwVersion(deviceFwVersions.mcuFwVersion || 0);
                    msgOut.setLoraSwVersion(deviceFwVersions.loraFwVersion || 0);
                    msgOut.setGsmSwVersion(deviceFwVersions.gsmFwVersion || 0);
                    msgOut.setGpsSwVersion(deviceFwVersions.gpsFwVersion || 0);


                   new Promise((resolve) => {
                    if (device.deviceGroupId && device.deviceGroupId !== nonGroupedDeviceGroupId) {
                        devices.find({ deviceGroupId: device.deviceGroupId }).toArray((err, group) => {
                            if (err) throw err;
                            msgOut.setGroupSize(group.length);

                            console.log(group);

                            let groupIndex = 0;
                            for (groupIndex = 0; groupIndex < group.length; groupIndex++) {
                                console.log('comparing', group[groupIndex]._id, '==', device._id);
                                if (group[groupIndex].mcuId === device.mcuId) {
                                    console.log("exit loop", groupIndex);
                                    msgOut.setGroupIndex(groupIndex);
                                    resolve();
                                    break;
                                }
                            }
                        });
                    } else
                        resolve();
                   }).then(()=> {
                    mongoDb.db('admin').collection('global').findOne({},(err,globalConfig) => {
                        if (err) throw err;
                        globalConfig = globalConfig || {};
                        console.log('*** globalConfig:', globalConfig);


                        msgOut.setIndoorConfig(hexStringToUint8Array(globalConfig.indoorConfig || ''));
                        msgOut.setCloudUri(device.cloudUri || globalConfig.cloudUri || 'digilora.coheros.com');
                        msgOut.setAssistNowToken(globalConfig.assistNowToken || '');

                        mongoDb.close();

                        const rawBuffer = appendFixed64FromHexString(msgOut.serializeBinary(), 2, device.devEui);
                        console.log('response:', msgOut);

                        res.set('Content-Type', 'application/octet-stream');
                        res.status(200).send(new Buffer(rawBuffer)); // OK
                    });
                   })
                });
            });

        })
    }
    catch (err) {
        console.log(err.stack);
        res.sendStatus(500); // Internal Server Error
    };

});

/**
 * Handle GET /
 */
app.get('/', (req, res) => {
    res.send('OK')
});