#!/bin/bash

COMPONENT_NAME=config_api
COMMAND=$1
VERSION=$2

OK=0
FAIL=1

PATH="/usr/local/opt/gettext/bin:$PATH"
K8S_CONTEXT="$(kubectl config current-context)"


function show_brief_help {

    echo ""
    echo "USAGE: ${0} [ build | deploy | all | help ] <version>"

}


function show_help {

    [[ "$COMMAND" != "help" ]] && return $OK

    show_brief_help

    echo ""
    echo "Commands:"
    echo ""
    echo "    build     Build current sources and store it to DockerHub with given version"
    echo "    deploy    Deploy given version to Kubernetes"
    echo "    all       Do build and deploy"
    echo "    help      Show this help"
    echo ""
    echo "Arguments:"
    echo ""
    echo "    <version> Version to be build or deployed"
    echo ""

    return $FAIL
}


function check_params {

    if [ $# -eq 0 ]; then echo "ERROR: No parameters given"; else
    if [[ "$COMMAND" != "build"  && \
          "$COMMAND" != "deploy" && \
          "$COMMAND" != "all"    && \
          "$COMMAND" != "help"   ]]; then echo "ERROR: Unknown command: $COMMAND"; else
    if [[ -z "${VERSION}" ]]; then echo "ERROR: Version is missing"; else

        return $OK

    fi;fi;fi

    show_brief_help
    return $FAIL

}


function check_env_for_build {

    return $OK

}


function check_env_for_deploy {

    [[ "$COMMAND" != "deploy" && "$COMMAND" != "all" ]] && return $OK

    if [[ ! $(which envsubst) ]]; then echo "No envsubst found. Please install gettext package"; else
    if [[ "$K8S_CONTEXT" != "netq-test.k8s.local" ]]; then echo "Please set k8s context to netq-test.k8s.local"; else

        return $OK

    fi;fi

    return $FAIL

}


function build {

    [[ "$COMMAND" != "build" && "$COMMAND" != "all" ]] && return $OK

    echo ""
    echo "========================================"
    echo "Building coheros/netq:${COMPONENT_NAME}-${VERSION}"
    echo "========================================"
    echo ""

    docker build -t coheros/netq:${COMPONENT_NAME}-${VERSION} . && \
    docker push coheros/netq:${COMPONENT_NAME}-${VERSION}

}


function deploy {

    [[ "$COMMAND" != "deploy" && "$COMMAND" != "all" ]] && return $OK

    echo ""
    echo "========================================"
    echo "Deploying ${COMPONENT_NAME}-${VERSION} to $K8S_CONTEXT"
    echo "========================================"
    echo ""

    VERSION=$VERSION envsubst < ./k8s/${COMPONENT_NAME}-app.yml.template > ./k8s/${COMPONENT_NAME}-app.yml && \
    kubectl apply -f ./k8s/${COMPONENT_NAME}-app.yml

}


##   ##  ####  #### ##  ##
### ### ##  ##  ##  ### ##
## # ## ######  ##  ## ###
##   ## ##  ## #### ##  ##

show_help               && \
check_params         $* && \
check_env_for_build     && \
check_env_for_deploy    && \
build                   && \
deploy
