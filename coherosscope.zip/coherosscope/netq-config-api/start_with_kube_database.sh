#!/bin/bash
#
# Start netq-front and its counterpart API, netq-web-api locally
# but use databases from Kubernetes
#

MONGO_POD='netq-mongodb-6f645964f9-462kg'
DIR=$(dirname "$0")

trap "trap - SIGTERM && kill -- -$$" SIGINT SIGTERM EXIT

function load_config() {
    local CONFIG=$1
    if [ -f "${DIR}/${CONFIG}.sh" ]; then
        source "${DIR}/${CONFIG}.sh"
    fi
}


function check_credentials {

    load_config mongodb_credentials

    [[ ! ${MONGO_USERNAME+x} ]] && echo "export MONGO_USERNAME" && return 1
    [[ ! ${MONGO_PASSWORD+x} ]] && echo "export MONGO_PASSWORD" && return 1

    return 0

}


function port_forward {

    local KUBE_POD=$1
    local KUBE_PORTS=$2
    local KUBE_CMD="kubectl port-forward $KUBE_POD $KUBE_PORTS"

    IS_RUNNING=$(ps -ef | grep -c "$KUBE_CMD")

    if [[ $IS_RUNNING -lt 2 ]]; then

        echo "Opening port forward to $KUBE_POD $KUBE_PORTS"
        while true; do $KUBE_CMD > /dev/null; done &
        sleep 10

    fi

    return 0

}


function start_config_api {

    npm install
    npm start

}



##   ##  ####  #### ##  ##
### ### ##  ##  ##  ### ##
## # ## ######  ##  ## ###
##   ## ##  ## #### ##  ##

check_credentials                                && \
port_forward      "$MONGO_POD"    "27017:27017"  && \
start_config_api

