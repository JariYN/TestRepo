#!/bin/bash

CI_DIR="$(dirname "${BASH_SOURCE[0]}")"
DATA=$(python $CI_DIR/send_config_request.py)

PASSED=0
FAILED=0

# *** Test Lib ***
# Try to use natural language

field() {
    FIELD=$1
    OPERAND=$2
    EXPECTED=$3
    VALUE=$(echo $DATA | jq -r "$FIELD")

    if [[ $? -ne 0 ]]; then
        ((FAILED++))
        return 1
    fi

    case $OPERAND in
        is)
            if [[ $VALUE != $EXPECTED ]]; then
                echo "FAIL: $FIELD: $VALUE != $EXPECTED"
                ((FAILED++))
                return 1
            fi
            ;;
        *)
            echo "Unknown operand: $OPERAND"
            return 1
    esac
    ((PASSED++))
}


show_summary() {
    echo ""
    echo "------------------------------"
    echo "TOTAL: $((PASSED+FAILED)), PASSED: $PASSED, FAILED: $FAILED"
    echo ""

    if [[ $FAILED -eq 0 ]]; then
        echo "*** PASSED ***"
        echo ""
        return 0
    else
        echo "*** FAILED ***"
        echo ""
        return 1
    fi
}

# *** Test Cases ***

field '.[0].status_code' is 204

field '.[1].status_code' is 200
field '.[1].response.config_version' is 2
field '.[1].response.dev_eui' is '0000000000000002'
field '.[1].response.dev_addr' is '44444444'
field '.[1].response.appskey' is '22222222222222222222222222222222'
field '.[1].response.nwkskey' is '11111111111111111111111111111111'
field '.[1].response.data_rate' is 3
field '.[1].response.group_size' is 0
field '.[1].response.group_index' is 0
field '.[1].response.indoor_config' is ''
field '.[1].response.cloud_uri' is 'cloud4all.com'
field '.[1].response.tx_power' is 15
field '.[1].response.assist_now_token' is 'token4all'
field '.[1].response.mcu_sw_version' is 256
field '.[1].response.lora_sw_version' is 512
field '.[1].response.gsm_sw_version' is 1
field '.[1].response.gps_sw_version' is 2

field '.[2].status_code' is 200
field '.[2].response.dev_eui' is '0000000000000003'
field '.[2].response.group_size' is 2
field '.[2].response.group_index' is 0

field '.[3].status_code' is 200
field '.[3].response.dev_eui' is '0000000000000004'
field '.[3].response.group_size' is 2
field '.[3].response.group_index' is 1

field '.[4].status_code' is 200
field '.[4].response.config_version' is 1
field '.[4].response.dev_eui' is '0000000000000005'
field '.[4].response.mcu_sw_version' is 256
field '.[4].response.lora_sw_version' is 512
field '.[4].response.gsm_sw_version' is 1
field '.[4].response.gps_sw_version' is 2

field '.[5].status_code' is 200
field '.[5].response.config_version' is 1
field '.[5].response.dev_eui' is '0000000000000006'
field '.[5].response.mcu_sw_version' is 0
field '.[5].response.lora_sw_version' is 0
field '.[5].response.gsm_sw_version' is 0
field '.[5].response.gps_sw_version' is 0

field '.[6].status_code' is 200
field '.[6].response.config_version' is 0
field '.[6].response.cloud_uri' is 'cloud-7.com'
field '.[6].response.assist_now_token' is 'token4all'
field '.[6].response.mcu_sw_version' is 0
field '.[6].response.lora_sw_version' is 0
field '.[6].response.gsm_sw_version' is 0
field '.[6].response.gps_sw_version' is 0
field '.[6].response.dev_addr' is '00000000'
field '.[6].response.appskey' is ''
field '.[6].response.nwkskey' is ''
field '.[6].response.data_rate' is 0

# *** Show test summary and pass result to Travis ***
show_summary