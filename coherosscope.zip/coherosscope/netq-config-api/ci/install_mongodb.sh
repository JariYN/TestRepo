#!/bin/bash
docker run --name netq-mongodb.default -d --rm -p 27017:27017 mongo:3.6.4-jessie
