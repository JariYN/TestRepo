#!/usr/bin/python

import datetime
import requests
import sys
import time
import config_request_message_pb2 as config_req
import config_response_message_pb2 as config_rsp
import json

NOW = datetime.datetime.utcnow()

def as_hex_string(data):
    ret = ""
    for i in data:
        ret += "{:02X}".format(ord(i))
    return ret

def send_request(req):

    res = requests.post(
        url='http://localhost:3000/v1/',
        data=req.SerializeToString(),
        headers={'Content-Type': 'application/octet-stream'})

    ret = {'status_code': res.status_code, 'response': {}}

    if res.status_code == 200:
        rsp = config_rsp.ConfigResponseMessage()
        rsp.ParseFromString(res.content)
        ret['response']['config_version'] = rsp.config_version
        ret['response']['dev_eui'] = "{:016X}".format(rsp.dev_eui)
        ret['response']['dev_addr'] = "{:08X}".format(rsp.dev_addr)
        ret['response']['appskey'] = as_hex_string(rsp.appskey)
        ret['response']['nwkskey'] = as_hex_string(rsp.nwkskey)
        ret['response']['data_rate'] = rsp.data_rate
        ret['response']['group_size'] = rsp.group_size
        ret['response']['group_index'] = rsp.group_index
        ret['response']['indoor_config'] = as_hex_string(rsp.indoor_config)
        ret['response']['cloud_uri'] = rsp.cloud_uri
        ret['response']['tx_power'] = rsp.tx_power
        ret['response']['assist_now_token'] = rsp.assist_now_token
        ret['response']['mcu_sw_version'] = rsp.mcu_sw_version
        ret['response']['lora_sw_version'] = rsp.lora_sw_version
        ret['response']['gsm_sw_version'] = rsp.gsm_sw_version
        ret['response']['gps_sw_version'] = rsp.gps_sw_version

    return ret


##   ##  ####  #### ##  ##
### ### ##  ##  ##  ### ##
## # ## ######  ##  ## ###
##   ## ##  ## #### ##  ##

def main():
    results = []

    req = config_req.ConfigRequestMessage()
    req.config_version = 1
    req.mcu_id = 0x0000000000000001
    req.mcu_sw_version = 3
    req.lora_sw_version = 4
    req.gsm_sw_version = 5
    req.gps_sw_version = 6
    results.append(send_request(req))

    # req.mcu_id = 0x0000000000000002
    # results.append(send_request(req))

    # req.mcu_id = 0x0000000000000003
    # results.append(send_request(req))

    # req.mcu_id = 0x0000000000000004
    # results.append(send_request(req))

    # req.mcu_id = 0x0000000000000005
    # results.append(send_request(req))

    # req.mcu_id = 0x0000000000000006
    # results.append(send_request(req))

    # req.mcu_id = 0x0000000000000007
    # results.append(send_request(req))

    print json.dumps(results)

if __name__ == '__main__':
    main()