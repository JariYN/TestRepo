#!/usr/bin/python

import csv
from pymongo import MongoClient

client = MongoClient('localhost:27017')
db = client.admin.devices

def add_or_update(data):
    if '_id' in data:
        del data['_id']

    db.find_one_and_replace({'mcuId': data['mcuId']}, data, upsert=True)

# No changes
data = {
    'name': 'Test-1',
    'devEui': '0000000000000001',
    'nwkSKey': '11111111111111111111111111111111',
    'appSKey': '22222222222222222222222222222222',
    'devAddr': '44444444',
    'mcuId': '0000000000000001',
    'enabled': True,
    'deviceGroupId': "0",
    'serialNumber': '66666666666666',
    'dataRateId': "3",
    'notes': "Just a test",
    'txPower': 1.5,
    'configVersion': 1,
    'configVersionInDevice': 0,
    'swVersion': '0.0.0-t'
}
add_or_update(data)

# Config has changes, sw is the same
data['name'] = 'Test-2'
data['mcuId'] = '0000000000000002'
data['devEui'] = '0000000000000002'
data['configVersion'] = 2
data['swVersion'] = '1.0.0-t'
add_or_update(data)

# Groups
data['name'] = 'Test-3'
data['mcuId'] = '0000000000000003'
data['devEui'] = '0000000000000003'
data['deviceGroupId'] = '1'
add_or_update(data)

data['name'] = 'Test-4'
data['mcuId'] = '0000000000000004'
data['devEui'] = '0000000000000004'
add_or_update(data)

# Difference in swVersions
data['name'] = 'Test-5'
data['mcuId'] = '0000000000000005'
data['devEui'] = '0000000000000005'
data['configVersion'] = 1
data['deviceGroupId'] = 0
add_or_update(data)

# Non-existent swVersion
data['name'] = 'Test-6'
data['mcuId'] = '0000000000000006'
data['devEui'] = '0000000000000006'
data['swVersion'] = '2.0.0-t'
add_or_update(data)

# Only pointer to next cloud
add_or_update({
#    'name': 'Test-7',
    'mcuId': '0000000000000007',
    'cloudUri': 'cloud-7.com',
#    'configVersion': 1,
#    'swVersion': '1.1.1-t'
})

sw_db = client.admin.swversions
sw_db.find_one_and_replace(
    { 'swName': '1.0.0-t' },
    {
        'swName': '1.0.0-t',
        'mcuFwVersion': 256,
        'loraFwVersion': 512,
        'gsmFwVersion': 1,
        'gpsFwVersion': 2,
    },
    upsert=True)

sw_db.insert_one({
    'swName': '0.0.0-t',
    'mcuFwVersion': 3,
    'loraFwVersion': 4,
    'gsmFwVersion': 5,
    'gpsFwVersion': 6,
})

sw_db.insert_one({
    'swName': '1.1.1-t',
    'mcuFwVersion': 0x01010100,
    'loraFwVersion': 0x01010000,
    'gsmFwVersion': 0x00000000,
    'gpsFwVersion': 0x00000000,
})


global_db = client.admin['global']
global_db.find_one_and_replace({}, {
    'cloudUri': 'cloud4all.com',
    'assistNowToken': 'token4all',
}, upsert=True)
