#!/usr/bin/python

import requests
import sys
import config_request_message_pb2 as config_req
import config_response_message_pb2 as config_rsp
import json

def as_hex_string(data):
    ret = ""
    for i in data:
        ret += "{:02X}".format(ord(i))
    return ret

def send_request(req, url):

    res = requests.post(
        url=url,
        data=req.SerializeToString(),
        headers={'Content-Type': 'application/octet-stream'})

    ret = {'status_code': res.status_code, 'response': {}}

    if res.status_code == 200:
        rsp = config_rsp.ConfigResponseMessage()
        rsp.ParseFromString(res.content)
        ret['response']['config_version'] = rsp.config_version
        ret['response']['dev_eui'] = "{:016X}".format(rsp.dev_eui)
        ret['response']['dev_addr'] = "{:08X}".format(rsp.dev_addr)
        ret['response']['appskey'] = as_hex_string(rsp.appskey)
        ret['response']['nwkskey'] = as_hex_string(rsp.nwkskey)
        ret['response']['data_rate'] = rsp.data_rate
        ret['response']['group_size'] = rsp.group_size
        ret['response']['group_index'] = rsp.group_index
        ret['response']['indoor_config'] = as_hex_string(rsp.indoor_config)
        ret['response']['cloud_uri'] = rsp.cloud_uri
        ret['response']['tx_power'] = rsp.tx_power
        ret['response']['assist_now_token'] = rsp.assist_now_token
        ret['response']['mcu_sw_version'] = rsp.mcu_sw_version
        ret['response']['lora_sw_version'] = rsp.lora_sw_version
        ret['response']['gsm_sw_version'] = rsp.gsm_sw_version
        ret['response']['gps_sw_version'] = rsp.gps_sw_version

        print "Hex:"
        for i in res.content:
            print "{:02X}".format(ord(i)),
        print ""


    return ret


##   ##  ####  #### ##  ##
### ### ##  ##  ##  ### ##
## # ## ######  ##  ## ###
##   ## ##  ## #### ##  ##

def main():

    if len(sys.argv) != 3:
        print "Usage:", sys.argv[0], "<mcu_id> <api url>"
        print "E.g.", sys.argv[0], "0x00000000000000FF http://localhost:3000/v1"
        print "or  ", sys.argv[0], "255 https://digilora.coheros.com/api/config/v1"
        return

    mcu_id = sys.argv[1]
    if mcu_id.startswith('0x'):
        mcu_id = int(mcu_id, 16)
    else:
        mcu_id = int(mcu_id)
    url = sys.argv[2]

    req = config_req.ConfigRequestMessage()
    req.config_version = 0
    req.mcu_id = mcu_id
    req.mcu_sw_version = 0
    req.lora_sw_version = 0
    req.gsm_sw_version = 0
    req.gps_sw_version = 0

    sys.stdout.write(req.SerializeToString())

    rsp = send_request(req, url)
    print json.dumps(rsp, indent=2)

if __name__ == '__main__':
    main()
