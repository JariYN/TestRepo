#!/bin/bash

COMMAND=$1

OK=0
FAIL=1

function check_env {
    [[ ! $(which wwtd) ]] && \
    echo "Please install wwtd (what would travis do):" && \
    echo "" && \
    echo "    gem install wwtd" && \
    echo "" && \
    return $FAIL

    [[ ! $(which docker) ]] && \
    echo "Please install docker. See" && \
    echo "" && \
    echo "    https://docs.docker.com/install/" && \
    echo "" && \
    return $FAIL

    return $OK
}

function run_tests {
    wwtd -u install -u after_script                      || \
    ( docker logs netq-config-api > test.log             && \
      docker stop netq-config-api                        && \
      docker stop netq-mongodb.default                   && \
      echo "*** netq-config-api logs stored to test.log"    \
    )
    return $OK
}

##   ##  ####  #### ##  ##
### ### ##  ##  ##  ### ##
## # ## ######  ##  ## ###
##   ## ##  ## #### ##  ##

check_env   && \
run_tests
