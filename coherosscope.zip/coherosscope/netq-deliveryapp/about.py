from PyQt5.QtWidgets import QMessageBox


def show_about():
    msgbox_str = "GUI for binding NETQ devices to certain customer\r\n" \
                 "Copyright © 2019 Coheros Oy\r\n" \
                 "\r\n" \
                 "Used open source APIs:\r\n" \
                 " QT (Copyright © The Qt Company)\r\n" \
                 " PyQt5 (Copyright © 2018 Riverbank Computing Limited <info@riverbankcomputing.com>)\r\n" \
                 " requests (Copyright © 2018 Kenneth Reitz)"

    msgbox = QMessageBox()
    msgbox.setWindowTitle('About')
    msgbox.setStyleSheet("QLabel{min-width: 700px;}");
    msgbox.setText(msgbox_str)
    msgbox.setDefaultButton(QMessageBox.Ok)
    msgbox.exec()
