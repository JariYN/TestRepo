import unittest
import json
import requests
from devicedb import DeviceDb, headers


def get_customer_device_bindings(customer):
    serials = []
    resp = requests.get('https://hansunapi.coherosscope.com:444/devices',
                        headers=headers, verify=False)
    whole_db = json.loads(resp.text)
    for db_entry in whole_db:
        if db_entry['customer'] == customer:
            serials.append(db_entry['ssn'])
    return serials


class TestDeviceCustomerBinding(unittest.TestCase):
    def test_customer_device_bindings__ok(self):
        customer = 'c1'
        expected_serials = ['0001', '0002', '1000', '12345678901234']
        device_db = DeviceDb()

        # check initial state (there is no devices for customer)
        serials = get_customer_device_bindings(customer)
        self.assertEqual(0, len(serials), 'customer {} has {} devices, should have none'.format(customer, serials))

        # add devices for customer
        unsent = device_db.bind_devices_to_customer(customer, expected_serials)
        self.assertEqual(0, len(unsent), 'devices {} not sent'.format(unsent))

        # check bound devices
        serials = get_customer_device_bindings(customer)
        self.assertEqual(len(expected_serials), len(serials), 'wrong number of devices bound to customer')
        for expected_serial in expected_serials:
            self.assertTrue(expected_serial in serials, 'serial {} not found'.format(expected_serial))
