from PyQt5.QtCore import pyqtSignal
from PyQt5.Qt import QThread
import requests
import json

headers = {
#    'api-key':'23fhsDF455HsgsDFRTbfht5nukllksddvs346grvsSse436geSDVhdsddv'
              'api-key':'test'

}


class CustomerDb(QThread):
    customers_ready = pyqtSignal(list)

    def __init__(self):
        QThread.__init__(self)
        self.customers = None

    def get_customers(self):
        return self.customers

    def run(self):
        self.customers = []
        try:
            resp = requests.get('https://hansunapi.coherosscope.com:444/customers', headers=headers, verify=False)
        except Exception as e:
            print(e)
        else:
            if 200 <= resp.status_code <= 230:
                whole_db = json.loads(resp.text)
                for dbEntry in whole_db:
                    self.customers.append(dbEntry['customerId'])
            else:
                print('Error: HTTP status {}'.format(resp.status_code))
        self.customers_ready.emit(self.customers)
