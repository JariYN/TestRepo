from PyQt5.QtCore import pyqtSignal
from PyQt5.Qt import QThread
import requests
import json

headers = {
#    'api-key':'23fhsDF455HsgsDFRTbfht5nukllksddvs346grvsSse436geSDVhdsddv'
              'api-key':'test'

}


class DeviceDb(QThread):
    devices_ready = pyqtSignal(list)
    serial_bound = pyqtSignal(list)

    def __init__(self):
        QThread.__init__(self)
        self.passed_devices = []
        self.start()

    def get_devices(self):
        return self.passed_devices

    def is_passed_device(self, serial_number):
        is_passed = False
        if serial_number in self.passed_devices:
            is_passed = True
        return is_passed

    def run(self):
        try:
            resp = requests.get('https://hansunapi.coherosscope.com/test-results?client=dummy',
                                headers=headers, verify=False)
        except Exception as e:
            print(e)
        else:
            if 200 <= resp.status_code <= 230:
                whole_db = json.loads(resp.text)

                for db_entry in whole_db:
                    if db_entry['client']:
                        if db_entry['status'] == 1:  # TODO: change this, real success code is 0
                            if not db_entry['serialNumber'] in self.passed_devices:
                                self.passed_devices.append(db_entry['serialNumber'])
        self.devices_ready.emit(self.passed_devices)

    def bind_devices_to_customer(self, customer, serial_numbers):
        unsent_numbers = serial_numbers.copy()
        post_data = {'customer': customer}
        for number in serial_numbers:
            post_data['ssn'] = number;
            try:
                resp = requests.post('https://hansunapi.coherosscope.com:444/devices', json=post_data,
                                     headers=headers, verify=False)
            except Exception as e:
                print(e)
            else:
                if 200 <= resp.status_code <= 230:
                    unsent_numbers.remove(number)
                    numbers = [number]
                    self.serial_bound.emit(numbers)
                else:
                    print('Error: HTTP status {}'.format(resp.status_code))
        return unsent_numbers
