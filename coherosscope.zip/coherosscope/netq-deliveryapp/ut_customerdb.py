import unittest
import json
import requests
from customerdb import CustomerDb, headers


def post_customer(customer):
    customer_json = {'customerId': customer}
    resp = requests.post('https://hansunapi.coherosscope.com:444/customers', json=customer_json,
                         headers=headers, verify=False)
    print(resp)


class TestCustomers(unittest.TestCase):

    def test_customer_fetch__ok(self):
        customer_db = CustomerDb()
        customer_db.start()
        customer_db.wait()

        customers = customer_db.get_customers()
        self.assertEqual(0, len(customers), '{} customers found, should be none'.format(customers))

        expected_customers = ['c1', 'c2', 'c5']
        for expected_customer in expected_customers:
            post_customer(expected_customer)

        customer_db = CustomerDb()
        customer_db.start()
        customer_db.wait()

        customers = customer_db.get_customers()
        self.assertEqual(len(expected_customers), len(customers), '{} customers found, should be {}'.format(len(customers), len(expected_customers)))
