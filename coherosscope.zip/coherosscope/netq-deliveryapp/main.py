from PyQt5 import QtWidgets
from app import AppWindow

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ui = AppWindow()

    ui.show()
    ret = app.exec_()

    sys.exit(ret)
