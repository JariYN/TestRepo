import sys
from PyQt5 import uic
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QMessageBox, QMainWindow, QWidget
from devicedb import DeviceDb
from customerdb import CustomerDb
from about import show_about


class AppWindow(QMainWindow):
    def __init__(self):
        QWidget.__init__(self)
        uic.loadUi("qtproject/prodshipping.ui", self)

        self.customer_db = CustomerDb()
        self.device_db = DeviceDb()

        # Menuitem 'About' added in runtime
        self.actionAbout = self.menuBar.addAction("About")
        self.actionAbout.triggered.connect(show_about)

        # signals
        self.editSerial.editingFinished.connect(self.serial_edit_finished)
        self.btnDelete.clicked.connect(self.btndelete_clicked)
        self.btnBind.clicked.connect(self.btnbind_clicked)
        self.boxCustomers.currentIndexChanged.connect(self.customer_selected)
        self.lstSerials.itemSelectionChanged.connect(self.item_selection_changed)
        self.customer_db.customers_ready.connect(self.customers_ready)
        self.device_db.serial_bound.connect(self.serial_bound)
        self.device_db.devices_ready.connect(self.devices_ready)

        self.customer_db.start()

    def customers_ready(self, customers):
        if len(customers) == 0:
            msgbox = QMessageBox()
            msgbox.setWindowTitle('No customers found')
            msgbox.setText('Check internet connection and launch application again')
            msgbox.setStandardButtons(QMessageBox.Abort)
            msgbox.exec()
            sys.exit()
        else:
            self.boxCustomers.clear()
            self.boxCustomers.addItem('<please select>')
            for customer in customers:
                self.boxCustomers.addItem(customer)

    def devices_ready(self, devices):
        if len(devices) == 0:
            msgbox = QMessageBox()
            msgbox.setWindowTitle('No tested devices')
            msgbox.setText('Check internet connection and launch application again')
            msgbox.setStandardButtons(QMessageBox.Abort)
            msgbox.exec()
            sys.exit()

    def serial_edit_finished(self):
        serial_number = self.editSerial.displayText()
        if self.editSerial.hasFocus() and serial_number != '':
            if self.device_db.is_passed_device(serial_number):
                if len(self.lstSerials.findItems(serial_number, Qt.MatchExactly)) == 0:
                    self.lstSerials.addItem(serial_number)
                    self.btnBind.setEnabled(True)
                    self.editSerial.clear()
            else:
                print('Seems that device is not tested')
                msgbox = QMessageBox()
                msgbox.setWindowTitle('Device not tested')
                msgbox.setText('Serial number {} not found from database'.format(serial_number))
                msgbox.setStandardButtons(QMessageBox.Ok)
                msgbox.exec()

    def btnbind_clicked(self):
        serial_numbers = []
        customer = self.boxCustomers.currentText()
        for i in range(self.lstSerials.count()):
            serial_numbers.append(self.lstSerials.item(i).text())
        if len(serial_numbers) > 0:
            list_of_unsent = self.device_db.bind_devices_to_customer(customer, serial_numbers)
            print('numbers unsent')
            print(list_of_unsent)

    def serial_bound(self, serials):
        for serial in serials:
            items = self.lstSerials.findItems(serial, Qt.MatchExactly)
            self.remove_items_from_list(items)

    def btndelete_clicked(self):
        items = self.lstSerials.selectedItems()
        self.remove_items_from_list(items)

    def remove_items_from_list(self, items):
        for item in items:
            self.lstSerials.takeItem(self.lstSerials.row(item))
        if self.lstSerials.count() == 0:
            self.lstSerials.setEnabled(False)
            self.btnBind.setEnabled(False)

    # gets called when combobox content is changed
    def customer_selected(self, index):
        if index > 0:
            self.editSerial.setEnabled(True)
            self.lstSerials.setEnabled(True)
            self.editSerial.setFocus()
        else:
            self.editSerial.setEnabled(False)
            self.lstSerials.setEnabled(False)
            self.btnBind.setEnabled(False)

    # gets called when serial number is selected from list
    def item_selection_changed(self):
        items = self.lstSerials.selectedItems()
        if len(items) > 0:
            self.btnDelete.setEnabled(True)
        else:
            self.btnDelete.setEnabled(False)
