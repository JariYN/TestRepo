#!/usr/bin/env python

import base64
import json
import subprocess
from pymongo import MongoClient
from pymongo.errors import OperationFailure

collections = ['deviceGroups', 'ftptokens', 'fw', 'global', 'swversions']

def mongo_client():
    ''' Try without credentials at first (local mongo).
        If no luck, dig credentials from Kube secrets.
    '''
    db_host = 'localhost:27017'
    client = MongoClient(db_host)
    try:
        client.admin.devices.estimated_document_count()
        print "Using local Docker database"
    except OperationFailure:
        # Darn, authentication required
        print "Authenticating to Kubernetes cluster..."
        secrets = json.loads(subprocess.check_output('kubectl get secrets netq-config -o json'.split()))
        client = MongoClient(db_host,
            username=base64.b64decode(secrets['data']['mongo_username']),
            password=base64.b64decode(secrets['data']['mongo_password'])
        )
        client.admin.devices.estimated_document_count()
        print "OK"
    return client


def create_collections(db):
    for collection in collections:
        db.create_collection(collection)


def add_default_global_config(db):
    db['global'].replace_one({}, {
            'ftpServer': 'demo2.coherosscope.com',
            'ftpPort': '1337',
            'cloudUri': 'demo2.coherosscope.com',
            'indoorConfig': '',
            'assistNowToken': 'ShkjM1CUFkyQ2KlSvgIJ6Q',
        }, upsert=True)

def add_swversions(db):
    db.swversions.insert_one({
        'swName': '1.1.0',
        'mcuFwVersion': 16842752,
        'loraFwVersion': 16842752,
        'gsmFwVersion': 0,
        'gpsFwVersion': 0,
    })


##   ##  ####  #### ##  ##
### ### ##  ##  ##  ### ##
## # ## ######  ##  ## ###
##   ## ##  ## #### ##  ##

def main():
    client = mongo_client()
    db = client.admin

    create_collections(db)
    add_default_global_config(db)
    add_swversions(db)

    client.close()


if __name__ == '__main__':
    main()
