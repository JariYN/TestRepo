#!/bin/bash

K8S_CONTEXT="demo2.coherosscope.com"
DIR=$(dirname "$0")

FAIL=1
OK=0

function check_env {

  echo $DIR
  # return $FAIL

  local CURRENT_K8S_CONTEXT="$(kubectl config current-context)"

  [[ "$K8S_CONTEXT" != "$CURRENT_K8S_CONTEXT" ]] && echo "Please use context $K8S_CONTEXT" && return $FAIL
  return $OK

}

function find_pod {

  local POD_NAME="$1"

  echo $(kubectl get pods | grep -e "^$POD_NAME-[0-9a-f]\{9,10\}-[0-9a-z]\{5\}.*1/1" | awk '{print $1}')
  return $OK

}

function connect_to_db {

  echo "Connecting to database server"
  kubectl port-forward $(find_pod netq-database) 9200:9200 &
  DATABASE_PID=$!
  sleep 10

  return $OK

}

function disconnect_from_db {

  echo "Disconnecting database"
  kill $DATABASE_PID
  return $OK

}

function init_data_db {

  echo "Initializing index: data"

  curl -H "Content-Type: application/json" -XPUT "http://localhost:9200/data_v1" -d @"$DIR/data.schema"
  curl -H "Content-Type: application/json" -XPOST "http://localhost:9200/_aliases" -d'
  {
    "actions": [
      {"add": {"alias": "data", "index": "data_v1"}}
    ]
  }
  '

  return $OK

}

function init_raw_db {

  echo "Initializing index: raw"

  curl -H "Content-Type: application/json" -XPUT "http://localhost:9200/raw_v1"
  curl -H "Content-Type: application/json" -XPOST "http://localhost:9200/_aliases" -d'
  {
    "actions": [
      {"add": {"alias": "raw", "index": "raw_v1"}}
    ]
  }
  '

  return $OK

}

function init_error_db {
  echo "Initializing index: error"
  curl -H "Content-Type: application/json" -XPUT "http://localhost:9200/error_v1"
  curl -H "Content-Type: application/json" -XPOST "http://localhost:9200/_aliases" -d'
  {
    "actions": [
      {"add": {"alias": "error", "index": "error_v1"}}
    ]
  }
  '

  return $OK

}

check_env           && \
connect_to_db       && \
init_data_db        && \
init_raw_db         && \
init_error_db       && \
disconnect_from_db  && \
echo "Done"
