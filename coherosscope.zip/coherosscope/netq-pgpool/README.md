# netq-pgpool
PGPool server for proxying and load balancing PG connections from K8 to outside
See picture at https://github.com/coheros/netq-pgpool/issues/3

## Content for PgPool pod
```
Dockerfile              For creating a image for PgPool POD
known_hosts.template    List of replica (and primary) nodes so PgPool can create SSH connection to replica node.
pcp.conf                Username and password(md) for PCP commands.
pgpool.template.conf    PgPool configuration file. This file include all nodes.
pool_hba.conf           PgPool authencation file
pool_passwd             md5 passwords used in pool_hba.conf
postgres.pem            RSA key for PgPool to connect nodes.
ec2                     Folder containing files needed for node ec2.
ec2/.pcppass            PCP password for node to connect PGPool. Used by attach_node.sh
ec2/attach_node.sh      Run this script to attach deattached node into the pool.
ec2/new_customer.sql    Used by new_customer.sh
ec2/new_customer.sh     Run this command when adding new HERO user. See section "Add user to database"
ec2/pg_hba.conf         Postgres permission configuration file. Need to be identical in each node.
ec2/postgresql.conf     Postgres configuration file.

```
## Attaching and manipulating nodes.

PgPool is commanded with PCP commands, see http://www.pgpool.net/docs/latest/en/html/pcp-commands.html

Password for PgPool PCP is ggs3h843Hs16bSAuW

## Add client user to databaser

SSH to PRIMARY postgresql server (To see which are primary, use pcp_node_info command).

Make sure scripts new_customer.sh and new_customer.psql are on server.

Run "sh new_customer.sh CUSTOMERNAME", it will create stuff for customer CUSTOMERNAME.

Once you have created a keycloak realm to the customer, update realm public key into customers creditials table in postgresql.


## Add user to database (OTHER THAN client)
In pgpool node run ```pg_md5 --md5auth --username=username password```
If an error raises, make sure you /etc/pool_passwd has permission to be opened.

Copy content of /etc/pool_passwd to this repository and fix line breaks.

Then add user credentials also to pool_hba.conf file.

User creditentals also need to be in each node's pg_hba.conf AND in the database itself