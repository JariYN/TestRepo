#Run this on primary Postgresql server, eg: "sh new_customer.sh demo" will create a customer "demo"

psql -h localhost -p 5432 -d hero -c "CREATE USER $1 PASSWORD 'fas42SDG75'";
psql -h localhost -p 5432 -d hero -c "CREATE SCHEMA AUTHORIZATION $1"
psql -h localhost -p 5432 -U $1 -d hero -f new_customer.psql;
#TODO: public key from keycloak
psql -h localhost -p 5432 -U $1 -d hero -c "INSERT INTO credentials (realm, authserver, realmpublickey) VALUES ('$1.coherosscope.com','https://$1.coherosscope.com/auth','MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgHB68fut668BaOojGYWj/kvcJyRrto1hewB5/+jBiFP3BCkQ/miMQEN7yO0Pow8EyYoeCzIPP0jpTyi0sPwoE37Tunwg+3dUxlueEDZIpyWn4xh0Bw3wJMGusLG9O0LkuaXpyDJfs1++dXvI+t3MQN153E35Ju0YFL55P6A7MrbFkIXcoeTzJRAX2aueL0XQEZb5jE0NTn18NTD3LAKl5oqZoPPfvEHWqNIbDhDB+QAeG3am2x3glZbem83T3gLhbjzKzsIx9ZHe7+gqpvV9V71OVOrBDNfycN6WojlrWa1rmS5C0V+8tfOEug1gs0sSX26PkU1vaWgf0k1viktuXwIDAQAB');"