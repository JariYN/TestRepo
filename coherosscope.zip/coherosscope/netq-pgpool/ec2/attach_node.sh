for i in 0 1 2 3 4 5 6 7 8 9 10
do
        NODE=$(pcp_node_info -h ip-172-20-38-205.eu-west-1.compute.internal -p 30898 -U pgpool -w "$i") #CHANGE PGPOOL HOSTNAME
        echo "$NODE" | grep -q "primary"
        if [ $? -eq 0 ]; then
                IP=$(echo "$NODE" | awk '{print $1;}')
                PORT=$(echo "$NODE" | awk '{print $2;}')
                pg_ctl -D /var/lib/postgresql/11/data/ stop
                rm -r /var/lib/postgresql/11/data_new
                pg_basebackup -h $IP -p $PORT -U replicate -D /var/lib/postgresql/11/data_new || exit 1;

                rm /var/lib/postgresql/11/data_new/postgresql.conf
                rm /var/lib/postgresql/11/data_new/pg_hba.conf
                rm /var/lib/postgresql/11/data_new/pg_ident.conf

                ln -s /etc/postgresql/postgresql.conf /var/lib/postgresql/11/data_new/postgresql.conf &&
                ln -s /etc/postgresql/pg_hba.conf /var/lib/postgresql/11/data_new/pg_hba.conf &&
                ln -s /etc/postgresql/pg_ident.conf /var/lib/postgresql/11/data_new/pg_ident.conf &&

                rm -r /var/lib/postgresql/11/data/*
                mv /var/lib/postgresql/11/data_new/* /var/lib/postgresql/11/data &&
echo "standby_mode          = 'on'
primary_conninfo      = 'host=$IP port=$PORT user=replicate'" | cat > /var/lib/postgresql/11/data/recovery.conf
                
                pg_ctl -D /var/lib/postgresql/11/data/ start &&
                pcp_attach_node -h ip-172-20-38-205.eu-west-1.compute.internal -p 30898 -U pgpool -w 1   #CHANGE PGPOOL HOSTNAME, CHANGE LAST NUMBER TO NODE NUMBER
                break
        fi
done